<?php
	session_start();
	
	$nama = $_SESSION['nama'];
	$noStaff = $_SESSION['noStaff'];
	$jawatan = $_SESSION['jawatan'];
	
	include '../penghubung/penghubung.php';
		
	
	$permohonan = "delete from permohonan where permohonanNoStaff = '$noStaff'";
	mysql_query($permohonan) or die (mysql_error());
	
	header("Location:index.php");
?>