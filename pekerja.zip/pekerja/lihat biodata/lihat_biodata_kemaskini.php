<?php
	session_start();
	$nama = $_SESSION['nama'];
	$noStaff = $_SESSION['noStaff'];
	$jawatan = $_SESSION['jawatan'];
	
	if(!$_SESSION['register'])
		header('Location:../index.php');
	
	else
	{
		include '../penghubung/penghubung.php';
		
		
		$status = "";
		$paparStatus = "";
		
		if(isset($_REQUEST['submit']))
		{ $klik = $_REQUEST['submit']; }
		else { $klik = ""; }
		
		if(!$klik =="")
		{
			$noStaff=$_POST['noStaff'];
			$noIC=$_POST['noIC'];
			$jabatan=$_POST['jabatan'];
			$email = $_POST['email'];
			$noTel = $_POST['noTel'];
	
			$pekerja = "update pekerja
				set	pekerjaIC = '$noIC',
					pekerjaJabatan = '$jabatan',
					pekerjaEmail = '$email',
					pekerjaTelifon = '$noTel'
				where pekerjaID = '$noStaff'";
			$simpanPekerja = mysql_query($pekerja) or die(mysql_error());

			$status = "kb";
		}
		
		
		if(!$status == "")
		{
			if($status == "kb")
			{ $paparStatus = "<font face='Arial, sans-serif' color='green' size='3'>Kemaskini Berjaya!</font>"; }
			else{ $paparStatus = "<font face='Arial, sans-serif' color='Red' size='3'>Kemaskini Gagal!</font>";}
		}
		else{ $paparStatus = "&nbsp;";}
?>

<!DOCTYPE>
<html xml:lang="EN" lang="EN" dir="ltr">
<head>
<title>Sistem Tempahan</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="scripts/jquery.timers.1.2.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.2.1.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.setup.js"></script>
</head>
<body id="top">
<!-- ########################################HEADER############################################################### -->
<?php include '../header.php';?>
<!-- ##################################################TUTUP LOGO##################################################### -->

<!-- #################################################MENU###################################################### -->
<?php include 'menu.php';?>
<!-- #####################################################TUTUP MENU################################################## -->
<!-- ##################################################MAKLUMAT PENGUNA##################################################### -->



<div class="wrapper">
  <div class="container">
  <?php include 'tajuk_kemaskini_biodata.php';?>
 <?php include 'maklumat_diri.php';?>
  </div>
</div>
<!-- #################################################TUTUP MAKLUMAT PENGGUNA###################################################### -->
<!-- ###############################################BODY######################################################## -->
 <?php
  
  //SQL untuk papar semua biodata
  
	$pekerja = "select * from pekerja where pekerjaID = '$noStaff'";
	$queryPekerja = mysql_query($pekerja) or die (mysql_error());
	$dataPekerja = mysql_fetch_array($queryPekerja);
  
  ?>

<div class="wrapper">
<div class="container">
	<div align="center">
	<?php echo $paparStatus; ?>
	</div>
<br>
  <form action="lihat_biodata_kemaskini.php" method="post">
  <table border="1">
  <tr>
  <thead>
  	<th colspan="3"><font face="Arial, Helvetica, sans-serif" size="2">Kemaskini Biodata</font></th>
    </thead>
  </tr> 
  <tr class="light">
  	<td width="24"><font face="Arial, Helvetica, sans-serif" size="2">Nombor Staf</font> <font face="Arial, Helvetica, sans-serif" color="#FF0000" size="2">****</font></td>
    <td width="1%">:</td>
    <td width="75%"><input type="text" name="noStaff" id="noStaff" value="<?php echo $noStaff;?>" size="100" readonly /></td>
    </tr>
    <tr class="light">
    	<td><font face="Arial, Helvetica, sans-serif" size="2">Nama</font> <font face="Arial, Helvetica, sans-serif" color="#FF0000" size="2"> ****</font></td>
        <td>:</td>
        <td><input type="text" name="nama" id="nama" value="<?php echo $nama;?>" size="100" readonly/></td>
    </tr>
    <tr class="light">
    	<td><font face="Arial, Helvetica, sans-serif" size="2">Nombor IC</font></td>
        <td>:</td>
        <td><input type="text" name="noIC" id="noIC" value="<?php echo $dataPekerja['pekerjaIC'];?>" size="100"/></td>
     </tr>
     <tr class="light">
     	<td><font face="Arial, Helvetica, sans-serif" size="2">Jabatan </font></td>
        <td>:</td>
        <td><select name="jabatan">
                    <?php
						
          			$qs = "select * from jabatan";
          			$rowqs = mysql_query($qs) or die(mysql_error());
          			while ($data = mysql_fetch_array($rowqs))
          			{
						
	       				if ($dataPekerja['pekerjaJabatan']==$data["jabatanNama"])
	        					{ 
								?>
									
					      <option value ="<?php echo $data['jabatanNama']; 
						  ?>" selected> <?php echo $data['jabatanNama']; ?>
                          <?php  	}
	       						else
            					{ ?>
                          </option>
					      <option value ="<?php echo $data['jabatanNama']; ?>" ><?php echo $data['jabatanNama']; ?>
                          <?php 		}
          					} ?>
                          </option>
				        </select></td>
         </tr>
		 <tr class="light">
			<td><font face="Arial, Helvetica, sans-serif" size="2">Nombor Telifon</font></td>
			<td>:</td>
			<td><input type="text" name="noTel" id="noTelifon" value="<?php echo $dataPekerja['pekerjaTelifon'];?>" size="100"/></td>
		</tr>
         <tr class="light">
          	<td><font face="Arial, Helvetica, sans-serif" size="2">Email</font> </td>
            <td>:</td>
            <td><input type="text" name="email" id="email" value="<?php echo $dataPekerja['pekerjaEmail'];?>" size="100"/></td>
           </tr>
         </table>
         <div id="respond" align="center">
         	<input name="submit" type="submit" id="submit" value="Simpan" />
            &nbsp;
            <input name="reset" type="reset" id="reset" tabindex="5" value="Kembali Asal" />
            &nbsp;
            <a href="index.php"><input type="button" id="submit" value="Balik Kepada Biodata" /></a>
                   </div> </form>	     
            <br /><br>
		  <small>Petunjuk : <font face="Arial, Helvetica, sans-serif" color="#FF0000" size="2">****</font> >> Perlu minta kebenaran dari admin untuk kemaskini. <a href="lihat_biodata_kemaskini_pohon.php">Klik disini.</a></small>
		  <br>
          </p>
 
     
      </font>
    </div>
    <br class="clear" />
</div>
<!-- #################################################TUTUP BODY###################################################### -->
<!-- #####################################################SPACE################################################## -->
<div id="adblock">
<br class="clear" />
</div>
<!-- #################################################TUTUP SPACE###################################################### -->

<!-- ##############################################BOTTOM######################################################### -->
<?php include '../footer.php';?>
<!-- ##############################################TUTuP BOTTOM######################################################### -->
</body>
</html>
<?php
}
?>
