<?php
	$noStaff = $_POST['nomborStaff'];
	$nama = $_POST['nama'];
	$katalaluan = $_POST['katalaluan'];
	$noStaffPohon = $_POST['noStaffPohon'];
	
	include '../penghubung/penghubung.php';
	
	
	$pengguna = "update pengguna 
				set penggunaID = '$noStaff', 
					penggunaNama = '$nama', 
					penggunaKatalaluan = '$katalaluan' 
				where penggunaID = '$noStaffPohon'";
				
	mysql_query($pengguna) or die (mysql_error());
	
	$permohonan = "delete from permohonan where permohonanNoStaff = '$noStaff'";
	mysql_query($permohonan) or die (mysql_error());
	
	header("Location:lihat_biodata_lulus.php");
?>