<?php
	session_start();
	$nama = $_SESSION['nama'];
	$noStaff = $_SESSION['noStaff'];
	$jawatan = $_SESSION['jawatan'];
	
	if(!$_SESSION['register'])
		header('Location:../index.php');
	
	else
	{
		include '../penghubung/penghubung.php';
	
	
	$pengguna = mysql_query("select * from pengguna where penggunaID = '$noStaff'") or die(mysql_error());
	$dataPengguna = mysql_fetch_array($pengguna);
	
	$permohonan = mysql_query("select * from permohonan where permohonanNoStaff = '$noStaff' and permohonanTindak = 'lulus'") or die(mysql_error());
	$dataPermohonan = mysql_fetch_array($permohonan);
	$adaketak = mysql_num_rows($permohonan);
	
	if($adaketak==0)
	{
		$pohon="";
	}
	else
	{
	$pohon="Permohonan Menukar Nama/Nombor Staff/Katalaluan Diluluskan";
	}
?>

<!DOCTYPE html >
<html xml:lang="EN" lang="EN" dir="ltr">
<head >
<title>Sistem Tempahan</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="scripts/jquery.timers.1.2.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.2.1.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.setup.js"></script>
</head>
<body id="top">
<!-- ########################################HEADER############################################################### -->
<?php include '../header.php';?>

<!-- ##################################################TUTUP LOGO##################################################### -->

<!-- #################################################MENU###################################################### -->
<?php include'menu.php';?>
<!-- #####################################################TUTUP MENU################################################## -->
<!-- ##################################################MAKLUMAT PENGUNA##################################################### -->
<div class="wrapper">
  <div class="container">
 <?php include 'tajuk_laman_biodata.php';?>
 <?php include 'maklumat_diri.php';?>
  </div>
</div>
<!-- #################################################TUTUP MAKLUMAT PENGGUNA###################################################### -->
<!-- ###############################################BODY######################################################## -->
<div class="wrapper">
<div class="container">
<font face="Arial, Helvetica, sans-serif">



  <table summary="Summary Here" cellpadding="0" cellspacing="0">
  <?php
  
	$pekerja = "select * from pekerja where pekerjaID = '$noStaff'";
	$queryPekerja = mysql_query($pekerja) or die (mysql_error());
	$dataPekerja = mysql_fetch_array($queryPekerja);
  
  ?>
  
        <thead>
          <tr>
            <th colspan=" 4">Anda diluluskan untuk : <?php echo $dataPermohonan['permohonanPerkara'];?> </th>
            
          </tr>
        </thead>
        <tbody>
         <form action="proses_kemaskini_lulus.php" method="post" name="kemaskini">
		 <input name="noStaffPohon" value="<?php echo $dataPermohonan['permohonanNoStaff']; ?>" hidden>
          <tr class="dark">
            <td>Nama</td>
            <td width="1%">:</td>
            <td width="52%"><input name="nama" value="<?php echo $nama; ?>" size="130" <?php 
					if($dataPermohonan['permohonanPerkara']=="Tukar Nama")
					{
						echo "";
					}
					else
					{
					echo "readonly";
					}
			
			?>></td>
          </tr>
          <tr class="light">
            <td width="27%">Nombor Staff : </td>
            <td width="1%">:</td>
            <td><input name="nomborStaff" value="<?php echo $noStaff; ?>" <?php 
					if($dataPermohonan['permohonanPerkara']=="Tukar Nombor Staff")
					{
						echo "";
					}
					else
					{
					echo "readonly";
					}
			
			?>></td>
          </tr>
          <tr class="dark">
            <td>Katalaluan</td>
            <td>:</td>
            <td><input name="katalaluan" type="password" value="<?php echo $dataPengguna['penggunaKatalaluan']; ?>" <?php 
					if($dataPermohonan['permohonanPerkara']=="Tukar Katalaluan")
					{
						echo "";
					}
					else
					{
					echo "readonly";
					}
			
			?>></td>
          </tr>
        </tbody>
      </table>
      <p><div id="respond">
	  <input name="submit" type="submit" id="submit" value="Kemaskini" />
      <a href="index.php"><input name="button" type="button" id="submit" value="Kembali" /></a>
      </div>
      </p>
	  </form>
      </font>
    </div>
    <br class="clear" />
</div>
<!-- #################################################TUTUP BODY###################################################### -->
<!-- #####################################################SPACE################################################## -->
<div id="adblock">
<br class="clear" />
</div>
<!-- #################################################TUTUP SPACE###################################################### -->

<!-- ##############################################BOTTOM######################################################### -->
<br class="clear" />
<div class="wrapper col8">
  <div id="copyright">
  <font size="-3" face="Arial, Helvetica, sans-serif">
    <p class="fl_left">Copyright &copy; Jun 2014 - Sept 2014 - All Rights Reserved - <a>PKINK</a></p>
    <p class="fl_right">Dibina oleh : <a>Pelajar Latihan Industri UiTM</a></p>
    </font>
    <br class="clear" />
  </div>
</div>
<!-- ##############################################TUTuP BOTTOM######################################################### -->
</body>
</html>
<?php } ?>