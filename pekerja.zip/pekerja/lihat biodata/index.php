<?php
	session_start();
	$nama = $_SESSION['nama'];
	$noStaff = $_SESSION['noStaff'];
	$jawatan = $_SESSION['jawatan'];
	
	if(!$_SESSION['register'])
		header('Location:../index.php');
	
	else
	{
		include '../penghubung/penghubung.php';
		
		
		if(isset($_GET['status']))
	{
		$catatan = $_GET['status'];
		
		if($catatan == "pasd")
		{	$semakStatus = "Permohonan Anda Sedang Diproses!";}
		else
		{ $semakStatus = $catatan;}
	}
	else
	{
		$semakStatus = '';
	}
	
	$permohonan = mysql_query("select * from permohonan where permohonanNoStaff = '$noStaff'") or die(mysql_error());
	$dataPermohonan = mysql_fetch_array($permohonan);
	$adaketak = mysql_num_rows($permohonan);
	
	if($dataPermohonan['permohonanTindak']=="lulus")
	{
		$noSemak = '1';
		$pohon="Permohonan Menukar Nama/Nombor Staff/Katalaluan Diluluskan";
	}
	elseif($dataPermohonan['permohonanTindak']=="tolak")
	{
		$noSemak = '2';
		$pohon="Maaf! Permohonan Menukar Nama/Nombor Staff/Katalaluan Tidak Diluluskan Sila Cuba Lagi.";
	}
	else
	{	
		$noSemak = '3';
		$pohon="";
	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<title>Sistem Tempahan</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="scripts/jquery.timers.1.2.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.2.1.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.setup.js"></script>
</head>
<body id="top">
<!-- ########################################HEADER############################################################### -->
<?php include '../header.php';?>

<!-- ##################################################TUTUP LOGO##################################################### -->

<!-- #################################################MENU###################################################### -->
<?php include 'menu.php';?>
<!-- #####################################################TUTUP MENU################################################## -->
<!-- ##################################################MAKLUMAT PENGUNA##################################################### -->
<div class="wrapper">
  <div class="container">
  <?php include 'tajuk_laman_biodata.php'; ?>
  <?php include 'maklumat_diri.php';?>
  </div>
</div>
<!-- #################################################TUTUP MAKLUMAT PENGGUNA###################################################### -->
<!-- ###############################################BODY######################################################## -->
<div class="wrapper">
<div class="container">
 <p align="center">
<font face="Arial, Helvetica, sans-serif" color="green" size="+1">
<?php echo $semakStatus."<br>";
		
			if($noSemak == '1')
				{
					echo '<a href="lihat_biodata_kemaskini_pohon_lulus.php">'.$pohon.'</a>';
				}
				
			elseif($noSemak == '2')
				{
					echo $pohon.' <a href="lihat_biodata_kemaskini_pohon_tolak.php">Tutup</a>';
				}
			else
			{
				echo $pohon;
				}
	?>
<br>
</font></p>
<font face="Arial, sans-serif" size="2">
  <table summary="Summary Here" cellpadding="0" cellspacing="0">
  <?php
  
  //SQL untuk papar semua biodata
  
	$pekerja = "select * from pekerja where pekerjaID = '$noStaff'";
	$queryPekerja = mysql_query($pekerja) or die (mysql_error());
	$dataPekerja = mysql_fetch_array($queryPekerja);
  
  ?>
  
        <thead>
          <tr>
            <th colspan=" 4">Biodata Pengguna : </th>
            
          </tr>
        </thead>
        <tbody>
          <tr class="light">
            <td width="16%" rowspan="7"><p align="center"><img src="../<?php echo $dataGambar['gambarAlamat'];?>" width="135" height="145" /></p></td>
            
          </tr>
          <tr class="dark">
            <td>Nama</td>
            <td width="1%">:</td>
            <td width="52%"><?php echo $nama; ?></td>
          </tr>
          <tr class="light">
            <td width="27%">Nombor Staff : </td>
            <td width="1%">:</td>
            <td><?php echo $noStaff; ?></td>
          </tr>
          <tr class="dark">
            <td>Nombor IC</td>
            <td>:</td>
            <td><?php echo $dataPekerja['pekerjaIC']; ?></td>
          </tr>
           <tr class="light">
            <td>Jabatan</td>
            <td>:</td>
            <td><?php echo $dataPekerja['pekerjaJabatan']; ?></td>
          </tr>
           <tr class="dark">
            <td>Nombor Telifon</td>
            <td>:</td>
            <td><?php echo $dataPekerja['pekerjaTelifon']; ?></td>
          </tr>
		   <tr class="light">
            <td>Email</td>
            <td>:</td>
            <td><?php echo $dataPekerja['pekerjaEmail']; ?></td>
          </tr>
        </tbody>
      </table>
      <p><div id="respond">
      <a href="lihat_biodata_kemaskini.php"><input name="submit" type="submit" id="submit" value="Kemaskini" /></a>
      </div>
      </p>
      </font>
    </div>
    <br class="clear" />
</div>
<!-- #################################################TUTUP BODY###################################################### -->
<!-- #####################################################SPACE################################################## -->
<div id="adblock">
<br class="clear" />
</div>
<!-- #################################################TUTUP SPACE###################################################### -->

<!-- ##############################################BOTTOM######################################################### -->
<?php include '../footer.php';?>
<!-- ##############################################TUTuP BOTTOM######################################################### -->
</body>
</html>
<?php } ?>