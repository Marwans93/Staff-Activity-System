<?php
	session_start();
	$nama = $_SESSION['nama'];
	$noStaff = $_SESSION['noStaff'];
	$jawatan = $_SESSION['jawatan'];
	
	if(!$_SESSION['register'])
		header('Location:../index.php');
	
	else
	{
		include '../penghubung/penghubung.php';
		
		
		$klik = "";
		$status = "";
		$paparStatus ="";
		
		if(isset($_REQUEST['submit']))
		{ $klik = $_REQUEST['submit']; }
		else{ $klik = "";}
		
		if(!$klik == "")
		{
			
			
			if(isset($_POST['perkara']))
			{	$semakPerkara = $_POST['perkara'];}
			else{ $semakPerkara = "";}
			
			if($semakPerkara == "1")
			{	$status = "pp"; }
			elseif(!$semakPerkara == "")	
			{	
				$noStaff=$_POST['noStaff'];
				$nama=$_POST['nama'];	
				$perkara=$_POST['perkara'];
	
				$select = mysql_query("select * from permohonan") or die(mysql_error());
				$no = mysql_num_rows($select)+1;
	
				$permohonan = "insert into permohonan values('$no','$noStaff','$nama','$perkara','proses','belum')";
				$simpanPermohonan = mysql_query($permohonan) or die(mysql_error());
			
				$status = "pasd";			
				header ("Location: index.php?status=$status");
			}
			else
			{ $status = "";}
		}
		else
		{
			$status = "";
		}
		
		if(!$status == "")
		{
			if($status == "pp")
			{ $paparStatus= "Sila Pilih Permohonan! <br>";}
		}
		else
		{ $paparStatus = "&nbsp;"; }
		
?>

<!DOCTYPE>
<html xml:lang="EN" lang="EN" dir="ltr">
<head >
<title>Sistem Tempahan</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="scripts/jquery.timers.1.2.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.2.1.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.setup.js"></script>
</head>
<body id="top">
<!-- ########################################HEADER############################################################### -->
<?php include '../header.php';?>
<!-- ##################################################TUTUP LOGO##################################################### -->

<!-- #################################################MENU###################################################### -->
<?php include 'menu.php';?>
<!-- #####################################################TUTUP MENU################################################## -->
<!-- ##################################################MAKLUMAT PENGUNA##################################################### -->



<div class="wrapper">
  <div class="container">
 <?php include 'tajuk_kemaskini_biodata.php';?>
  <?php include 'maklumat_diri.php';?>
  </div>
</div>
<!-- #################################################TUTUP MAKLUMAT PENGGUNA###################################################### -->
<!-- ###############################################BODY######################################################## -->
 <?php
  
  //SQL untuk papar semua biodata
  
	$pekerja = "select * from pekerja where pekerjaID = '$noStaff'";
	$queryPekerja = mysql_query($pekerja) or die (mysql_error());
	$dataPekerja = mysql_fetch_array($queryPekerja);
  
  ?>

<div class="wrapper">
<div class="container">
	
	<div align="center">
	<font face="Arial, Helvetica, sans-serif" color="red" size="3">
		<?php echo $paparStatus; ?>
	</font></div>
<font face="Arial, Helvetica, sans-serif" size="+1">
  <h2>Permohonan Kemaskini Nama/Nombor Staff/Katalaluan : </h2>
		</font>     
	 <div id="respond">
	  
	  <font face="Arial, Helvetica, sans-serif" size="2">
	  <p align="center">
	  Anda boleh menukar nama/nombor staff/katalaluan dengan meminta kebenaran dari admin. 
	  <br>
	  Cara-cara memohon kebenaran:
	  <li> Pilih [Permohonan untuk menukarkan] dibawah.
	  <li> Anda hanya perlu menunggu kebenaran dari admin yang akan dipaparkan pada [Lihat Biodata]. Contoh [Permohonan Menukar Nama/Nombor Staff/Katalaluan Diluluskan]
	  <li> Klik pada link itu.
	  <li> Anda perlu log masuk dengan nombor staff dan katalaluan yang sedia ada terlebih dahulu.
	  <li> Anda boleh menukarkan apa permohonan anda itu.
	    
	  </p>
	  <br>
	  </font>
	  <font face="Arial, Helvetica, sans-serif" size="3">
	  
	  
        <form action="lihat_biodata_kemaskini_pohon.php" method="post">
		<input name="nama" value="<?php echo $nama?>" hidden>
		<input name="noStaff" value="<?php echo $noStaff?>" hidden>
		
		Permohonan untuk menukarkan : 
		 <select name="perkara">
		 <option value="1">Pilih</option>
		  <option value="Tukar Nama">Tukar Nama</option>
		  <option value="Tukar Nombor Staff">Tukar Nombor Staff</option>
		  <option value="Tukar Katalaluan">Tukar Katalaluan</option>
		  </select>
		  
		  <br>
		  <br>
		 <input type="submit" id="submit" name="submit" value="Hantar">
		 <a href="lihat_biodata_kemaskini.php"><input type="button" id="submit" name="submit" value="Kembali"></a>
        </form>
      </div>
      </font>
    </div>
    <br class="clear" />
</div>
<!-- #################################################TUTUP BODY###################################################### -->
<!-- #####################################################SPACE################################################## -->
<div id="adblock">
<br class="clear" />
</div>
<!-- #################################################TUTUP SPACE###################################################### -->

<!-- ##############################################BOTTOM######################################################### -->
<br class="clear" />
<div class="wrapper col8">
  <div id="copyright">
  <font size="-3" face="Arial, Helvetica, sans-serif">
    <p class="fl_left">Copyright &copy; Jun 2014 - Sept 2014 - All Rights Reserved - <a>PKINK</a></p>
    <p class="fl_right">Dibina oleh : <a>Pelajar Latihan Industri UiTM</a></p>
    </font>
    <br class="clear" />
  </div>
</div>
<!-- ##############################################TUTuP BOTTOM######################################################### -->
</body>
</html>
<?php
}
?>
