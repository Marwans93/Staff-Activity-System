<font face="Arial, Helvetica, sans-serif" size="6">
  <a href="index.php">Laman Kemaskini Biodata</a>
  </font>