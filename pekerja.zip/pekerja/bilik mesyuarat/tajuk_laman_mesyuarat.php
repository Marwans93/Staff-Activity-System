<font face="Arial, Helvetica, sans-serif" size="6">
  <a href="index.php">Laman Bilik Mesyuarat</a>
  </font>