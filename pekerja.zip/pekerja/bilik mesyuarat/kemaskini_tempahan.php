<?php
	session_start();
	$nama = $_SESSION['nama'];
	$noStaff = $_SESSION['noStaff'];
	$jawatan = $_SESSION['jawatan'];
	
		
	
	if(!$_SESSION['register'])
		header('Location:../index.php');
	
	else
	{
		include '../penghubung/penghubung.php';
		
		
	
		if(isset($_GET['noTempahanK']))
		{	
			$noTempahan = $_GET['noTempahanK'];
			$bilikNo = $_GET['noBilikK'];
			$masaMulaLama = $_GET['masaMulaK'];
			$masaAkhirLama = $_GET['masaAkhirK'];
			$tarikhMula = $_GET['tarikhMulaK'];
		//Tukar masa
		
		
	
	//################# Start Masa ###################################
	
	//###########################################buka 9pg###########################################################
	
		if($masaAkhirLama=='9:00PG')
	{
		if($masaMulaLama=='8:00PG')
		{
			$masaHapus = "update masa
					set	pg8 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		
	}	
//##########################tutup 9pg#########################################
//##########################buka 5ptg#########################################	
	elseif($masaAkhirLama=="5:00PTG")
	{
		if($masaMulaLama=="8:00PG")
		{
			$masaHapus = "update masa
					set	pg8 = 't',
						pg9 = 't',
						pg10 = 't',
						pg11 = 't',
						ptg12 = 't',
						ptg1 = 't',
						ptg2 = 't',
						ptg3 = 't',
						ptg4 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		elseif($masaMulaLama=="9:00PG")
		{
			$masaHapus = "update masa
					set	pg9 = 't',
						pg10 = 't',
						pg11 = 't',
						ptg12 = 't',
						ptg1 = 't',
						ptg2 = 't',
						ptg3 = 't',
						ptg4 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		elseif($masaMulaLama=="10:00PG")
		{
			$masaHapus = "update masa
					set	pg10 = 't',
						pg11 = 't',
						ptg12 = 't',
						ptg1 = 't',
						ptg2 = 't',
						ptg3 = 't',
						ptg4 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		elseif($masaMulaLama=="11:00PG")
		{
			$masaHapus = "update masa
					set	pg11 = 't',
						ptg12 = 't',
						ptg1 = 't',
						ptg2 = 't',
						ptg3 = 't',
						ptg4 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		elseif($masaMulaLama=="12:00PTG")
		{
			$masaHapus = "update masa
					set	ptg12 = 't',
						ptg1 = 't',
						ptg2 = 't',
						ptg3 = 't',
						ptg4 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		elseif($masaMulaLama=="1:00PTG")
		{
			$masaHapus = "update masa
					set	ptg1 = 't',
						ptg2 = 't',
						ptg3 = 't',
						ptg4 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		elseif($masaMulaLama=="2:00PTG")
		{
			$masaHapus = "update masa
					set	ptg2 = 't',
						ptg3 = 't',
						ptg4 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		elseif($masaMulaLama=="3:00PTG")
		{
			$masaHapus = "update masa
					set ptg3 = 't',
						ptg4 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		elseif($masaMulaLama=="4:00PTG")
		{
			$masaHapus = "update masa
					set ptg4 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
	}
	
//##########################tutup 5ptg############################
//##########################buka 4ptg#########################################
	elseif($masaAkhirLama=="4:00PTG")
	{
		if($masaMulaLama=="8:00PG")
		{
			$masaHapus = "update masa
					set	pg8 = 't',
						pg9 = 't',
						pg10 = 't',
						pg11 = 't',
						ptg12 = 't',
						ptg1 = 't',
						ptg2 = 't',
						ptg3 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		elseif($masaMulaLama=="9:00PG")
		{
			$masaHapus = "update masa
					set	pg9 = 't',
						pg10 = 't',
						pg11 = 't',
						ptg12 = 't',
						ptg1 = 't',
						ptg2 = 't',
						ptg3 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		elseif($masaMulaLama=="10:00PG")
		{
			$masaHapus = "update masa
					set	pg10 = 't',
						pg11 = 't',
						ptg12 = 't',
						ptg1 = 't',
						ptg2 = 't',
						ptg3 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		elseif($masaMulaLama=="11:00PG")
		{
			$masaHapus = "update masa
					set	pg11 = 't',
						ptg12 = 't',
						ptg1 = 't',
						ptg2 = 't',
						ptg3 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		elseif($masaMulaLama=="12:00PTG")
		{
			$masaHapus = "update masa
					set	ptg12 = 't',
						ptg1 = 't',
						ptg2 = 't',
						ptg3 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		elseif($masaMulaLama=="1:00PTG")
		{
			$masaHapus = "update masa
					set	ptg1 = 't',
						ptg2 = 't',
						ptg3 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		elseif($masaMulaLama=="2:00PTG")
		{
			$masaHapus = "update masa
					set	ptg2 = 't',
						ptg3 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		elseif($masaMulaLama=="3:00PTG")
		{
			$masaHapus = "update masa
					set ptg3 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
	}
//##########################tutup 4ptg##################################################
//##########################buka 3ptg#########################################	
	elseif($masaAkhirLama=="3:00PTG")
	{
		if($masaMulaLama=="8:00PG")
		{
			$masaHapus = "update masa
					set	pg8 = 't',
						pg9 = 't',
						pg10 = 't',
						pg11 = 't',
						ptg12 = 't',
						ptg1 = 't',
						ptg2 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		elseif($masaMulaLama=="9:00PG")
		{
			$masaHapus = "update masa
					set	pg9 = 't',
						pg10 = 't',
						pg11 = 't',
						ptg12 = 't',
						ptg1 = 't',
						ptg2 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		elseif($masaMulaLama=="10:00PG")
		{
			$masaHapus = "update masa
					set	pg10 = 't',
						pg11 = 't',
						ptg12 = 't',
						ptg1 = 't',
						ptg2 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		elseif($masaMulaLama=="11:00PG")
		{
			$masaHapus = "update masa
					set	pg11 = 't',
						ptg12 = 't',
						ptg1 = 't',
						ptg2 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		elseif($masaMulaLama=="12:00PTG")
		{
			$masaHapus = "update masa
					set	ptg12 = 't',
						ptg1 = 't',
						ptg2 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		elseif($masaMulaLama=="1:00PTG")
		{
			$masaHapus = "update masa
					set	ptg1 = 't',
						ptg2 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		elseif($masaMulaLama=="2:00PTG")
		{
			$masaHapus = "update masa
					set	ptg2 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		
	}
//##########################tutup 3ptg#########################################
//##########################buka 2ptg#########################################		
		elseif($masaAkhirLama=="2:00PTG")
	{
		if($masaMulaLama=="8:00PG")
		{
			$masaHapus = "update masa
					set	pg8 = 't',
						pg9 = 't',
						pg10 = 't',
						pg11 = 't',
						ptg12 = 't',
						ptg1 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		elseif($masaMulaLama=="9:00PG")
		{
			$masaHapus = "update masa
					set	pg9 = 't',
						pg10 = 't',
						pg11 = 't',
						ptg12 = 't',
						ptg1 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		elseif($masaMulaLama=="10:00PG")
		{
		
			$masaHapus = "update masa
					set	pg10 = 't',
						pg11 = 't',
						ptg12 = 't',
						ptg1 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		elseif($masaMulaLama=="11:00PG")
		{
			$masaHapus = "update masa
					set	pg11 = 't',
						ptg12 = 't',
						ptg1 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		elseif($masaMulaLama=="12:00PTG")
		{
			$masaHapus = "update masa
					set	ptg12 = 't',
						ptg1 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		elseif($masaMulaLama=="1:00PTG")
		{
			$masaHapus = "update masa
					set	ptg1 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		
	}
//##########################tutup 2ptg#########################################
//##########################buka 1ptg#########################################		
		elseif($masaAkhirLama=="1:00PTG")
	{
		if($masaMulaLama=="8:00PG")
		{
			$masaHapus = "update masa
					set	pg8 = 't',
						pg9 = 't',
						pg10 = 't',
						pg11 = 't',
						ptg12 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		elseif($masaMulaLama=="9:00PG")
		{
			$masaHapus = "update masa
					set	pg9 = 't',
						pg10 = 't',
						pg11 = 't',
						ptg12 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		elseif($masaMulaLama=="10:00PG")
		{
			$masaHapus = "update masa
					set	pg10 = 't',
						pg11 = 't',
						ptg12 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		elseif($masaMulaLama=="11:00PG")
		{
			$masaHapus = "update masa
					set	pg11 = 't',
						ptg12 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		elseif($masaMulaLama=="12:00PTG")
		{
			$masaHapus = "update masa
					set	ptg12 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		
	}
//##########################tutup 1ptg#########################################
//##########################buka 12ptg#########################################		
		elseif($masaAkhirLama=="12:00PTG")
	{
		if($masaMulaLama=="8:00PG")
		{
			$masaHapus = "update masa
					set	pg8 = 't',
						pg9 = 't',
						pg10 = 't',
						pg11 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		elseif($masaMulaLama=="9:00PG")
		{
			$masaHapus = "update masa
					set	pg9 = 't',
						pg10 = 't',
						pg11 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		elseif($masaMulaLama=="10:00PG")
		{
			$masaHapus = "update masa
					set	pg10 = 't',
						pg11 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		elseif($masaMulaLama=="11:00PG")
		{
			$masaHapus = "update masa
					set	pg11 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		
	}
//##########################tutup 12ptg#########################################
//##########################buka 11pg#########################################		
		elseif($masaAkhirLama=="11:00PG")
	{
		if($masaMulaLama=="8:00PG")
		{
			$masaHapus = "update masa
					set	pg8 = 't',
						pg9 = 't',
						pg10 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		elseif($masaMulaLama=="9:00PG")
		{
			$masaHapus = "update masa
					set	pg9 = 't',
						pg10 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		elseif($masaMulaLama=="10:00PG")
		{
			$masaHapus = "update masa
					set	pg10 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		
	}
//##########################tutup 11pg#########################################	
//##########################buka 10pg#########################################
		elseif($masaAkhirLama=="10:00PG")
	{
		if($masaMulaLama=="8:00PG")
		{
			$masaHapus = "update masa
					set	pg8 = 't',
						pg9 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		elseif($masaMulaLama=="9:00PG")
		{
			$masaHapus = "update masa
					set	pg9 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
		}
		
	}
    //#########################tutup 10pg##########################################	
		mysql_query($masaHapus) or die(mysql_error());
	
	//#################tutup masa#####################################
	
		
		}
		else
		{
			$noTempahan = $_GET['noTempahan'];
		}
	
	
	
	
		$pekerja = "select * from pekerja where pekerjaID = '$noStaff'";
		$qPekerja = mysql_query($pekerja) or die (mysql_error());
		$dataPekerja = mysql_fetch_array($qPekerja);
		
		$tempahan = "select * from tempahan where tempahanNo = '$noTempahan'";
		$qTempahan = mysql_query($tempahan) or die (mysql_error());
		$dataTempahan = mysql_fetch_array($qTempahan);
		
		$tempahanBilik = "select * from tempahanBilik where tempahanNo = '$noTempahan'";
		$qTempahanBilik = mysql_query($tempahanBilik) or die (mysql_error());
		$dataTempahanBilik = mysql_fetch_array($qTempahanBilik);
		$noBilik = $dataTempahanBilik['bilikNo'];
		
		$bilik = "select * from bilik where bilikNo = '$noBilik'";
		$qBilik = mysql_query($bilik) or die (mysql_error());
		$dataBilik = mysql_fetch_array($qBilik);
		
		$arasNama = $dataBilik['bilikAras'];
		
		$aras = "select * from aras where arasNama = '$arasNama'";
		$qAras = mysql_query($aras) or die (mysql_error());
		$dataAras = mysql_fetch_array($qAras);
		
		
		
		//proses kemaskini
		$status = "";
		if(isset($_REQUEST['submit']))
		{
			$klik = $_REQUEST['submit'];
		}
		else
		{
			$klik = "";
		}
		
		if(!$klik == "")
		{
			$noTempahan = $_POST['noTempahan'];
			$noStaff = $_POST['noStaff'];
			$pinjamanLCD = $_POST['pinjamanLCD'];
			$tujuan = $_POST['tujuan'];
			$aras = $_POST['aras'];
			$noBilik = $_POST['noBilik'];
			$masaMula = $_POST['masaMula'];
			$masaAkhir  = $_POST['masaAkhir'];
			$tarikhMula = $_POST['tarikhMula'];
	
			$tempahanKemaskini = "update tempahan
					set	tempahanLCD = '$pinjamanLCD',
						tempahanTujuan = '$tujuan'
					where tempahanID = '$noStaff' and tempahanNo = '$noTempahan'";
			mysql_query($tempahanKemaskini) or die(mysql_error());
			$status = "kb";
			header("Location:senarai_tempahan.php?status=$status");
		}
		else
		{
			$status="";
		}
		
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<title>Sistem Tempahan</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="scripts/jquery.timers.1.2.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.2.1.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.setup.js"></script>




</head>
<body id="top">
<!-- ########################################HEADER############################################################### -->
<?php include '../header.php';?>
<!-- ##################################################TUTUP LOGO##################################################### -->

<!-- #################################################MENU###################################################### -->
<?php include 'menu.php';?>
<!-- #####################################################TUTUP MENU################################################## -->
<!-- ##################################################MAKLUMAT PENGUNA##################################################### -->
<div class="wrapper">
  <div class="container">
<?php include 'tajuk_laman_mesyuarat.php'; ?>
  <?php include 'maklumat_diri.php';?>
  </div>
</div>
<!-- #################################################TUTUP MAKLUMAT PENGGUNA###################################################### -->
<!-- ###############################################BODY######################################################## -->
<div class="wrapper">
<div class="container">

<form name="kemaskini" method="post" action="kemaskini_tempahan.php">

<font face="Arial, Helvetica, sans-serif">
<p align="center">Hanya pinjaman LCD dan tujuan sahaja boleh di kemaskini. Kemaskini masa tempahan perlu menyemak kekosongan pada tarikh itu dahulu sebelum kemaskini.<br>
Sila klik pada Tukar Masa untuk kemaskini masa. Harap Maklum.</p>
 <table summary="Summary Here" cellpadding="0" cellspacing="0">
        <thead>
          <tr>
            <th colspan=" 4">Tempahan</th>
            
          </tr>
        </thead>
        <tbody>
          
        <tr class="light">
            <td width="27%">Nama</td>
            <td width="1%">:</td>
            <td><input name="nama" value="<?php echo $nama; ?>" readonly size="130"></td>
		<tr class="dark">
            <td>Nombor Staf</td>
            <td>:</td>
             <td><input name="noStaff" value="<?php echo $noStaff; ?>" readonly></td>
			<tr class="light">
            <td >Jabatan</td>
            <td >:</td>
            <td><input name="jabatan" value="<?php echo $dataPekerja['pekerjaJabatan']; ?>" readonly size="130"></td>
          <tr class="dark">
            <td>Tarikh </td>
            <td>:</td>
			<td><input name="tarikhMula" value="<?php echo $dataTempahan['tempahanTarikh'];?>" readonly></td>
          </tr>
          <tr class="light">
            <td>Masa Mula</td>
            <td>:</td>
            <td><input name="masaMula" value="<?php echo $dataTempahan['tempahanMula']; ?>" readonly></td>
          </tr>
          <tr class="dark">
            <td>Masa Akhir</td>
            <td>:</td>
         <td><input name="masaAkhir" value="<?php echo $dataTempahan['tempahanAkhir']; ?>" readonly></td>
		 </tr>
		    <tr class="light">
            <td>Pinjaman LCD (Boleh Dikemaskini)</td>
            <td>:</td>
            <td>
			<input type="radio" name="pinjamanLCD" value="Ya" required 
			<?php  if($dataTempahan['tempahanLCD']=="Ya")
				{echo "checked";}
			else
			{
			echo "";
			}
			?>>Ya
			<input type="radio" name="pinjamanLCD" value="Tidak"<?php
			if($dataTempahan['tempahanLCD']=="Tidak")
				{echo "checked";}
			else
			{
			echo "";
			}
			?> required>Tidak</td>
          </tr>
		  <tr class="dark">
            <td>Nama Bilik</td>
            <td>:</td>
            <td><input name="namaBilik" value="<?php echo $dataBilik['bilikNama']; ?>" readonly size="80"></td>
			<input name="noBilik" value="<?php echo $dataBilik['bilikNo']; ?>" hidden>
          </tr>
           <tr class="light">
            <td>Aras</td>
            <td>:</td>
            <td><input name="aras" value="<?php echo $dataBilik['bilikAras']; ?>" readonly></td>
          </tr>  
		   <tr class="dark">
           
            <td>Tujuan (Boleh Dikemaskini)</td>
            <td>:</td>
            <td><input name="tujuan" value="<?php echo $dataTempahan['tempahanTujuan']; ?>" size="130" required></td>
			<input name="noTempahan" value="<?php echo $noTempahan; ?>" hidden>
          </tr>
        </tbody>
      </table>
	  </font>
        
      <p><div id="respond">
	  <p align = "center">
	  <a><input name="submit" type="submit" id="submit" value="Kemaskini" /></a>
	  <a><input name="reset" type="reset" id="submit" value="Padam Ke Asal" /></a>
	  <a href="kemaskini_tempahan_tukar_masa.php?noTempahan=<?php echo $noTempahan;?>&tarikhMula=<?php echo $dataTempahan['tempahanTarikh'];?>&aras=<?php echo $dataAras['arasId']; ?>&noBilik=<?php echo $dataBilik['bilikNo']; ?>&masaMula=<?php echo $dataTempahan['tempahanMula']; ?>&masaAkhir=<?php echo $dataTempahan['tempahanAkhir'];?>"><input type="button" id="submit" value="Tukar Masa" /></a>
	  <a href="proses_batal_tempahan.php?noBilik=<?php echo $dataBilik['bilikNo'];?>&noTempahan=<?php echo $noTempahan; ?>&noStaff=<?php echo $noStaff;?>&masaMula=<?php echo $dataTempahan['tempahanMula']; ?>&masaAkhir=<?php echo $dataTempahan['tempahanAkhir']; ?>&tarikhMula=<?php echo $dataTempahan['tempahanTarikh'];?>"><input type="button" id="submit" value="Batal Tempahan" /></a>
	  <a href="senarai_tempahan.php"><input type="button" id="submit" value="Kembali" /></a>
	  </form>
      </p></div>
      </p>
    </font>
    </div>
    <br class="clear" />
</div>
<!-- #################################################TUTUP BODY###################################################### -->

<!-- #####################################################SPACE################################################## -->
<div id="adblock">
<br class="clear" />
</div>
<!-- #################################################TUTUP SPACE###################################################### -->

<!-- ##############################################BOTTOM######################################################### -->
 <?php include '../footer.php';?>
<!-- ##############################################TUTuP BOTTOM######################################################### -->
</body>
</html>
<?php 
}
?>
