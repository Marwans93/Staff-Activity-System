<font face="Arial, Helvetica, sans-serif" size="6">
  <a href="index.php">Laman Tempah Bilik Mesyuarat</a>
  </font>