<?php
	session_start();
	$nama = $_SESSION['nama'];
	$noStaff = $_SESSION['noStaff'];
	$jawatan = $_SESSION['jawatan'];
	
	if(!$_SESSION['register'])
		header('Location:../index.php');
	
	else
	{
		include '../penghubung/penghubung.php';
?>


<!DOCTYPE>
<html xml:lang="EN" lang="EN" dir="ltr">
<head>
<title>Sistem Tempahan</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="scripts/jquery.timers.1.2.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.2.1.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.setup.js"></script>
</head>
<body id="top">
<!-- ########################################HEADER############################################################### -->
<?php include '../header.php';?>

<!-- ##################################################TUTUP LOGO##################################################### -->

<!-- #################################################MENU###################################################### -->
<?php include 'menu.php'; ?>
<!-- #####################################################TUTUP MENU################################################## -->
<!-- ##################################################MAKLUMAT PENGUNA##################################################### -->
<div class="wrapper">
  <div class="container">
  <?php include 'tajuk_laman_mesyuarat.php';?>
  <?php include 'maklumat_diri.php';?>
  </div>
</div>
<!-- #################################################TUTUP MAKLUMAT PENGGUNA###################################################### -->
<!-- ###############################################BODY######################################################## -->
<div class="wrapper">
  <div id="adblock">
  <p align="center">
  <font face="Arial, Helvetica, sans-serif">Pilih salah satu.</font></p>
    <div class="fl_left">
    <a href="senarai_tempahan.php">
    <img src="images/senarai2.png" onMouseOver="this.src='images/senarai1.png'" onMouseOut="this.src='images/senarai2.png'" onClick="this.src='images/senarai2.png'"></a>
    </div>
    
    <div class="fl_right"><a href="semak_tempah.php"><img src="images/tempah2.png" onMouseOver="this.src='images/tempah1.png'" onMouseOut="this.src='images/tempah2.png'" onClick="this.src='images/tempah2.png'"></a>
    </div>
    
    <br class="clear" />
  </div>
<!-- #################################################TUTUP BODY###################################################### -->
<!-- #####################################################SPACE################################################## -->
<div id="adblock">
<br class="clear" />
</div>
<!-- #################################################TUTUP SPACE###################################################### -->

<!-- ##############################################BOTTOM######################################################### -->
<?php include'../footer.php'?>
<!-- ##############################################TUTuP BOTTOM######################################################### -->
</body>
</html>
<?php

}
?>
