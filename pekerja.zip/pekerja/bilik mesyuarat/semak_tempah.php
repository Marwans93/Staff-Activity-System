<?php
	session_start();
	$nama = $_SESSION['nama'];
	$noStaff = $_SESSION['noStaff'];
	$jawatan = $_SESSION['jawatan'];

	
	
	if(!$_SESSION['register'])
		header('Location:../index.php');
	
	else
	{
		
		include '../penghubung/penghubung.php';
		
		
	$carianAras = "";
	$carianBilik = "";
	$carianTarikh = "";	
	$arasBeza = "";	
	$tarikhMula = "";
	$tarikhAkhir = "";
	$tableOn = "";
		
	if(isset($_REQUEST['aras']))
	{	$carianAras = $_REQUEST['aras']; }	
	else
	{ $carianAras = "";}
	
	if(!$carianAras == "")
	{	$aras = $carianAras; }
	else
	{	$aras = ""; }
	
	
	
	if(isset($_REQUEST['noBilik']))
	{	$carianBilik = $_REQUEST['noBilik']; }	
	else
	{ $carianBilik = "";}
	
	if(!$carianBilik == "")
	{	$bilikNo = $carianBilik; }
	else
	{	$bilikNo = ""; }
	
	
	
	if(isset($_GET['tarikhMula']))
	{	$carianTarikh = $_REQUEST['tarikhMula']; }	
	else
	{ $carianTarikh = "";}
	
	if(!$carianTarikh == "")
	{	
		$tarikhMula = $carianTarikh;
		$aras = $_GET['aras'];
		$bilikNo = $_GET['noBilik'];
		$tableOn = "yes";
	}
	else
	{	$tarikhMula = ""; }
	
	
	if(isset($_GET['tarikhAkhir']))
	{	$carianTarikhA = $_REQUEST['tarikhAkhir']; }	
	else
	{ $carianTarikhA = "";}
	
	if(!$carianTarikhA == "")
	{	
		$tarikhAkhir = $carianTarikhA;
		$aras = $_GET['aras'];
		$bilikNo = $_GET['noBilik'];
		$tableOn = "yes";
	}
	else
	{	$tarikhAkhir = ""; }
	
	
	
?>

<!DOCTYPE>
<html xml:lang="EN" lang="EN" dir="ltr">
<head>
<title>Sistem Tempahan</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<link rel="stylesheet" type="text/css" href="datetimepicker-master/jquery.datetimepicker.css"/>
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="scripts/jquery.timers.1.2.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.2.1.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.setup.js"></script>


</head>
<body id="top">
<!-- ########################################HEADER############################################################### -->
<?php include'../header.php';?>
<!-- ##################################################TUTUP LOGO##################################################### -->

<!-- #################################################MENU###################################################### -->
<?php include'menu.php';?>
<!-- #####################################################TUTUP MENU################################################## -->
<!-- ##################################################MAKLUMAT PENGUNA##################################################### -->
<div class="wrapper">
  <div class="container">
  <?php include'tajuk_tempah_bilik_mesyuarat.php';?>
  <?php include'maklumat_diri.php';?>
  </div>
</div>
<!-- #################################################TUTUP MAKLUMAT PENGGUNA###################################################### -->
<!-- ###############################################BODY######################################################## -->
<div class="wrapper">
<div class="container">




 <table class="table2" summary="Summary Here" cellpadding="0" cellspacing="0" width="50%">
       
		<thead>
          <tr>
            <th ><font face="Arial, Helvetica, sans-serif" size="2">Semak</font></th>
          </tr>
        </thead>
		<tr>
		<td align="center"><div id="respond">
        <form name="form" method="post" action="semak_tempah.php">
		 <select name="aras" onChange="this.form.submit();">
         	<option value="">Pilih Aras           
				<?php
				$qs = "select * from aras";
          		$rowqs = mysql_query($qs) or die(mysql_error());
          		while ($data = mysql_fetch_array($rowqs))
          		{		
	       			if ($aras==$data["arasId"])
	        		{ 
						$arasBeza = $data['arasNama'];
				?>
			</option>	
			<option value ="<?php echo $data['arasId']; ?>" selected> <?php echo $data['arasNama']; ?>
                <?php  	
					}
					else
            		{
				?>
            </option>
			<option value ="<?php echo $data['arasId']; ?>" ><?php echo $data['arasNama']; ?>
            <?php 	
					}
          		} 
				?>
          	</option>
			</select>
            </form>						 
						 
						 
				<!-- Proses Carian -->		 
				<form name="bilik" method = "post" action="semak_tempah.php">
				<select name="noBilik" onChange="this.form.submit();">
					<option>Pilih Nama Bilik Mesyuarat
					<?php
					$bilikJenis = "Bilik Mesyuarat";
          			$bilik = "select * from bilik where bilikAras = '$arasBeza' and bilikJenis = '$bilikJenis'";
          			$qBilik = mysql_query($bilik) or die(mysql_error());
          			while ($dataBilik = mysql_fetch_array($qBilik))
          			{
						if ($bilikNo==$dataBilik["bilikNo"])
	        					{ 
			 		?>
	       			</option>
					<option value ="<?php echo $dataBilik['bilikNo']; ?>" selected> <?php echo $dataBilik['bilikNama']; ?>
					<?php  		
								}
	       				else
            					{ 
					?>
					</option>
					<option value ="<?php echo $dataBilik['bilikNo']; ?>" ><?php echo $dataBilik['bilikNama']; ?>
                          <?php }		
          					} ?>
                    </option>
				    </select>
                    
                    <input type="text" name="aras" value="<?php echo $aras;?>" hidden>
                    
                    </form>
                    
                    <form action="proses_semak_tarikh.php" method="post">
					
					<select name="tahun">
						<option value="2014">2014</option>
						<option value="2015">2015</option>
						<option value="2016">2016</option>
					</select>
					
					<select name="bulan">
						<option value="01">Januari</option>
						<option value="02">Februari</option>
						<option value="03">Mac</option>
						<option value="04">April</option>
						<option value="05">Mei</option>
						<option value="06">Jun</option>
						<option value="07">Julai</option>
						<option value="08">Ogos</option>
						<option value="09">September</option>
						<option value="10">Oktober</option>
						<option value="11">November</option>
						<option value="12">Desember</option>
					</select>
					
					
                	<input type="text" name="aras" value="<?php echo $aras;?>" hidden required>
                    <input type="text" name="noBilik" value="<?php echo $bilikNo;?>" hidden required>
                     <div id="respond">
	 					<p align = "center">   
					<input type="submit" name="submit" value="Semak" />
                    	</p>
                     </div>
				</td>
			</tr>
		
				</form>
				<!-- tutup Proses Carian -->
			</table>
				



<?php 
	if($tableOn == "yes")
	{
?>

  <table summary="Summary Here" cellpadding="0" cellspacing="0" border="1">
        <thead>
          <tr>
			<th width ="5%"><font face="Arial, sans-serif" size="2">Hari </font></th>
            <th width ="11%"><font face="Arial, sans-serif" size="2">Tarikh </font></th>
			<th width="9.8%"><font face="Arial, sans-serif" size="2">8-9 PG </font></th>
			<th width="9.8%"><font face="Arial, sans-serif" size="2">9-10 PG </font></th>
			<th width="9.8%"><font face="Arial, sans-serif" size="2">10-11 PG </font></th>
			<th width="9.8%"><font face="Arial, sans-serif" size="2">11-12 PTG </font></th>
			<th width="9.9%"><font face="Arial, sans-serif" size="2">12-1 PTG </font></th>
			<th width="9.8%"><font face="Arial, sans-serif" size="2">1-2 PTG </font></th>
			<th width="9.8%"><font face="Arial, sans-serif" size="2">2-3 PTG </font></th>
			<th width="9.9%"><font face="Arial, sans-serif" size="2">3-4 PTG </font></th>
			<th width="9.9%"><font face="Arial, sans-serif" size="2">4-5 PTG </font></th>
           
			</thead>
		  <tr> 
		  <?php
			
			$masa = "select * from masa where masaTarikh between '$tarikhMula' and '$tarikhAkhir' and masaBilikNo = '$bilikNo'";
			$qMasa = mysql_query($masa) or die (mysql_error());

		while($dataMasa = mysql_fetch_array($qMasa))
		  {
		  ?>
			<td><font face="Arial, sans-serif" size="2"><?php  
			$hariTukar = $dataMasa['masaTarikh'];
			$tukar = new DateTime($hariTukar);
			$namaHari = $tukar->format('l');
			if($namaHari == "Friday")
			{ echo "Jumaat";}
			elseif($namaHari == "Saturday")
			{ echo "Sabtu";}
			elseif($namaHari == "Sunday")
			{ echo "Ahad";}
			elseif($namaHari == "Monday")
			{ echo "Isnin";}
			elseif($namaHari == "Tuesday")
			{ echo "Selasa";}
			elseif($namaHari == "Wednesday")
			{ echo "Rabu";}
			elseif($namaHari == "Thursday")
			{ echo "Khamis";}
			
			
			?></font></td>
			
			
			
			
			<td><font face="Arial, sans-serif" size="2"><?php echo $dataMasa['masaTarikh']; 
			$tarikh = $dataMasa['masaTarikh'];
			?></font></td>
			<td><?php if($dataMasa['pg8']=='x')
					{	$masa = "8:00PG"; 
					echo "<a href='tempah_maklumat.php?tarikhMula=$tarikh&tarikhAsal=$tarikhMula&tarikhAkhir=$tarikhAkhir&aras=$aras&noBilik=$bilikNo&masa=$masa'><img src='images/kosong.png'onMouseOver=this.src='images/kosong2.png' onClick=this.src='images/kosong.png' onMouseOut=this.src='images/kosong.png'></a>";}
					else
					{ echo "<img src='images/penuh.png'>"; } ?></td>
			<td><?php if($dataMasa['pg9']=='x')
					{ $masa = "9:00PG";
					echo "<a href='tempah_maklumat.php?tarikhMula=$tarikh&tarikhAsal=$tarikhMula&tarikhAkhir=$tarikhAkhir&aras=$aras&noBilik=$bilikNo&masa=$masa'><img src='images/kosong.png'onMouseOver=this.src='images/kosong2.png' onClick=this.src='images/kosong.png' onMouseOut=this.src='images/kosong.png'></a>";}
					else
					{ echo "<img src='images/penuh.png'>"; } ?></td>
			<td><?php if($dataMasa['pg10']=='x')
					{ $masa = "10:00PG";
					echo "<a href='tempah_maklumat.php?tarikhMula=$tarikh&tarikhAsal=$tarikhMula&tarikhAkhir=$tarikhAkhir&aras=$aras&noBilik=$bilikNo&masa=$masa'><img src='images/kosong.png'onMouseOver=this.src='images/kosong2.png' onClick=this.src='images/kosong.png' onMouseOut=this.src='images/kosong.png'></a>";}
					else
					{ echo "<img src='images/penuh.png'>"; } ?></td>
			<td><?php if($dataMasa['pg11']=='x')
					{	$masa = "11:00PG"; 
					echo "<a href='tempah_maklumat.php?tarikhMula=$tarikh&tarikhAsal=$tarikhMula&tarikhAkhir=$tarikhAkhir&aras=$aras&noBilik=$bilikNo&masa=$masa'><img src='images/kosong.png'onMouseOver=this.src='images/kosong2.png' onClick=this.src='images/kosong.png' onMouseOut=this.src='images/kosong.png'></a>";}
					else
					{ echo "<img src='images/penuh.png'>"; } ?></td>
			<td><?php if($dataMasa['ptg12']=='x')
					{	$masa = "12:00PTG";  
					echo "<a href='tempah_maklumat.php?tarikhMula=$tarikh&tarikhAsal=$tarikhMula&tarikhAkhir=$tarikhAkhir&aras=$aras&noBilik=$bilikNo&masa=$masa'><img src='images/kosong.png'onMouseOver=this.src='images/kosong2.png' onClick=this.src='images/kosong.png' onMouseOut=this.src='images/kosong.png'></a>";}
					else
					{ echo "<img src='images/penuh.png'>"; } ?></td>
			<td><?php if($dataMasa['ptg1']=='x')
					{	$masa = "1:00PTG"; 
					echo "<a href='tempah_maklumat.php?tarikhMula=$tarikh&tarikhAsal=$tarikhMula&tarikhAkhir=$tarikhAkhir&aras=$aras&noBilik=$bilikNo&masa=$masa'><img src='images/kosong.png'onMouseOver=this.src='images/kosong2.png' onClick=this.src='images/kosong.png' onMouseOut=this.src='images/kosong.png'></a>";}
					else
					{ echo "<img src='images/penuh.png'>"; } ?></td>
			<td><?php if($dataMasa['ptg2']=='x')
					{	$masa = "2:00PTG"; 
					echo "<a href='tempah_maklumat.php?tarikhMula=$tarikh&tarikhAsal=$tarikhMula&tarikhAkhir=$tarikhAkhir&aras=$aras&noBilik=$bilikNo&masa=$masa'><img src='images/kosong.png' onMouseOver=this.src='images/kosong2.png' onClick=this.src='images/kosong.png' onMouseOut=this.src='images/kosong.png'></a>";}
					else
					{ echo "<img src='images/penuh.png'>"; } ?></td>
			<td><?php if($dataMasa['ptg3']=='x')
					{	$masa = "3:00PTG";
					echo "<a href='tempah_maklumat.php?tarikhMula=$tarikh&tarikhAsal=$tarikhMula&tarikhAkhir=$tarikhAkhir&aras=$aras&noBilik=$bilikNo&masa=$masa'><img src='images/kosong.png' onMouseOver=this.src='images/kosong2.png' onClick=this.src='images/kosong.png' onMouseOut=this.src='images/kosong.png'></a>";}
					else
					{ echo "<img src='images/penuh.png'>"; } ?></td>
			<td><?php if($dataMasa['ptg4']=='x')
					{	$masa = "4:00PTG"; 
					echo "<a href='tempah_maklumat.php?tarikhMula=$tarikh&tarikhAsal=$tarikhMula&tarikhAkhir=$tarikhAkhir&aras=$aras&noBilik=$bilikNo&masa=$masa'><img src='images/kosong.png'></a>";}
					else
					{ echo "<img src='images/penuh.png'>"; } ?></td>
			
          </tr>
        <?php 
		}
		?>
      </font>
      </table>
  <?php 
	}
  else
  {}
   ?>  
      
      <p><div id="respond">
	  <p align = "center">
	  <a href="index.php"><input name="submit" type="submit" id="submit" value="Kembali" /></a>
      </p></div>
      </p>
    </font>
    </div>
    <br class="clear" />
</div>



<!-- #################################################TUTUP BODY###################################################### -->
<!-- #####################################################SPACE################################################## -->
<div id="adblock">
<br class="clear" />
</div>
<!-- #################################################TUTUP SPACE###################################################### -->

<!-- ##############################################BOTTOM######################################################### -->
<?php include '../footer.php';?>
<!-- ##############################################TUTuP BOTTOM######################################################### -->
</body>
<script type="text/javascript" src="datetimepicker-master/jquery.js"></script>
<script type="text/javascript" src="datetimepicker-master/jquery.datetimepicker.js"></script>
<script type="text/javascript">
$('#datetimepicker2').datetimepicker({
	yearOffset:0,
	lang:'ml',
	timepicker:false,
	format:'Y-m-d',
	formatDate:'Y/m/d',
	minDate:'-2000/01/02', // yesterday is minimum date
	maxDate:'+2020/01/02' // and tommorow is maximum date calendar
});
</script>
</html>
<?php
}
?>
