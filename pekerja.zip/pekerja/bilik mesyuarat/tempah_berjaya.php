<?php
	session_start();
	$nama = $_SESSION['nama'];
	$noStaff = $_SESSION['noStaff'];
	$jawatan = $_SESSION['jawatan'];
	$tarikhMula=$_GET['tarikhMula'];
	$aras = $_GET['aras'];
	$noBilik = $_GET['noBilik'];
	$tujuan = $_GET['tujuan'];
	$masaMula = $_GET['masaMula'];
	$masaAkhir = $_GET['masaAkhir'];
	$lcd = $_GET['lcd'];
	
	if(!$_SESSION['register'])
		header('Location:../index.php');
	
	else
	{
		include '../penghubung/penghubung.php';
		
		$pekerja = "select * from pekerja where pekerjaID = '$noStaff'";
		$qPekerja = mysql_query($pekerja) or die (mysql_error());
		$dataPekerja = mysql_fetch_array($qPekerja);
		
		$bilik = "select * from bilik where bilikNo = '$noBilik'";
		$qBilik = mysql_query($bilik) or die (mysql_error());
		$dataBilik = mysql_fetch_array($qBilik);
		
?>

<!DOCTYPE >
<html xml:lang="EN" lang="EN" dir="ltr">
<head>
<title>Sistem Tempahan</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<link rel="stylesheet" type="text/css" href="datetimepicker-master/jquery.datetimepicker.css"/>
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="scripts/jquery.timers.1.2.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.2.1.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.setup.js"></script>


</head>
<body id="top">
<!-- ########################################HEADER############################################################### -->
<?php include'../header.php';?>

<!-- ##################################################TUTUP LOGO##################################################### -->

<!-- #################################################MENU###################################################### -->
<?php include'menu.php';?>
<!-- #####################################################TUTUP MENU################################################## -->
<!-- ##################################################MAKLUMAT PENGUNA##################################################### -->
<div class="wrapper">
  <div class="container">
 <?php include'tajuk_tempah_bilik_mesyuarat.php';?>
 <?php include'maklumat_diri.php';?>
  </div>
</div>
<!-- #################################################TUTUP MAKLUMAT PENGGUNA###################################################### -->
<!-- ###############################################BODY######################################################## -->
<div class="wrapper">
<div class="container">
<font face="Arial, Helvetica, sans-serif" size="+1">
  <h2>Maklumat Tempahan</h2>
  	Nama: <a><?php echo $nama;?></a><br />
    Nombor Staf: <a><?php echo $noStaff;?></a><br />
    Jabatan: <a><?php echo $dataPekerja['pekerjaJabatan'];?></a><br />
	Tarikh: <a><?php echo $tarikhMula;?></a><br />
	Tujuan: <a><?php echo $tujuan;?></a><br />
	Nama Bilik: <a><?php echo $dataBilik['bilikNama'];?></a><br />
	Masa Mula: <a><?php echo $masaMula;?></a><br />
	Masa Akhir: <a><?php echo $masaAkhir;?></a><br />
	Pinjaman LCD: <a><?php echo $lcd;?></a><br />
    <br />
    <br />
    </font>
    <font face="Arial, Helvetica, sans-serif" color="#FF0000">
        <h3>Kemaskini Tempahan Berjaya!</h3>
      </font>
    </div>
    <br class="clear" />
</div>
<!-- #################################################TUTUP BODY###################################################### -->

<!-- #################################################TUTUP SPACE###################################################### -->

<!-- ##############################################BOTTOM######################################################### -->
<?php include'../footer.php';?>
<!-- ##############################################TUTuP BOTTOM######################################################### -->
</body>
</html>
<?php
}
?>