<!-- ###############################################BODY######################################################## -->
<div class="wrapper">
  <div id="adblock">
  <p align="center">
  <font face="Arial, Helvetica, sans-serif">Anda hanya perlu klik pada gambar dibawah untuk tempahan atau melihat
  kekosongan bilik untuk ditempahan.</font></p>
    <div class="fl_left"><a href="bilik makmal/index.php"><img src="images/makmal1.png"  onmouseover="this.src='images/makmal2.png'" onmouseout="this.src='images/makmal1.png'" onclick="this.src='images/makmal1.png'" /></a>
    </div>
    
    <div class="fl_right"><a href="bilik mesyuarat/index.php"><img src="images/mesyuarat1.png"  onmouseover="this.src='images/mesyuarat2.png'" onmouseout="this.src='images/mesyuarat1.png'" onclick="this.src='images/mesyuarat1.png'" /></a>
    </div>
    <br class="clear" />
  </div>
<!-- #################################################TUTUP BODY###################################################### -->