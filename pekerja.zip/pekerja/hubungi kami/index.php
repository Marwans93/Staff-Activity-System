<?php
	session_start();
	$nama = $_SESSION['nama'];
	$noStaff = $_SESSION['noStaff'];
	$jawatan = $_SESSION['jawatan'];
	$status = "";
	$paparStatus = "";
	
	if(!$_SESSION['register'])
		header('Location:../index.php');
	
	else
	{
		include '../penghubung/penghubung.php';
		
		
		
	if(isset($_GET['status']))
	{
	$status = $_GET['status'];
	}
	else
	{$status ="";}
	
	if(!$status == "")
		{
			if($status =="ts")
			{$paparStatus = "<font face='Arial, Helvetica, sans-serif' size='2' color='red'>Mesej Kosong!</font>";}
			else
			{$paparStatus = "&nbsp;"; }
		}
	else
	{$paparStatus = "&nbsp;"; }
		
?>

<!DOCTYPE>
<html xml:lang="EN" lang="EN" dir="ltr">
<head>
<title>Sistem Tempahan</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="scripts/jquery.timers.1.2.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.2.1.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.setup.js"></script>
</head>
<body id="top">
<!-- ########################################HEADER############################################################### -->
<?php include '../header.php';?>

<!-- ##################################################TUTUP LOGO##################################################### -->

<!-- #################################################MENU###################################################### -->
<?php include 'menu.php';?>
<!-- #####################################################TUTUP MENU################################################## -->
<!-- ##################################################MAKLUMAT PENGUNA##################################################### -->
<div class="wrapper">
  <div class="container">
  <?php include 'tajuk_laman_hubungi_kami.php';?>
 <?php include 'maklumat_diri.php';?>
  </div>
</div>
<!-- ##########################################TUTUP MAKLUMAT PENGGUNA###################################################### -->
<!-- ###############################################BODY######################################################## -->
<?php

//SQL untuk papar email
	$pekerja = "select * from pekerja where pekerjaID = '$noStaff'";
	$queryPekerja = mysql_query($pekerja) or die (mysql_error());
	$dataPekerja = mysql_fetch_array($queryPekerja);
?>
<div class="wrapper">
<div class="container">
<br>
<font face="Arial, Helvetica, sans-serif">
  <h2>Hubungi Kami</h2><?php echo $paparStatus;?>
      <div id="respond">
        <form action="hubungi_kami_hantar.php" method="post" name="hantar">
          <p>
            <input type="text" name="nama" id="name" value="<?php echo $nama;?>" size="100" />
            <label for="Nama"><small>Nama</small></label>
          </p>
          <p>
            <input type="text" name="email" id="email" value="<?php echo $dataPekerja['pekerjaEmail']?>" size="100" />
            <label for="Email"><small>Email</small></label>
          </p>
          <p>
            <textarea name="soalan" id="comment" cols="100%" rows="10"></textarea>
            <label for="Soalan" style="display:none;"><small>Soalan</small></label>
          </p>
          <p>
            <a><input name="submit" type="submit" id="submit" value="Hantar" /></a>
            &nbsp;
            <input name="reset" type="reset" id="reset" tabindex="5" value="Padam Semua" />
          </p>
        </form>
      </div>
      </font>
    </div>
    <br class="clear" />
</div>
<!-- #################################################TUTUP BODY###################################################### -->
<!-- #####################################################SPACE################################################## -->
<div id="adblock">
<br class="clear" />
</div>
<!-- #################################################TUTUP SPACE###################################################### -->

<!-- ##############################################BOTTOM######################################################### -->
<?php include '../footer.php';?>
<!-- ##############################################TUTuP BOTTOM######################################################### -->
</body>
</html>
<?php

}
?>
