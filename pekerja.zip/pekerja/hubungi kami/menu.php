<!-- #################################################MENU###################################################### -->
<div class="wrapper col2">
  <div id="topbar">
  <font face="Arial, Helvetica, sans-serif">
    <div id="topnav">
      <ul>
        <li><a href="../index.php">Utama</a></li>
        <li ><a href="../lihat biodata/index.php">Lihat Biodata</a></li>
        <li><a href="">Tempahan Bilik</a>
          <ul>
            <li ><a href="../bilik makmal/index.php">Bilik Makmal</a></li>
            <li><a href="../bilik mesyuarat/index.php">Bilik Mesyuarat</a></li>
          </ul>
        </li>
        <li class="active" ><a href="index.php">Hubungi Kami</a></li>
      </ul>
    </div>
    </font>
    <br class="clear" />
  </div>
</div>
<!-- #################################################TUTUP MENU###################################################### -->