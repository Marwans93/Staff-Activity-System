<?php
	session_start();
	$nama = $_SESSION['nama'];
	$noStaff = $_SESSION['noStaff'];
	$jawatan = $_SESSION['jawatan'];
	$soalanSemak = "";
		
	if(!$_SESSION['register'])
		header('Location:../index.php');
	
	else
	{
		
		include '../penghubung/penghubung.php';
		
		
		if(isset($_REQUEST['soalan']))
		{ $soalanSemak = $_REQUEST['soalan']; }
		else
		{ $soalanSemak = "";}
		
		if(!$soalanSemak == "")
		{
			$namaHubungi = $_POST['nama'];
			$emailHubungi = $_POST['email'];
			$mesejHubungi = $_POST['soalan'];
	
		
			$hubungi = "select * from hubungikami";
			$qHubungi= mysql_query($hubungi) or die (mysql_error());
			$row = mysql_num_rows($qHubungi);
		
			$hubungiNo = $row + 1;
			$status = "Belum";
		
			$tambahHubungi = "insert into hubungikami values ('$hubungiNo','$namaHubungi','$emailHubungi','$mesejHubungi','$status')";
			mysql_query($tambahHubungi) or die(mysql_error());
		}
		elseif($soalanSemak == "")	
		{	$status = "ts";
			 header ("Location: index.php?status=$status");
		}
		
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<title>Sistem Tempahan</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="scripts/jquery.timers.1.2.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.2.1.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.setup.js"></script>
</head>
<body id="top">
<!-- ########################################HEADER############################################################### -->
<div class="wrapper col0">
  <div id="topline">
    <p><font face="Arial, Helvetica, sans-serif">Log Masuk Sebagai: Pekerja | </font></p>
   <!-- <ul>
      <li><a href="#">Libero</a></li>
      <li><a href="#">Maecenas</a></li>
      <li><a href="#">Mauris</a></li>
      <li class="last"><a href="#">Suspendisse</a></li>
    </ul>-->
    <br class="clear" />
  </div>
</div>
<!-- ###############################################TUTUP HEADER######################################################## -->
<!-- #############################################LOGO########################################################## -->
<div class="wrapper">
  <div id="header">
    <div class="fl_left">
      <h1><a href="#"><strong>S</strong>istem <strong>T</strong>empahan</a></h1>
      <p>Bilik Makmal & Bilik Mesyuarat</p>
    </div>
    <div class="fl_right"><a href="#"><img src="images/LOGO.png" alt="" /></a></div>
    <br class="clear" />
  </div>
</div>

<!-- ##################################################TUTUP LOGO##################################################### -->

<!-- #################################################MENU###################################################### -->
<div class="wrapper col2">
  <div id="topbar">
  <font face="Arial, Helvetica, sans-serif">
    <div id="topnav">
      <ul>
        <li><a href="../index.php">Utama</a></li>
        <li><a href="../lihat biodata/lihat_biodata.php">Lihat Biodata</a></li>
        <li><a href="#">Tempahan Bilik</a>
          <ul>
            <li><a href="../bilik makmal/bilik_makmal.php">Bilik Makmal</a></li>
            <li><a href="../bilik mesyuarat/bilik_mesyuarat.php">Bilik Mesyuarat</a></li>
          </ul>
        </li>
        <li class="active"><a href="hubungi_kami.php">Hubungi Kami</a></li>
      </ul>
    </div>
    </font>
    <br class="clear" />
  </div>
</div>
<!-- #####################################################TUTUP MENU################################################## -->
<!-- ##################################################MAKLUMAT PENGUNA##################################################### -->
<div class="wrapper">
  <div class="container">
  <font face="Arial, Helvetica, sans-serif" size="+6">
  Laman Hubungi Kami</font>
  <div class="column">
    <font face="Arial, Helvetica, sans-serif" size="-1">
     <?php
		$gambar = "select * from gambar where gambarPenggunaID = '$noStaff'";
		$qGambar = mysql_query($gambar) or die (mysql_error());
		$dataGambar = mysql_fetch_array($qGambar);
	?>
    <table border="5">
    <tr>
    	<th colspan="2" align="center" bgcolor="#CCCCCC">Maklumat Pengguna</th>
    </tr>
    <tr>
    	<td width="100" height="130"><img src="../<?php echo $dataGambar['gambarAlamat'];?>" width="100" height="130" /></td>
       <td>Nama: <?php echo $nama;?>
        	<br /> No. Staff: <?php echo $noStaff;?>
			<br><br><br><br><br>
			<a href="../proses_log_keluar.php">[LOG KELUAR]</a>
        </td>
    </tr>
    
    </table> </font>
    </div>
    <br class="clear" />
  </div>
</div>
<!-- ##########################################TUTUP MAKLUMAT PENGGUNA###################################################### -->
<!-- ###############################################BODY######################################################## -->
<div class="wrapper">
<div class="container">
<font face="Arial, Helvetica, sans-serif">
  <h2>Hubungi Kami</h2>
  	Nama: <?php echo $namaHubungi;?><br />
    Email: <?php echo $emailHubungi;?><br />
    Mesej: <?php echo $mesejHubungi;?><br />
    <br />
    <br />
    </font>
    <font face="Arial, Helvetica, sans-serif" color="#FF0000">
        <h3>Sedang diproses!</h3>
      </font>
    </div>
    <br class="clear" />
</div>
<!-- #################################################TUTUP BODY###################################################### -->
<!-- #####################################################SPACE################################################## -->
<div id="adblock">
<br class="clear" />
</div>
<!-- #################################################TUTUP SPACE###################################################### -->

<!-- ##############################################BOTTOM######################################################### -->
<br class="clear" />
<div class="wrapper col8">
  <div id="copyright">
  <font size="-3" face="Arial, Helvetica, sans-serif">
    <p class="fl_left">Copyright &copy; Jun 2014 - Sept 2014 - All Rights Reserved - <a>PKINK</a></p>
    <p class="fl_right">Dibina oleh : <a>Pelajar Latihan Industri UiTM</a></p>
    </font>
    <br class="clear" />
  </div>
</div>
<!-- ##############################################TUTuP BOTTOM######################################################### -->
</body>
</html>
<?php
}
?>
