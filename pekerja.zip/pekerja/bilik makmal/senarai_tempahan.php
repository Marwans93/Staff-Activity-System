<?php
	session_start();
	$nama = $_SESSION['nama'];
	$noStaff = $_SESSION['noStaff'];
	$jawatan = $_SESSION['jawatan'];
	
	if(!$_SESSION['register'])
		{	header('Location:../index.php');}
	
	else
	{
		include '../penghubung/penghubung.php';

		$status = "";
	
		if(isset($_GET['status']))
		{ $status = $_GET['status'];}
		else
		{ $status = "";}
	
		if(!$status =="")
		{
			if($status == "kb")
			{	$paparStatus = "<font face='Arial, Helvetica, sans-serif' color='Green' size='3'>Kemaskini Berjaya!</font>";}
			elseif($status == "ttd")
			{ $paparStatus = "<font face='Arial, Helvetica, sans-serif' color='red' size='3'>Tempahan Telah Dibatalkan!</font>";}
		}
		else{	$paparStatus="&nbsp;";}
	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xml:lang="EN" lang="EN" dir="ltr">
<head>
<title>Sistem Tempahan</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="scripts/jquery.timers.1.2.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.2.1.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.setup.js"></script>




</head>
<body id="top">
<!-- ########################################HEADER############################################################### -->
<?php include '../header.php';?>
<!-- ##################################################TUTUP LOGO##################################################### -->

<!-- #################################################MENU###################################################### -->
<?php include 'menu.php';?>
<!-- #####################################################TUTUP MENU################################################## -->
<!-- ##################################################MAKLUMAT PENGUNA##################################################### -->
<div class="wrapper">
  <div class="container">
  <?php include 'tajuk_laman_makmal.php'; ?>
  <?php include 'maklumat_diri.php';?>
  </div>
</div>
<!-- #################################################TUTUP MAKLUMAT PENGGUNA###################################################### -->
<!-- ###############################################BODY######################################################## -->
<div class="wrapper">
<div class="container">

	<div align="center">
	<?php echo $paparStatus; ?>
	</div>
	
	<br>
<font face="Arial, Helvetica, sans-serif">
  <table cellpadding="0" cellspacing="0" border="1">
        <thead>
          <tr>
            <th width="1%"><font face="Arial, sans-serif" color=#00000 size="2">Bil.</font></th>
			<th width="30%"><font face="Arial, sans-serif" color=#00000 size="2">Tujuan</font></th>
			<th width="10%"><font face="Arial, sans-serif" color=#00000 size="2">Tarikh</font></th>
			<th width="10%" ><font face="Arial, sans-serif" color=#00000 size="2">Masa Mula</font></th>
			<th width="10%" ><font face="Arial, sans-serif" color=#00000 size="2">Masa Akhir</font></th>
			<th width="20%" ><font face="Arial, sans-serif" color=#00000 size="2">Nama Bilik Makmal</font></th>
			<th width="10%" ><font face="Arial, sans-serif" color=#00000 size="2">Aras</font></th>
			<th width="9%" ><font face="Arial, sans-serif" color=#00000 size="2">Tindakan</font></th>
          </tr>
        </thead>
        <tbody>
       <?php 

		$bil = 1;
		$jenisTempahan = 'Bilik Makmal';
		$tempahan = "select * from tempahan where tempahanID =  '$noStaff' and tempahanJenis = '$jenisTempahan' order by tempahanTarikh";
		$qTempahan = mysql_query($tempahan) or die (mysql_error());

		while($dataTempahan = mysql_fetch_array($qTempahan))
		{	
			$noTempahan = $dataTempahan['tempahanNo'];
			
			$tempahanBilik = "select * from tempahanBilik where tempahanNo =  '$noTempahan'";
			$qTempahanBilik = mysql_query($tempahanBilik) or die (mysql_error());
			$dataTempahanBilik = mysql_fetch_array($qTempahanBilik);
			
			$noBilik = $dataTempahanBilik['bilikNo'];
			
			$bilik = "select * from bilik where bilikNo =  '$noBilik'";
			$qBilik = mysql_query($bilik) or die (mysql_error());
			$dataBilik = mysql_fetch_array($qBilik);
	   ?>
          <tr>
            <td><font face="Arial, sans-serif" size="2"><?php echo $bil++?></font></td>
            <td><font face="Arial, sans-serif" size="2"><?php echo $dataTempahan['tempahanTujuan']; ?></font></td>
            <td><font face="Arial, sans-serif" size="2"><?php echo $dataTempahan['tempahanTarikh']; ?></font></td>
			<td><font face="Arial, sans-serif" size="2"><?php echo $dataTempahan['tempahanMula']; ?></font></td>
			<td><font face="Arial, sans-serif" size="2"><?php echo $dataTempahan['tempahanAkhir']; ?></font></td>
			<td><font face="Arial, sans-serif" size="2"><?php echo $dataBilik['bilikNama']; ?></font></td>
			<td><font face="Arial, sans-serif" size="2"><?php echo $dataBilik['bilikAras']; ?></font></td>
			<td><div id="respond">
				<a href="kemaskini_tempahan.php?noTempahan=<?php echo $dataTempahan['tempahanNo']; ?>"><input type="button" id="submit" value="Kemaskini" /></a></div></td>
		<?php
		}
		?>			
          </tr>
        </tbody>
      </table>
      <p><div id="respond">
	  <p align = "center">
	  <a href="index.php"><input name="submit" type="submit" id="submit" value="Kembali" /></a>
      </p></div>
      </p>
    </font>
    </div>
    <br class="clear" />
</div>
<!-- #################################################TUTUP BODY###################################################### -->
<!-- #####################################################SPACE################################################## -->
<div id="adblock">
<br class="clear" />
</div>
<!-- #################################################TUTUP SPACE###################################################### -->
<!-- ##############################################BOTTOM######################################################### -->
<?php include '../footer.php';?>
<!-- ##############################################TUTuP BOTTOM######################################################### -->
</body>
</html>
<?php
}
?>
