<?php
	$noTempahan = $_POST['noTempahan'];
	$nama = $_POST['nama'];
	$noStaff = $_POST['noStaff'];
	$jabatan = $_POST['jabatan'];
	$tarikhMula = $_POST['tarikhMula'];
	$masaMula = $_POST['masaMula'];
	$masaAkhir = $_POST['masaAkhir'];
	$pinjamanLCD = $_POST['pinjamanLCD'];
	$namaBilik = $_POST['namaBilik'];
	$aras = $_POST['aras'];
	$tujuan = $_POST['tujuan'];
	$tempahanJenis = "Bilik Makmal";
	$masaMulaLama = $_POST['masaMulaLama'];
	$masaAkhirLama = $_POST['masaAkhirLama'];
	$noBilik = $_POST['noBilik'];
	
	include '../penghubung/penghubung.php';

	$tempahan = "update tempahan 
				set tempahanTarikh = '$tarikhMula', 
					tempahanJenis = '$tempahanJenis',
					tempahanID = '$noStaff',
					tempahanMula = '$masaMula',
					tempahanAkhir = '$masaAkhir',
					tempahanTujuan = '$tujuan',
					tempahanLCD = '$pinjamanLCD'
				where tempahanNo = '$noTempahan'";
	
	mysql_query($tempahan) or die(mysql_error());
		
		
	$tempahanBilik = "update tempahanbilik 
						set bilikNo = '$noBilik' 
						where tempahanBilikId = '$noTempahan' and tempahanNo = '$noTempahan' ";
	
	mysql_query($tempahanBilik) or die(mysql_error());
	
	
	
	//######################################################################################################
	
		if($masaAkhir=='9:00PG')
	{
		if($masaMula=='8:00PG')
		{
			$masa = "update masa
					set	pg8 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		
	}	
	
	elseif($masaAkhir=="5:00PTG")
	{
		if($masaMula=="8:00PG")
		{
			$masa = "update masa
					set	pg8 = 't',
						pg9 = 't',
						pg10 = 't',
						pg11 = 't',
						ptg12 = 't',
						ptg1 = 't',
						ptg2 = 't',
						ptg3 = 't',
						ptg4 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="9:00PG")
		{
			$masa = "update masa
					set	pg9 = 't',
						pg10 = 't',
						pg11 = 't',
						ptg12 = 't',
						ptg1 = 't',
						ptg2 = 't',
						ptg3 = 't',
						ptg4 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="10:00PG")
		{
			$masa = "update masa
					set	pg10 = 't',
						pg11 = 't',
						ptg12 = 't',
						ptg1 = 't',
						ptg2 = 't',
						ptg3 = 't',
						ptg4 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="11:00PG")
		{
			$masa = "update masa
					set	pg11 = 't',
						ptg12 = 't',
						ptg1 = 't',
						ptg2 = 't',
						ptg3 = 't',
						ptg4 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="12:00PTG")
		{
			$masa = "update masa
					set	ptg12 = 't',
						ptg1 = 't',
						ptg2 = 't',
						ptg3 = 't',
						ptg4 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="1:00PTG")
		{
			$masa = "update masa
					set	ptg1 = 't',
						ptg2 = 't',
						ptg3 = 't',
						ptg4 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="2:00PTG")
		{
			$masa = "update masa
					set	ptg2 = 't',
						ptg3 = 't',
						ptg4 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="3:00PTG")
		{
			$masa = "update masa
					set ptg3 = 't',
						ptg4 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="4:00PTG")
		{
			$masa = "update masa
					set ptg4 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
	}
	
	//######################################################
	
	elseif($masaAkhir=="4:00PTG")
	{
		if($masaMula=="8:00PG")
		{
			$masa = "update masa
					set	pg8 = 't',
						pg9 = 't',
						pg10 = 't',
						pg11 = 't',
						ptg12 = 't',
						ptg1 = 't',
						ptg2 = 't',
						ptg3 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="9:00PG")
		{
			$masa = "update masa
					set	pg9 = 't',
						pg10 = 't',
						pg11 = 't',
						ptg12 = 't',
						ptg1 = 't',
						ptg2 = 't',
						ptg3 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="10:00PG")
		{
			$masa = "update masa
					set	pg10 = 't',
						pg11 = 't',
						ptg12 = 't',
						ptg1 = 't',
						ptg2 = 't',
						ptg3 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="11:00PG")
		{
			$masa = "update masa
					set	pg11 = 't',
						ptg12 = 't',
						ptg1 = 't',
						ptg2 = 't',
						ptg3 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="12:00PTG")
		{
			$masa = "update masa
					set	ptg12 = 't',
						ptg1 = 't',
						ptg2 = 't',
						ptg3 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="1:00PTG")
		{
			$masa = "update masa
					set	ptg1 = 't',
						ptg2 = 't',
						ptg3 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="2:00PTG")
		{
			$masa = "update masa
					set	ptg2 = 't',
						ptg3 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="3:00PTG")
		{
			$masa = "update masa
					set ptg3 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
	}
	
	//############################################################################
	
	elseif($masaAkhir=="3:00PTG")
	{
		if($masaMula=="8:00PG")
		{
			$masa = "update masa
					set	pg8 = 't',
						pg9 = 't',
						pg10 = 't',
						pg11 = 't',
						ptg12 = 't',
						ptg1 = 't',
						ptg2 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="9:00PG")
		{
			$masa = "update masa
					set	pg9 = 't',
						pg10 = 't',
						pg11 = 't',
						ptg12 = 't',
						ptg1 = 't',
						ptg2 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="10:00PG")
		{
			$masa = "update masa
					set	pg10 = 't',
						pg11 = 't',
						ptg12 = 't',
						ptg1 = 't',
						ptg2 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="11:00PG")
		{
			$masa = "update masa
					set	pg11 = 't',
						ptg12 = 't',
						ptg1 = 't',
						ptg2 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="12:00PTG")
		{
			$masa = "update masa
					set	ptg12 = 't',
						ptg1 = 't',
						ptg2 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="1:00PTG")
		{
			$masa = "update masa
					set	ptg1 = 't',
						ptg2 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="2:00PTG")
		{
			$masa = "update masa
					set	ptg2 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		
	}
		
		//###################################################################
		
		elseif($masaAkhir=="2:00PTG")
	{
		if($masaMula=="8:00PG")
		{
			$masa = "update masa
					set	pg8 = 't',
						pg9 = 't',
						pg10 = 't',
						pg11 = 't',
						ptg12 = 't',
						ptg1 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="9:00PG")
		{
			$masa = "update masa
					set	pg9 = 't',
						pg10 = 't',
						pg11 = 't',
						ptg12 = 't',
						ptg1 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="10:00PG")
		{
		
			$masa = "update masa
					set	pg10 = 't',
						pg11 = 't',
						ptg12 = 't',
						ptg1 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="11:00PG")
		{
			$masa = "update masa
					set	pg11 = 't',
						ptg12 = 't',
						ptg1 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="12:00PTG")
		{
			$masa = "update masa
					set	ptg12 = 't',
						ptg1 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="1:00PTG")
		{
			$masa = "update masa
					set	ptg1 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		
	}
		
		
		//###################################################################
		
		
		
		elseif($masaAkhir=="1:00PTG")
	{
		if($masaMula=="8:00PG")
		{
			$masa = "update masa
					set	pg8 = 't',
						pg9 = 't',
						pg10 = 't',
						pg11 = 't',
						ptg12 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="9:00PG")
		{
			$masa = "update masa
					set	pg9 = 't',
						pg10 = 't',
						pg11 = 't',
						ptg12 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="10:00PG")
		{
			$masa = "update masa
					set	pg10 = 't',
						pg11 = 't',
						ptg12 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="11:00PG")
		{
			$masa = "update masa
					set	pg11 = 't',
						ptg12 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="12:00PTG")
		{
			$masa = "update masa
					set	ptg12 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		
	}
		
		
		
		
		
		//###################################################################
		
		
		
		elseif($masaAkhir=="12:00PTG")
	{
		if($masaMula=="8:00PG")
		{
			$masa = "update masa
					set	pg8 = 't',
						pg9 = 't',
						pg10 = 't',
						pg11 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="9:00PG")
		{
			$masa = "update masa
					set	pg9 = 't',
						pg10 = 't',
						pg11 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="10:00PG")
		{
			$masa = "update masa
					set	pg10 = 't',
						pg11 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="11:00PG")
		{
			$masa = "update masa
					set	pg11 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		
	}
		
		
		
		//###################################################################
		
		
		
		elseif($masaAkhir=="11:00PG")
	{
		if($masaMula=="8:00PG")
		{
			$masa = "update masa
					set	pg8 = 't',
						pg9 = 't',
						pg10 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="9:00PG")
		{
			$masa = "update masa
					set	pg9 = 't',
						pg10 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="10:00PG")
		{
			$masa = "update masa
					set	pg10 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		
	}
		
		
		
		
		
		//###################################################################
		
		
		elseif($masaAkhir=="10:00PG")
	{
		if($masaMula=="8:00PG")
		{
			$masa = "update masa
					set	pg8 = 't',
						pg9 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="9:00PG")
		{
			$masa = "update masa
					set	pg9 = 't'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		
	}
		
		
		
		//###################################################################
		
		
	
		mysql_query($masa) or die(mysql_error());
	
	
	
	
	
	
	$status= "kb";
	
	header("Location:senarai_tempahan.php?status=$status");

	
	
	?>