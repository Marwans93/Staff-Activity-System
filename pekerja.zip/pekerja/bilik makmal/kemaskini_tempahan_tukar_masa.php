<?php
	session_start();
	$nama = $_SESSION['nama'];
	$noStaff = $_SESSION['noStaff'];
	$jawatan = $_SESSION['jawatan'];

	
	if(!$_SESSION['register'])
		header('Location:../index.php');
	
	else
	{
		
		include '../penghubung/penghubung.php';
		
		$aras = $_GET['aras'];
		$bilikNo = $_GET['noBilik'];
		$tarikhMula = $_GET['tarikhMula'];
		$noTempahan = $_GET['noTempahan'];
		$masaMulaLama = $_GET['masaMula'];
		$masaAkhirLama = $_GET['masaAkhir'];
		
		
		$noBilik = $bilikNo;
	
	//################# Start Masa ###################################
	
	//###########################################buka 9pg###########################################################
	
		if($masaAkhirLama=='9:00PG')
	{
		if($masaMulaLama=='8:00PG')
		{
			$masaHapus = "update masa
					set	pg8 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		
	}	
//##########################tutup 9pg#########################################
//##########################buka 5ptg#########################################	
	elseif($masaAkhirLama=="5:00PTG")
	{
		if($masaMulaLama=="8:00PG")
		{
			$masaHapus = "update masa
					set	pg8 = 'x',
						pg9 = 'x',
						pg10 = 'x',
						pg11 = 'x',
						ptg12 = 'x',
						ptg1 = 'x',
						ptg2 = 'x',
						ptg3 = 'x',
						ptg4 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMulaLama=="9:00PG")
		{
			$masaHapus = "update masa
					set	pg9 = 'x',
						pg10 = 'x',
						pg11 = 'x',
						ptg12 = 'x',
						ptg1 = 'x',
						ptg2 = 'x',
						ptg3 = 'x',
						ptg4 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMulaLama=="10:00PG")
		{
			$masaHapus = "update masa
					set	pg10 = 'x',
						pg11 = 'x',
						ptg12 = 'x',
						ptg1 = 'x',
						ptg2 = 'x',
						ptg3 = 'x',
						ptg4 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMulaLama=="11:00PG")
		{
			$masaHapus = "update masa
					set	pg11 = 'x',
						ptg12 = 'x',
						ptg1 = 'x',
						ptg2 = 'x',
						ptg3 = 'x',
						ptg4 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMulaLama=="12:00PTG")
		{
			$masaHapus = "update masa
					set	ptg12 = 'x',
						ptg1 = 'x',
						ptg2 = 'x',
						ptg3 = 'x',
						ptg4 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMulaLama=="1:00PTG")
		{
			$masaHapus = "update masa
					set	ptg1 = 'x',
						ptg2 = 'x',
						ptg3 = 'x',
						ptg4 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMulaLama=="2:00PTG")
		{
			$masaHapus = "update masa
					set	ptg2 = 'x',
						ptg3 = 'x',
						ptg4 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMulaLama=="3:00PTG")
		{
			$masaHapus = "update masa
					set ptg3 = 'x',
						ptg4 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMulaLama=="4:00PTG")
		{
			$masaHapus = "update masa
					set ptg4 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
	}
	
//##########################tutup 5ptg############################
//##########################buka 4ptg#########################################
	elseif($masaAkhirLama=="4:00PTG")
	{
		if($masaMulaLama=="8:00PG")
		{
			$masaHapus = "update masa
					set	pg8 = 'x',
						pg9 = 'x',
						pg10 = 'x',
						pg11 = 'x',
						ptg12 = 'x',
						ptg1 = 'x',
						ptg2 = 'x',
						ptg3 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMulaLama=="9:00PG")
		{
			$masaHapus = "update masa
					set	pg9 = 'x',
						pg10 = 'x',
						pg11 = 'x',
						ptg12 = 'x',
						ptg1 = 'x',
						ptg2 = 'x',
						ptg3 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMulaLama=="10:00PG")
		{
			$masaHapus = "update masa
					set	pg10 = 'x',
						pg11 = 'x',
						ptg12 = 'x',
						ptg1 = 'x',
						ptg2 = 'x',
						ptg3 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMulaLama=="11:00PG")
		{
			$masaHapus = "update masa
					set	pg11 = 'x',
						ptg12 = 'x',
						ptg1 = 'x',
						ptg2 = 'x',
						ptg3 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMulaLama=="12:00PTG")
		{
			$masaHapus = "update masa
					set	ptg12 = 'x',
						ptg1 = 'x',
						ptg2 = 'x',
						ptg3 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMulaLama=="1:00PTG")
		{
			$masaHapus = "update masa
					set	ptg1 = 'x',
						ptg2 = 'x',
						ptg3 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMulaLama=="2:00PTG")
		{
			$masaHapus = "update masa
					set	ptg2 = 'x',
						ptg3 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMulaLama=="3:00PTG")
		{
			$masaHapus = "update masa
					set ptg3 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
	}
//##########################tutup 4ptg##################################################
//##########################buka 3ptg#########################################	
	elseif($masaAkhirLama=="3:00PTG")
	{
		if($masaMulaLama=="8:00PG")
		{
			$masaHapus = "update masa
					set	pg8 = 'x',
						pg9 = 'x',
						pg10 = 'x',
						pg11 = 'x',
						ptg12 = 'x',
						ptg1 = 'x',
						ptg2 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMulaLama=="9:00PG")
		{
			$masaHapus = "update masa
					set	pg9 = 'x',
						pg10 = 'x',
						pg11 = 'x',
						ptg12 = 'x',
						ptg1 = 'x',
						ptg2 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMulaLama=="10:00PG")
		{
			$masaHapus = "update masa
					set	pg10 = 'x',
						pg11 = 'x',
						ptg12 = 'x',
						ptg1 = 'x',
						ptg2 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMulaLama=="11:00PG")
		{
			$masaHapus = "update masa
					set	pg11 = 'x',
						ptg12 = 'x',
						ptg1 = 'x',
						ptg2 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMulaLama=="12:00PTG")
		{
			$masaHapus = "update masa
					set	ptg12 = 'x',
						ptg1 = 'x',
						ptg2 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMulaLama=="1:00PTG")
		{
			$masaHapus = "update masa
					set	ptg1 = 'x',
						ptg2 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMulaLama=="2:00PTG")
		{
			$masaHapus = "update masa
					set	ptg2 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		
	}
//##########################tutup 3ptg#########################################
//##########################buka 2ptg#########################################		
		elseif($masaAkhirLama=="2:00PTG")
	{
		if($masaMulaLama=="8:00PG")
		{
			$masaHapus = "update masa
					set	pg8 = 'x',
						pg9 = 'x',
						pg10 = 'x',
						pg11 = 'x',
						ptg12 = 'x',
						ptg1 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMulaLama=="9:00PG")
		{
			$masaHapus = "update masa
					set	pg9 = 'x',
						pg10 = 'x',
						pg11 = 'x',
						ptg12 = 'x',
						ptg1 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMulaLama=="10:00PG")
		{
		
			$masaHapus = "update masa
					set	pg10 = 'x',
						pg11 = 'x',
						ptg12 = 'x',
						ptg1 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMulaLama=="11:00PG")
		{
			$masaHapus = "update masa
					set	pg11 = 'x',
						ptg12 = 'x',
						ptg1 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMulaLama=="12:00PTG")
		{
			$masaHapus = "update masa
					set	ptg12 = 'x',
						ptg1 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMulaLama=="1:00PTG")
		{
			$masaHapus = "update masa
					set	ptg1 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		
	}
//##########################tutup 2ptg#########################################
//##########################buka 1ptg#########################################		
		elseif($masaAkhirLama=="1:00PTG")
	{
		if($masaMulaLama=="8:00PG")
		{
			$masaHapus = "update masa
					set	pg8 = 'x',
						pg9 = 'x',
						pg10 = 'x',
						pg11 = 'x',
						ptg12 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMulaLama=="9:00PG")
		{
			$masaHapus = "update masa
					set	pg9 = 'x',
						pg10 = 'x',
						pg11 = 'x',
						ptg12 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMulaLama=="10:00PG")
		{
			$masaHapus = "update masa
					set	pg10 = 'x',
						pg11 = 'x',
						ptg12 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMulaLama=="11:00PG")
		{
			$masaHapus = "update masa
					set	pg11 = 'x',
						ptg12 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMulaLama=="12:00PTG")
		{
			$masaHapus = "update masa
					set	ptg12 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		
	}
//##########################tutup 1ptg#########################################
//##########################buka 12ptg#########################################		
		elseif($masaAkhirLama=="12:00PTG")
	{
		if($masaMulaLama=="8:00PG")
		{
			$masaHapus = "update masa
					set	pg8 = 'x',
						pg9 = 'x',
						pg10 = 'x',
						pg11 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMulaLama=="9:00PG")
		{
			$masaHapus = "update masa
					set	pg9 = 'x',
						pg10 = 'x',
						pg11 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMulaLama=="10:00PG")
		{
			$masaHapus = "update masa
					set	pg10 = 'x',
						pg11 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMulaLama=="11:00PG")
		{
			$masaHapus = "update masa
					set	pg11 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		
	}
//##########################tutup 12ptg#########################################
//##########################buka 11pg#########################################		
		elseif($masaAkhirLama=="11:00PG")
	{
		if($masaMulaLama=="8:00PG")
		{
			$masaHapus = "update masa
					set	pg8 = 'x',
						pg9 = 'x',
						pg10 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMulaLama=="9:00PG")
		{
			$masaHapus = "update masa
					set	pg9 = 'x',
						pg10 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMulaLama=="10:00PG")
		{
			$masaHapus = "update masa
					set	pg10 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		
	}
//##########################tutup 11pg#########################################	
//##########################buka 10pg#########################################
		elseif($masaAkhirLama=="10:00PG")
	{
		if($masaMulaLama=="8:00PG")
		{
			$masaHapus = "update masa
					set	pg8 = 'x',
						pg9 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMulaLama=="9:00PG")
		{
			$masaHapus = "update masa
					set	pg9 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		
	}
//#########################tutup 10pg##########################################	
		mysql_query($masaHapus) or die(mysql_error());
	
	//#################tutup masa#####################################
	
	
	
	
	
	
	
?>

<!DOCTYPE>
<html xml:lang="EN" lang="EN" dir="ltr">
<head>
<title>Sistem Tempahan</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<link rel="stylesheet" type="text/css" href="datetimepicker-master/jquery.datetimepicker.css"/>
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="scripts/jquery.timers.1.2.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.2.1.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.setup.js"></script>


</head>
<body id="top">
<!-- ########################################HEADER############################################################### -->
<?php include'../header.php';?>

<!-- ##################################################TUTUP LOGO##################################################### -->

<!-- #################################################MENU###################################################### -->
<?php include'menu.php';?>
<!-- #####################################################TUTUP MENU################################################## -->
<!-- ##################################################MAKLUMAT PENGUNA##################################################### -->
<div class="wrapper">
  <div class="container">
 <?php include'tajuk_tempah_bilik_makmal.php';?>
<?php include'maklumat_diri.php';?>  </div>
</div>
<!-- #################################################TUTUP MAKLUMAT PENGGUNA###################################################### -->
<!-- ###############################################BODY######################################################## -->
<div class="wrapper">
<div class="container">


  <table summary="Summary Here" cellpadding="0" cellspacing="0" border="1">
        <thead>
          <tr>
            <th width ="11%"><font face="Arial, sans-serif" size="2">Tarikh</font></th>
			<th width="9.8%"><font face="Arial, sans-serif" size="2">8.00 PG</font></th>
			<th width="9.8%"><font face="Arial, sans-serif" size="2">9.00 PG</font></th>
			<th width="9.8%"><font face="Arial, sans-serif" size="2">10.00 PG</font></th>
			<th width="9.8%"><font face="Arial, sans-serif" size="2">11.00 PG</font></th>
			<th width="9.9%"><font face="Arial, sans-serif" size="2">12.00 PTG</font></th>
			<th width="9.8%"><font face="Arial, sans-serif" size="2">1.00 PTG</font></th>
			<th width="9.8%"><font face="Arial, sans-serif" size="2">2.00 PTG</font></th>
			<th width="9.9%"><font face="Arial, sans-serif" size="2">3.00 PTG</font></th>
			<th width="9.9%"><font face="Arial, sans-serif" size="2">4.00 PTG</font></th>
			</thead>
		  <tr> 
		  <?php
			
			$masa = "select * from masa where masaTarikh = '$tarikhMula' and masaBilikNo = '$bilikNo'";
			$qMasa = mysql_query($masa) or die (mysql_error());

		while($dataMasa = mysql_fetch_array($qMasa))
		  {
		  ?>
			<td><font face="Arial, sans-serif" size="2"><?php echo $dataMasa['masaTarikh']; ?></font></td>
			<td><?php if($dataMasa['pg8']=='x')
					{	$masa = "8:00PG"; 
					echo "<a href='kemaskini_tempahan_tukar_masa_tempah.php?noTempahan=$noTempahan&tarikhMula=$tarikhMula&aras=$aras&noBilik=$bilikNo&masa=$masa&masaMulaLama=$masaMulaLama&masaAkhirLama=$masaAkhirLama'><img src='images/kosong.png'></a>";}
					else
					{ echo "<img src='images/penuh.png'>"; } ?></td>
			<td><?php if($dataMasa['pg9']=='x')
					{ $masa = "9:00PG";
					echo "<a href='kemaskini_tempahan_tukar_masa_tempah.php?noTempahan=$noTempahan&tarikhMula=$tarikhMula&aras=$aras&noBilik=$bilikNo&masa=$masa&masaMulaLama=$masaMulaLama&masaAkhirLama=$masaAkhirLama'><img src='images/kosong.png'></a>";}
					else
					{ echo "<img src='images/penuh.png'>"; } ?></td>
			<td><?php if($dataMasa['pg10']=='x')
					{ $masa = "10:00PG";
					echo "<a href='kemaskini_tempahan_tukar_masa_tempah.php?noTempahan=$noTempahan&tarikhMula=$tarikhMula&aras=$aras&noBilik=$bilikNo&masa=$masa&masaMulaLama=$masaMulaLama&masaAkhirLama=$masaAkhirLama'><img src='images/kosong.png'></a>";}
					else
					{ echo "<img src='images/penuh.png'>"; } ?></td>
			<td><?php if($dataMasa['pg11']=='x')
					{	$masa = "11:00PG"; 
					echo "<a href='kemaskini_tempahan_tukar_masa_tempah.php?noTempahan=$noTempahan&tarikhMula=$tarikhMula&aras=$aras&noBilik=$bilikNo&masa=$masa&masaMulaLama=$masaMulaLama&masaAkhirLama=$masaAkhirLama'><img src='images/kosong.png'></a>";}
					else
					{ echo "<img src='images/penuh.png'>"; } ?></td>
			<td><?php if($dataMasa['ptg12']=='x')
					{	$masa = "12:00PTG";  
					echo "<a href='kemaskini_tempahan_tukar_masa_tempah.php?noTempahan=$noTempahan&tarikhMula=$tarikhMula&aras=$aras&noBilik=$bilikNo&masa=$masa&masaMulaLama=$masaMulaLama&masaAkhirLama=$masaAkhirLama'><img src='images/kosong.png'></a>";}
					else
					{ echo "<img src='images/penuh.png'>"; } ?></td>
			<td><?php if($dataMasa['ptg1']=='x')
					{	$masa = "1:00PTG"; 
					echo "<a href='kemaskini_tempahan_tukar_masa_tempah.php?noTempahan=$noTempahan&tarikhMula=$tarikhMula&aras=$aras&noBilik=$bilikNo&masa=$masa&masaMulaLama=$masaMulaLama&masaAkhirLama=$masaAkhirLama'><img src='images/kosong.png'></a>";}
					else
					{ echo "<img src='images/penuh.png'>"; } ?></td>
			<td><?php if($dataMasa['ptg2']=='x')
					{	$masa = "2:00PTG"; 
					echo "<a href='kemaskini_tempahan_tukar_masa_tempah.php?noTempahan=$noTempahan&tarikhMula=$tarikhMula&aras=$aras&noBilik=$bilikNo&masa=$masa&masaMulaLama=$masaMulaLama&masaAkhirLama=$masaAkhirLama'><img src='images/kosong.png'></a>";}
					else
					{ echo "<img src='images/penuh.png'>"; } ?></td>
			<td><?php if($dataMasa['ptg3']=='x')
					{	$masa = "3:00PTG";
					echo "<a href='kemaskini_tempahan_tukar_masa_tempah.php?noTempahan=$noTempahan&tarikhMula=$tarikhMula&aras=$aras&noBilik=$bilikNo&masa=$masa&masaMulaLama=$masaMulaLama&masaAkhirLama=$masaAkhirLama'><img src='images/kosong.png'></a>";}
					else
					{ echo "<img src='images/penuh.png'>"; } ?></td>
			<td><?php if($dataMasa['ptg4']=='x')
					{	$masa = "4:00PTG"; 
					echo "<a href='kemaskini_tempahan_tukar_masa_tempah.php?noTempahan=$noTempahan&tarikhMula=$tarikhMula&aras=$aras&noBilik=$bilikNo&masa=$masa&masaMulaLama=$masaMulaLama&masaAkhirLama=$masaAkhirLama'><img src='images/kosong.png'></a>";}
					else
					{ echo "<img src='images/penuh.png'>"; } ?></td>
			
          </tr>
        <?php 
		}
		?>
        <tbody>
        </tbody>
      </table>
      <p><div id="respond">
	  <p align = "center">
	  <a href="kemaskini_tempahan.php?noTempahanK=<?php echo $noTempahan;?>&tarikhMulaK=<?php echo $tarikhMula;?>&noBilikK=<?php echo $bilikNo;?>&masaMulaK=<?php echo $masaMulaLama;?>&masaAkhirK=<?php echo $masaAkhirLama;?>"><input name="submit" type="submit" id="submit" value="Kembali" /></a>
      </p></div>
      </p>

    </div>
    <br class="clear" />
</div>



<!-- #################################################TUTUP BODY###################################################### -->
<!-- #####################################################SPACE################################################## -->
<div id="adblock">
<br class="clear" />
</div>
<!-- #################################################TUTUP SPACE###################################################### -->

<!-- ##############################################BOTTOM######################################################### -->
<?php include'../footer.php';?>
<!-- ##############################################TUTuP BOTTOM######################################################### -->
</body>
<script type="text/javascript" src="datetimepicker-master/jquery.js"></script>
<script type="text/javascript" src="datetimepicker-master/jquery.datetimepicker.js"></script>
<script type="text/javascript">
$('#datetimepicker2').datetimepicker({
	yearOffset:0,
	lang:'ml',
	timepicker:false,
	format:'Y-m-d',
	formatDate:'Y/m/d',
	minDate:'-2000/01/02', // yesterday is minimum date
	maxDate:'+2020/01/02' // and tommorow is maximum date calendar
});
</script>
</html>
<?php
}
?>
