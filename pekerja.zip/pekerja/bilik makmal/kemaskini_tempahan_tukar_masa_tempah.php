<?php
	session_start();
	$nama = $_SESSION['nama'];
	$noStaff = $_SESSION['noStaff'];
	$jawatan = $_SESSION['jawatan'];
	$aras = $_GET['aras'];
	$bilikNo = $_GET['noBilik'];
	$tarikhMula = $_GET['tarikhMula'];
	$masa = $_GET['masa'];
	$noTempahan=$_GET['noTempahan'];
	$masaMulaLama = $_GET['masaMulaLama'];
	$masaAkhirLama = $_GET['masaAkhirLama'];
	
		
	
	if(!$_SESSION['register'])
		header('Location:../index.php');
	
	else
	{
		include '../penghubung/penghubung.php';
		
		
		$pekerja = "select * from pekerja where pekerjaID = '$noStaff'";
		$qPekerja = mysql_query($pekerja) or die (mysql_error());
		$dataPekerja = mysql_fetch_array($qPekerja);
		
		$bilik = "select * from bilik where bilikNo = '$bilikNo'";
		$qBilik = mysql_query($bilik) or die (mysql_error());
		$dataBilik = mysql_fetch_array($qBilik);
		
	
?>

<!DOCTYPE>
<html xml:lang="EN" lang="EN" dir="ltr">
<head>
<title>Sistem Tempahan</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="scripts/jquery.timers.1.2.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.2.1.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.setup.js"></script>




</head>
<body id="top">
<!-- ########################################HEADER############################################################### -->
<?php include '../header.php';?>

<!-- ##################################################TUTUP LOGO##################################################### -->

<!-- #################################################MENU###################################################### -->
<?php include'menu.php';?>
<!-- #####################################################TUTUP MENU################################################## -->
<!-- ##################################################MAKLUMAT PENGUNA##################################################### -->
<div class="wrapper">
  <div class="container">
 <?php include 'tajuk_tempah_bilik_makmal.php';?>
  <?php include 'maklumat_diri.php';?>
  </div>
</div>
<!-- #################################################TUTUP MAKLUMAT PENGGUNA###################################################### -->
<!-- ###############################################BODY######################################################## -->
<div class="wrapper">
<div class="container">
<form name="tempah" method="post" action="proses_kemaskini_tempahan.php">
<font face="Arial, Helvetica, sans-serif">
 <p align="center">
 Sila pilih masa akhir, pinjaman LCD dan nyatakan tujuan tempahan.
 </font>
 </p>
  <table summary="Summary Here" cellpadding="0" cellspacing="0">
        <thead>
          <tr>
            <th colspan=" 4"><font face="Arial, sans-serif" size="2">Tempahan</font></th>
            
          </tr>
        </thead>
        <tbody>
          
        <tr class="light">
            <td width="27%"><font face="Arial, sans-serif" size="2">Nama</font></td>
            <td width="1%">:</td>
            <td><input name="nama" value="<?php echo $nama; ?>" readonly size="130"></td>
		<tr class="dark">
            <td><font face="Arial, sans-serif" size="2">Nombor Staf</font></td>
            <td>:</td>
             <td><input name="noStaff" value="<?php echo $noStaff; ?>" readonly></td>
			<tr class="light">
            <td ><font face="Arial, sans-serif" size="2">Jabatan</font></td>
            <td >:</td>
            <td><input name="jabatan" value="<?php echo $dataPekerja['pekerjaJabatan']; ?>" readonly size="130"></td>
          <tr class="dark">
            <td><font face="Arial, sans-serif" size="2">Tarikh </font></td>
            <td>:</td>
			<td><input name="tarikhMula" value="<?php echo $tarikhMula; ?>" readonly></td>
          </tr>
          <tr class="light">
            <td><font face="Arial, sans-serif" size="2">Masa Mula</font></td>
            <td>:</td>
            <td><input name="masaMula" value="<?php echo $masa; ?>" readonly></td>
          </tr>
          <tr class="dark">
            <td><font face="Arial, sans-serif" size="2">Masa Akhir</font></td>
            <td>:</td>
          <td>
			<select name="masaAkhir" required />
			<option selected ><font face="Arial, sans-serif" size="2">Pilih Masa</font>
			<?php 
				
					$masa = "select * from masa where masaTarikh = '$tarikhMula' and masaBilikNo='$bilikNo'";
					$qMasa = mysql_query($masa) or die (mysql_error());
          			while ($dataMasa = mysql_fetch_array($qMasa))
          			{
					
						if ($dataMasa['ptg4']=='x')
	        			{ 
			?>
					      <option value ="5:00PTG">5:00PTG
							<?php  	}
	       						else
            					{ ?>
                          </option>
					      <option hidden>5:00PTG
                          <?php 		}
          					 ?>
                          </option>
					<?php 
						if($dataMasa['ptg3']=='x')	
						{						
					?>			
						 <option value ="4:00PTG">4:00PTG	
					<?php  	}
	       						else
            					{ ?>
                          </option>
					      <option hidden>4:00PTG
                          <?php 		}
          					 ?>
                          </option>
					<?php 
						if($dataMasa['ptg2']=='x')	
						{						
					?>			
						 <option value ="3:00PTG">3:00PTG	
						 <?php  	}
	       						else
            					{ ?>
                          </option>
					      <option hidden>3:00PTG
                          <?php 		}
          					 ?>
                          </option>
					<?php  	
						if($dataMasa['ptg1']=='x')	
						{						
					?>			
						 <option value ="2:00PTG">2:00PTG	
						 <?php  	}
	       						else
            					{ ?>
                          </option>
					      <option hidden>2:00PTG
                          <?php 		}
          					 ?>
                          </option>
						  
					<?php
						if($dataMasa['ptg12']=='x')	
						{						
					?>			
						 <option value ="1:00PTG">1:00PTG
						 <?php  	}
	       						else
            					{ ?>
                          </option>
					      <option hidden>1:00PTG
                          <?php 		}
          					 ?>
                          </option>
					<?php 
					if($dataMasa['pg11']=='x')	
						{						
					?>			
						 <option value ="12:00PTG">12:00PTG	
						<?php  	}
	       						else
            					{ ?>
                          </option>
					      <option hidden>12:00PG
                          <?php 		}
          					 ?>
                          </option>
						 
					<?php  
					if($dataMasa['pg10']=='x')	
						{						
					?>			
						 <option value ="11:00PG">11:00PG
						 <?php  	}
	       						else
            					{ ?>
                          </option>
					      <option hidden>11:00PG
                          <?php 		}
          					 ?>
                          </option>
						 <?php  
					if($dataMasa['pg9']=='x')	
						{						
					?>			
						 <option value ="10:00PG">10:00PG
						 <?php  	}
	       						else
            					{ ?>
                          </option>
					      <option hidden>10:00PG
                          <?php 		}
          					 ?>
                          </option>
					<?php  
					if($dataMasa['pg8']=='x')		
						{						
					?>			
						 <option value ="9:00PG">9:00PG
							<?php  	}
	       						else
            					{ ?>
                          </option>
					      <option hidden>9:00PG
                          <?php 		}
          					} ?>
                          </option>
						  
			</select>
		  </td>

		 </tr>
		    <tr class="light">
            <td><font face="Arial, sans-serif" size="2">Pinjaman LCD</font></td>
            <td>:</td>
            <td><font face="Arial, sans-serif" size="2"><input type="radio" name="pinjamanLCD" value="Ya" required>Ya<input type="radio" name="pinjamanLCD" value="Tidak">Tidak</font></td>
          </tr>
		  <tr class="dark">
           
            <td><font face="Arial, sans-serif" size="2">Nama Bilik</font></td>
            <td>:</td>
            <td><input name="namaBilik" value="<?php echo $dataBilik['bilikNama']; ?>" readonly size="50">
			<input name="noBilik" value="<?php echo $dataBilik['bilikNo']; ?>" hidden></td>
          </tr>
           <tr class="light">
            <td><font face="Arial, sans-serif" size="2">Aras</font></td>
            <td>:</td>
            <td><input name="aras" value="<?php echo $aras; ?>" readonly></td>
          </tr>  
		   <tr class="dark">
           
            <td><font face="Arial, sans-serif" size="2">Tujuan</font></td>
            <td>:</td>
            <td><input type="text" name="tujuan" size="130" required>
			<input type="text" name="noTempahan" value="<?php echo $noTempahan;?>" hidden>
			<input type="text" name="masaMulaLama" value="<?php echo $masaMulaLama; ?>" hidden>
			<input type="text" name="masaAkhirLama" value="<?php echo $masaAkhirLama; ?>" hidden>
			</td>
          </tr>
        </tbody>
      </table>
	  </font>
        
      <p><div id="respond">
	  <p align = "center">
	  <a><input name="submit" type="submit" id="submit" value="Tempah" /></a>
	  <a href="kemaskini_tempahan_tukar_masa.php?noTempahan=<?php echo $noTempahan;?>&tarikhMula=<?php echo $tarikhMula?>&aras=<?php echo $aras; ?>&noBilik=<?php echo $bilikNo; ?>&masaMula=<?php echo $masaMulaLama;?>&masaAkhir=<?php echo $masaAkhirLama;?>"><input type="button" id="submit" value="Kembali" /></a>
	  </form>
      </p></div>
      </p>
    </div>
    <br class="clear" />
</div>
<!-- #################################################TUTUP BODY###################################################### -->

<!-- #################################################TUTUP SPACE###################################################### -->

<!-- ##############################################BOTTOM######################################################### -->
<br class="clear" />
<div class="wrapper col8">
  <div id="copyright">
  <font size="-3" face="Arial, Helvetica, sans-serif">
    <p class="fl_left">Copyright &copy; Jun 2014 - Sept 2014 - All Rights Reserved - <a>PKINK</a></p>
    <p class="fl_right">Dibina oleh : <a>Pelajar Latihan Industri UiTM</a></p>
    </font>
    <br class="clear" />
  </div>
</div>
<!-- ##############################################TUTuP BOTTOM######################################################### -->
</body>
</html>
<?php 
}
?>
