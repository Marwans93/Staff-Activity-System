<?php
	include '../penghubung/penghubung.php';

	$noBilik = $_POST['noBilik'];
	$aras = $_POST['aras'];
	$tahun = $_POST['tahun'];
	$bulan = $_POST['bulan'];
	$hari = "01";
	
	$tarikh = $tahun."-".$bulan."-".$hari;
	
	$tarikhPenuh = new DateTime($tarikh);
	$tarikhPapar = $tarikhPenuh->format('l Y-m-d');
	$hariPapar = $tarikhPenuh->format('l');
	
	
	//Convert Day to Malay
	
	if($hariPapar == "Friday")
	{
		$namaHari = "Jumaat";
	}
	elseif($hariPapar == "Saturday")
	{
		$namaHari = "Sabtu";
	}
	elseif($hariPapar == "Sunday")
	{
		$namaHari = "Ahad";
	}
	elseif($hariPapar == "Monday")
	{
		$namaHari = "Isnin";
	}
	elseif($hariPapar == "Tuesday")
	{
		$namaHari = "Selasa";
	}
	elseif($hariPapar == "Wednesday")
	{
		$namaHari = "Rabu";
	}
	elseif($hariPapar == "Thursday")
	{
		$namaHari = "Khamis";
	}
	
	// close convert day
	
	
	
	//Total day in month
	
	if($bulan == "08" || $bulan == "07" || $bulan == "01" || $bulan == "03" || $bulan == "05" || $bulan == "10" || $bulan == "12")
	{
		$jumlahBulan = 31;
	}
	else if($bulan == "09" || $bulan == "04" || $bulan == "06" || $bulan == "11")
	{
		$jumlahBulan = 30;
	}
	else if($bulan == "02")
	{
		if($tahun == "2012" || $tahun == "2016" || $tahun == "2020" || $tahun == "2024")
		{
			$jumlahBulan = 29;
		}
		else
		{
			$jumlahBulan = 28;
		}
	}
	//close total day in month
	
	//make date
	$hariEsok = $tarikh;
	
	for($i = 2; $i <=$jumlahBulan; $i++)
		{
			$id1++;
			$lastDay = new DateTime($hariEsok);
			$lastDay->modify('+1 day');
			$tarikhAkhir = $lastDay->format('Y-m-d');
			
			$hariEsok = $lastDay->format('Y-m-d');
		}
	

	//close make date
	
	
	
	
	
	
	
	$selectID = mysql_query ("select * from masa");
	$dataID = mysql_num_rows($selectID);
	$id = $dataID;
	
	
	$select = "select * from masa where masaTarikh = '$tarikh' and masaBilikNo = '$noBilik'";
	
	$queue = mysql_query($select) or die (mysql_error());
	$data = mysql_fetch_array($queue);
	$numberRow = mysql_num_rows($queue);
	

	
	$hariYangDitambah = $tarikh;
	
	if(!$numberRow == 0)
	{
		//$status = "Telah Ada";	
		header("Location:semak_tempah.php?tarikhMula=$tarikh&tarikhAkhir=$tarikhAkhir&aras=$aras&noBilik=$noBilik");
	}
	else
	{
		$id++;
		
		$tukar = new DateTime($tarikh);
		$tukarNama = $tukar->format('l');
		
		if($tukarNama == 'Friday' || $tukarNama == 'Saturday')
		{
			$tambah1 = "insert into masa (masaTarikh, pg8, pg9, pg10, pg11, ptg12, ptg1, ptg2, ptg3, ptg4, masaBilikNo, masaID) values ('$tarikh', 't', 't', 't', 't', 't', 't', 't', 't', 't', '$noBilik', '$id')";
			mysql_query($tambah1) or die(mysql_error());
		}
		else
		{
			$tambah1 = "insert into masa (masaTarikh, pg8, pg9, pg10, pg11, ptg12, ptg1, ptg2, ptg3, ptg4, masaBilikNo, masaID) values ('$tarikh', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', '$noBilik', '$id')";
			mysql_query($tambah1) or die(mysql_error());
		}
		
		
		
		$id1=$id;
		for($limitHari = 2; $limitHari <=$jumlahBulan; $limitHari++)
		{
			$id1++;
			$tambahHari = new DateTime($hariYangDitambah);
			$tambahHari->modify('+1 day');
			$check = $tambahHari->format('l');
			$check2 = $tambahHari->format('Y-m-d');
			//echo "<br>Hari (".$limitHari.") = ".$tambahHari->format('l Y-m-d');
			//echo "<br>Tiap = ".$check2;
			
			if($check == "Friday" || $check == "Saturday")
			{
				$tambah = "insert into masa (masaTarikh, pg8, pg9, pg10, pg11, ptg12, ptg1, ptg2, ptg3, ptg4, masaBilikNo, masaID) values ('$check2', 't', 't', 't', 't', 't', 't', 't', 't', 't', '$noBilik', '$id1')";
				mysql_query($tambah) or die(mysql_error());
			}
			else
			{
				$tambah = "insert into masa (masaTarikh, pg8, pg9, pg10, pg11, ptg12, ptg1, ptg2, ptg3, ptg4, masaBilikNo, masaID) values ('$check2', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', '$noBilik', '$id1')";
				mysql_query($tambah) or die(mysql_error());
			}

				
			$hariYangDitambah = $tambahHari->format('Y-m-d');
		}
		//$status="Berjaya Ditambah Baru";
		header("Location:semak_tempah.php?tarikhMula=$tarikh&tarikhAkhir=$tarikhAkhir&aras=$aras&noBilik=$noBilik");
	}
	
	
	
	
	
	
	
	//echo "<br>Tarikh: ".$tarikhPapar;
	//echo "<br>Nama Hari: ".$namaHari;
	//echo "<br>Jumlah Hari Dalam Bulan: ".$jumlahBulan;
	//echo "<br>Jumlah Data Yang Ada: ".$numberRow;
	//echo "<br>Tarikh Dalam Data: ".$numberRow;
	//echo "<br>Satus: ".$status;
	
	
	/*
	$tm = new DateTime($tarikhMula);
	$ta = new DateTime($tarikhAkhir);
	
	$tMula = $tm->format('Y-m-d');
	$tAkhir = $ta->format('Y-m-d');
	
	$startTimeStamp = strtotime($tarikhMula);
	$endTimeStamp = strtotime($tarikhAkhir);

	$timeDiff = abs($endTimeStamp - $startTimeStamp);
	$a=$timeDiff;

	$numberDays = $timeDiff/86400;  // 86400 seconds in one day
	$b=$numberDays;
	
	
	$esok = new DateTime($tarikhMula);
	$esok->modify('+1 day');
	
	
	
	//echo "Tarikh Mula = ".$tarikhMula;
	//echo "<br>Tarikh Akhir = ".$tarikhAkhir;
	//echo "<br>Esok = ".$esok->format('l Y-m-d');
	//echo "<br>Hari Esok = ".$esok->format('l');
	//echo "<br>Beza Hari = ".$b;
	
	$hariYangDitambah = $tarikhMula;
	
	$select = "select * from masa";
	$qSelect = mysql_query($select) or die (mysql_error());
	$dataSelect = mysql_num_rows($qSelect);
	
	
	$select = "select * from masa where masaTarikh between '$tarikhMula' and '$tarikhAkhir' and masaBilikNo = '$noBilik'";
	
	$queue = mysql_query($select) or die (mysql_error());
	$data = mysql_fetch_array($queue);
	$numberRow = mysql_num_rows($queue);
	
	if($numberRow == 0)
	{
	
			for($limitHari = 1; $limitHari <=$b; $limitHari++)
		{
			$id = $dataSelect++;
			$tambahHari = new DateTime($hariYangDitambah);
			$tambahHari->modify('+1 day');
			$check = $tambahHari->format('l');
			$check2 = $tambahHari->format('Y-m-d');
			//echo "<br>Hari (".$limitHari.") = ".$tambahHari->format('l Y-m-d');
			//echo "<br>Tiap = ".$check2;

			$tambah = "insert into masa (masaTarikh, pg8, pg9, pg10, pg11, ptg12, ptg1, ptg2, ptg3, ptg4, masaBilikNo, masaID) values ('$check2', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', '$noBilik', '$id')";
			mysql_query($tambah) or die(mysql_error());

				
			$hariYangDitambah = $tambahHari->format('l Y-m-d');
		}
		
			header("Location:semak_tempah.php?tarikhMula=$tMula&tarikhAkhir=$tAkhir&aras=$aras&noBilik=$noBilik");
	}
		else
		{			
			header("Location:semak_tempah.php?tarikhMula=$tMula&tarikhAkhir=$tAkhir&aras=$aras&noBilik=$noBilik");
		}
	*/
?>