<font face="Arial, Helvetica, sans-serif" size="6">
  <a href="index.php">Laman Bilik Makmal</a>
  </font>