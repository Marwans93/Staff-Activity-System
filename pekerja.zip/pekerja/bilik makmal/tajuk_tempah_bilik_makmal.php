<font face="Arial, Helvetica, sans-serif" size="6">
  <a href="index.php">Laman Tempah Bilik Makmal</a>
  </font>