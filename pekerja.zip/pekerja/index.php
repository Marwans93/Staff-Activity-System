<?php
	session_start();
	$nama = $_SESSION['nama'];
	$noStaff = $_SESSION['noStaff'];
	$jawatan = $_SESSION['jawatan'];
	
	if(!$_SESSION['register'])
		header('Location:../index.php');
	
	else
	{
		include '../penghubung/penghubung.php';
?>
<?php include ('header.php'); ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<title>Sistem Tempahan</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="scripts/jquery.timers.1.2.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.2.1.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.setup.js"></script>
</head>
<body id="top">

<!-- #################################################MENU###################################################### -->
<?php include ('menu.php');?>
<!-- #####################################################TUTUP MENU################################################## -->

<!-- ##################################################MAKLUMAT PENGUNA##################################################### -->
<?php include('maklumat_diri.php'); ?>
<!-- #################################################TUTUP MAKLUMAT PENGGUNA###################################################### -->

<!-- ###############################################BODY######################################################## -->
<?php include('body.php'); ?>
<!-- #################################################TUTUP BODY###################################################### -->


<!-- #####################################################SPACE################################################## -->
<div id="adblock">
<br class="clear" />
</div>
<!-- #################################################TUTUP SPACE###################################################### -->

<!-- #################################################FOOTER###################################################### -->
<?php include('footer.php');?>
<!-- ###############################################TUTUP FOOTER################################################## -->

</body>
</html>
<?php
}
?>