<?php

	$no = $_GET['permohonanNo'];
	
		include '../penghubung/penghubung.php';

		$permohonan = mysql_query("select * from permohonan where permohonanNo = '$no'") or die(mysql_error());
		$dataPermohonan = mysql_fetch_array($permohonan);
		
		mysql_query("update permohonan
					set permohonanTindak = 'lulus',
						permohonanStatus = 'diterima'
					where permohonanNo = '$no'") or die (mysql_error());
					
		$lulus = "Permohonan ".$dataPermohonan['permohonanNama']." telah diluluskan!";			
		
		header("Location:senarai_permohonan_kemaskini.php?status=$lulus");
		
		
?>

