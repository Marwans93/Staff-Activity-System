<?php
	session_start();
	$nama = $_SESSION['nama'];
	$noStaff = $_SESSION['noStaff'];
	$jawatan = $_SESSION['jawatan'];
	
	if(!$_SESSION['register'])
		header('Location:../index.php');
	
	else
	{
		include '../penghubung/penghubung.php';
		
		
	if(isset($_GET['status']))
	{
		$catatan = $_GET['status'];
	
		$semakStatus = $catatan;
	}
	else
	{
		$semakStatus = '';
	}
	
	
		if (isset($_GET["start"]))
		{	$start = $_GET["start"]; }
		else
		{	$start =''; }

			if(!isset($start))
				{ $start = 0; }                 
  
				$eu = ($start - 0);
				$limit = 5;
				$thispage = $eu + $limit;
				$back = $eu - $limit;
				$next = $eu + $limit;
				
				
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<title>WHO'S IN SISTEM</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="scripts/jquery.timers.1.2.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.2.1.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.setup.js"></script>
</head>
<body id="top">
<!-- ########################################HEADER############################################################### -->
<div class="wrapper col0">
  <div id="topline">
    <p><font face="Arial, Helvetica, sans-serif">Log Masuk Sebagai: Admin | &nbsp;&nbsp;&nbsp;<a href="../proses_log_keluar.php">|LOG KELUAR|</a> </font></p>
   <!-- <ul>
      <li><a href="#">Libero</a></li>
      <li><a href="#">Maecenas</a></li>
      <li><a href="#">Mauris</a></li>
      <li class="last"><a href="#">Suspendisse</a></li>
    </ul>-->
    <br class="clear" />
  </div>
</div>
<!-- ###############################################TUTUP HEADER######################################################## -->
<!-- #############################################LOGO########################################################## -->
<div class="wrapper">
  <div id="header">
    <div class="fl_left">
      <h1><a href="#"><strong>W</strong>ho's In<strong> S</strong>istem</a></h1>
      <p>Keberadaan Anggota </p>
    </div>
    <div class="fl_right"><a href="#"><img src="images/LOGO.png" alt="" /></a></div>
    <br class="clear" />
  </div>
</div>

<!-- ##################################################TUTUP LOGO##################################################### -->

<!-- #################################################MENU###################################################### -->
<div class="wrapper col2">
  <div id="topbar">
  <font face="Arial, Helvetica, sans-serif">
    <div id="topnav">
      <ul>
        <li><a href="../index.php">Utama</a></li>
        <li><a href="../urus pengurus/lihat_semua_anggota.php">Urus Anggota</a></li>
        <li class="active"><a href="catatan_keluar_masuk.php"> Kemaskini Keberadaan</a></li>
         
        <li><a href="../khidmat pengguna/senarai_khidmat_anggota.php">Senarai Khidmat Anggota</a></li>
    </div>
    </font>
    <br class="clear" />
  </div>
</div>
<!-- #####################################################TUTUP MENU################################################## -->
<!-- ###############################################BODY######################################################## -->
<div class="wrapper">
<div class="container">
<p align="center">
<font face="Arial, Helvetica, sans-serif" size="+2">Catatan Keluar Masuk Anggota
<br>
</font></p>

<p align="center">
<font face="Arial, Helvetica, sans-serif" color="green" size="+1">
<?php echo $semakStatus; ?>
<br>
</font></p>
<font face="Arial, Helvetica, sans-serif">
  <table summary="Summary Here" cellpadding="0" cellspacing="0" border="1">
        <thead>
          <tr>
            <th >Tarikh</th>
			<th >Nama Anggota</th>
			<th >Tujuan Urusan Rasmi & Tidak Rasmi</th>
			<th >Masa Keluar</th>
            <th >Masa Masuk</th>
			<th>Status</th>
          </tr>
        </thead>
        <tbody>
		<?php 
			
			$status = mysql_query("select * from status order by statusTarikh limit $eu,$limit") or die(mysql_error());
			$kira =1;
			
			while($dataStatus = mysql_fetch_array($status))
			{
		?>
          <tr class="light">
            <td width="1%"><?php echo $kira++;?></td>
            <td width="20%"><?php echo $dataPengguna['penggunaNama'];?></td>
            <td width="20%"><?php echo $dataStatus['statusTujuan'];?></td>
			<td width="20%"><?php echo $dataStatus['statusKeluar'];?></td>
            <td width="20%"><?php echo $dataStatus['statusMasuk'];?></td>
			<td width="20%"><?php 
						if ( $dataStatus['statusKebenaran'] == 'belum')
						{
							$nom = $dataStatus['penggunaNama'];
							echo "<a href='proses_lulus.php?peenggunaNama=$nom'>[Lulus]</a>&nbsp;<a href='proses_tolak.php?penggunaNama=$nom'>[Tolak]</a>";
						}
						else
						{
							echo 'Telah Selesai';
						}
			
			?></td>
          </tr>
		  <?php
			
		  }
		  ?>
		  <tr>
		  <td colspan="5"><p align="right">
		  <?php
$selecRow = mysql_query("select * from status") or die (mysql_error());
$rows = mysql_num_rows($selecRow);

$bilrow1 = $rows;

         if($back >= 0)
         { print "<a href='senarai_khidmat_anggota.php?start=$back' ><<&nbsp;</a>";}

         $j=0;
         $l=1;

         for($j=0; $j<$bilrow1; $j=$j+$limit)
         {
           if($j <> $eu)
           { echo "&nbsp;&nbsp;<a href='senarai_khidmat_pengguna.php?start=$j'>$l</a> ";}
           else
           { echo "&nbsp;<font color=red>$l</font>";}
   
           $l=$l+1;
         }

         if($thispage < $bilrow1)
         { echo "&nbsp;&nbsp;<a href='senarai_khidmat_anggota.php?start=$next'><font face='Verdana' size='2'>>></font></a>";}

?></p></td>
		  </tr>
        </tbody>
      </table>
      
      
    </font>
	
    </div>
    <br class="clear" />
</div>
<!-- #################################################TUTUP BODY###################################################### -->
<!-- #####################################################SPACE################################################## -->
<div id="adblock">
<br class="clear" />
</div>
<!-- #################################################TUTUP SPACE###################################################### -->

<!-- ##############################################BOTTOM######################################################### -->
<br class="clear" />
<div class="wrapper col8">
  <div id="copyright">
  
    <p class="fl_left"><font size="-3" face="Arial, Helvetica, sans-serif">Copyright &copy; Dec 2014 - Mac 2015 - All Rights Reserved - <a>PKINK</a></font></p><font size="-3" face="Arial, Helvetica, sans-serif">
    <p class="fl_right">Dibina oleh : <a>Pelajar Latihan Industri UiTM</a></p>
    </font>
    <br class="clear" />
  </div>
</div>
<!-- ##############################################TUTuP BOTTOM######################################################### -->
</body>
</html>
<?php
}
?>
