<?php

	include '../penghubung/penghubung.php';
	
$noHubungi = $_POST['noHubungi'];
$nama = $_POST['nama'];
$to = $_POST['email'];
$mesej = $_POST['mesej'];
$maklumBalas = $_POST['maklumBalas'];
$subject = "Maklum Balas Tentang Sistem Keberadaan Anggota";
$headers = "From: ridhz93@gmail.com";
$message = "Persoalan anda : $mesej

Maklum balas dari kami:
$maklumBalas";

mail($to,$subject,$message,$headers);

mysql_query("update hubungi set hubungiStatus = 'Selesai' where hubungiNo = '$noHubungi'") or die (mysql_error());


$makluman = "Maklum Balas kepada ".$nama." (".$to.") telah dihantar!";

header ("Location: senarai_khidmat_anggota.php?status=$makluman");

?>