<?php
	session_start();
	$nama = $_SESSION['nama'];
	$noStaff = $_SESSION['noStaff'];
	$jawatan = $_SESSION['jawatan'];
	
	if(!$_SESSION['register'])
		header('Location:../index.php');
	
	else
	{
		include '../penghubung/penghubung.php';
		
		
		
		if (isset($_GET["start"]))
		{	$start = $_GET["start"]; }
		else
		{	$start =''; }

		//paging
			if(!isset($start))
				{ $start = 0; }                 
  
				$eu = ($start - 0);
				$limit = 5;
				$thispage = $eu + $limit;
				$back = $eu - $limit;
				$next = $eu + $limit;
				
				
				
	if(isset($_GET['status']))
	{
		$catatan = $_GET['status'];
	
		$semakStatus = $catatan;
	}
	else
	{
		$semakStatus = '';
	}
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<title>WHO'S IN SISTEM</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="scripts/jquery.timers.1.2.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.2.1.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.setup.js"></script>
</head>
<body id="top">
<!-- ########################################HEADER############################################################### -->
<div class="wrapper col0">
  <div id="topline">
    <p><font face="Arial, Helvetica, sans-serif">Log Masuk Sebagai: Admin | &nbsp;&nbsp;&nbsp;<a href="../proses_log_keluar.php">|LOG KELUAR|</a> </font></p>
   <!-- <ul>
      <li><a href="#">Libero</a></li>
      <li><a href="#">Maecenas</a></li>
      <li><a href="#">Mauris</a></li>
      <li class="last"><a href="#">Suspendisse</a></li>
    </ul>-->
    <br class="clear" />
  </div>
</div>
<!-- ###############################################TUTUP HEADER######################################################## -->
<!-- #############################################LOGO########################################################## -->
<div class="wrapper">
  <div id="header">
    <div class="fl_left">
      <h1><a href="#"><strong>W</strong>ho's In <strong>S</strong>istem</a></h1>
      <p>Keberadaan Anggota </p>
    </div>
    <div class="fl_right"><a href="#"><img src="images/LOGO.png" alt="" /></a></div>
    <br class="clear" />
  </div>
</div>

<!-- ##################################################TUTUP LOGO##################################################### -->

<!-- #################################################MENU###################################################### -->
<div class="wrapper col2">
  <div id="topbar">
  <font face="Arial, Helvetica, sans-serif">
    <div id="topnav">
      <ul>
        <li><a href="../index.php">Utama</a></li>
        <li><a href="../urus pengurus/lihat_semua_pengurus.php">Urus Anggota</a></li>
        <li><a href="../permohonan kemaskini/catatan_keluar_masuk.php"> Kemaskini Keberadaan</a></li>
         
        <li class="active"><a href="senarai_khidmat_pengguna.php">Senarai Khidmat Pengguna</a></li>
    </div>
    </font>
    <br class="clear" />
  </div>
</div>
<!-- #####################################################TUTUP MENU################################################## -->
<!-- ###############################################BODY######################################################## -->
<div class="wrapper">
<div class="container">
<p align="center">
<font face="Arial, Helvetica, sans-serif" size="+2">
Senarai Khidmat Pengguna
<br>
</font></p>

<p align="center">
<font face="Arial, Helvetica, sans-serif" color="green" size="+1">
<?php echo $semakStatus; ?>
<br>
</font></p>

<font face="Arial, Helvetica, sans-serif">
  <table summary="Summary Here" cellpadding="0" cellspacing="0" border="1">
        <thead>
          <tr>
            <th >Bil.</th>
			<th >Nama</th>
			<th >Email</th>
			<th >Mesej</th>
			<th>Tindakan</th>
          </tr>
        </thead>
        <tbody>
		<?php
			
			$hubungi = mysql_query("select * from hubungi order by hubungiStatus limit $eu,$limit") or die (mysql_error());
			$kira = 1;
			
			while($dataHubungi = mysql_fetch_array($hubungi))
			{
		?>
          <tr class="light">
            <td width="1%"><?php echo $kira++; ?></td>
            <td width="29%"><?php echo $dataHubungi['hubungiNama']; ?></td>
            <td width="20%"><?php echo $dataHubungi['hubungiEmail']; ?></td>
			<td width="40%"><?php echo $dataHubungi['hubungiMesej']; ?></td>
			<td width="10%"><?php
					if($dataHubungi['hubungiStatus']=='Belum') 
					{
						$noHubungi = $dataHubungi['hubungiNo'];
						echo "<a href='khidmat_pengguna_tindakkan.php?hubungiNo=$noHubungi'>Belum</a>";
					}
					else
					{
						echo "Selesai";
					}
			
			?></td>
          </tr>
		  <?php
		  }
		  ?>
		  <tr>
		  <td colspan="5"><p align="right">
		  <?php
$selecRow = mysql_query("select * from hubungi") or die (mysql_error());
$rows = mysql_num_rows($selecRow);

$bilrow1 = $rows;
// set paging
         if($back >= 0)
         { print "<a href='senarai_khidmat_pengguna.php?start=$back' ><<&nbsp;</a>";}

         $j=0;
         $l=1;

         for($j=0; $j<$bilrow1; $j=$j+$limit)
         {
           if($j <> $eu)
           { echo "&nbsp;&nbsp;<a href='senarai_khidmat_pengguna.php?start=$j'>$l</a> ";}
           else
           { echo "&nbsp;<font color=red>$l</font>";}
   
           $l=$l+1;
         }

         if($thispage < $bilrow1)
         { echo "&nbsp;&nbsp;<a href='senarai_khidmat_pengguna.php?start=$next'><font face='Verdana' size='2'>>></font></a>";}

?></p></td>
		  </tr>
        </tbody>
      </table>
    
      
    </font>
    </div>
    <br class="clear" />
</div>

<!-- #################################################TUTUP BODY###################################################### -->
<!-- #####################################################SPACE################################################## -->
<div id="adblock">
<br class="clear" />
</div>
<!-- #################################################TUTUP SPACE###################################################### -->

<!-- ##############################################BOTTOM######################################################### -->
<br class="clear" />
<div class="wrapper col8">
  <div id="copyright">
  <font size="-3" face="Arial, Helvetica, sans-serif">
    <p class="fl_left">Copyright &copy; Dec 2014 - Mac 2015 - All Rights Reserved - <a>PKINK</a></p>
    <p class="fl_right">Dibina oleh : <a>Pelajar Latihan Industri UiTM</a></p>
    </font>
    <br class="clear" />
  </div>
</div>
<!-- ##############################################TUTuP BOTTOM######################################################### -->
</body>
</html>
<?php
}
?>
