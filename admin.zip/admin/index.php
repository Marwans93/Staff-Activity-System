<?php
	session_start();
	$nama = $_SESSION['nama'];
	$noStaff = $_SESSION['noStaff'];
	$jawatan = $_SESSION['jawatan'];
	
	if(!$_SESSION['register'])
		header('Location:../index.php');
	
	else
	{
		include '../penghubung/penghubung.php';
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<title>WHO'S IN SISTEM</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="scripts/jquery.timers.1.2.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.2.1.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.setup.js"></script>
</head>
<body id="top">
<!-- ########################################HEADER############################################################### -->
<div class="wrapper col0">
  <div id="topline">
    <p><font face="Arial, Helvetica, sans-serif">Log Masuk Sebagai: Admin | &nbsp;&nbsp;&nbsp;<a href="proses_log_keluar.php">|LOG KELUAR|</a></font></p>
   <!-- <ul>
      <li><a href="#">Libero</a></li>
      <li><a href="#">Maecenas</a></li>
      <li><a href="#">Mauris</a></li>
      <li class="last"><a href="#">Suspendisse</a></li>
    </ul>-->
    <br class="clear" />
  </div>
</div>
<!-- ###############################################TUTUP HEADER######################################################## -->
<!-- #############################################LOGO########################################################## -->
<div class="wrapper">
  <div id="header">
    <div class="fl_left">
      <h1><a href="#"><strong>W</strong>ho's In <strong>S</strong>istem</a></h1>
      <p>Keberadaan Anggota</p>
    </div>
    <div class="fl_right"><a href="#"><img src="images/LOGO.png" alt="" /></a></div>
    <br class="clear" />
  </div>
</div>

<!-- ##################################################TUTUP LOGO##################################################### -->

<!-- #################################################MENU###################################################### -->
<div class="wrapper col2">
  <div id="topbar">
  <font face="Arial, Helvetica, sans-serif">
    <div id="topnav">
      <ul>
        <li class="active"><a href="index.php">Utama</a></li>
        <li><a href="urus pengurus/lihat_semua_anggota.php">Urus Anggota</a></li>
        <li><a href="permohonan kemaskini/catatan_keluar_masuk.php">Kemaskini Keberadaan </a></li>
         
        <li><a href="khidmat pengguna/senarai_khidmat_anggota.php">Senarai Khidmat Anggota</a></li>
    </div>
    </font>
    <br class="clear" />
  </div>
</div>
<!-- #####################################################TUTUP MENU################################################## -->
<!-- ###############################################BODY######################################################## -->
<div class="wrapper">
  <div id="adblock">
    <p align="center"><br>
    <h5>Tugas admin:</h5>
	<ol>
		<h4>URUS ANGGOTA</h4>
		<li>Perlu menambah anggota baru untuk setiap jabatan.
		<li>Perlu menambah jabatan baru atau membuang jabatan.
		<li>Menyemak kesilapan maklumat pengurus yang telah disimpan.
		<li>Perlu membuang pengurus jika pengurus itu bertukar/bersara/sebagainya yang tidak lagi akan ada di PKINK.
	</ol>
	<ol>
		<h4>KEMASKINI KEBERADAAN</h4>
		<li>Menyemak permohonan dari pekerja yang ingin mengemaskini nama/katalaluan/nombor staff.
		<li>Memberi kelulusan terhadap status keberadaan anggota
	</ol>
	<ol>
	  <h4>KHIDMAT ANGGOTA</h4>
		<li>Memberi tindakbalas terhadap semua pertanyaan anggota.
		<li>Menyemak semua pertanyaan anggota.
	</ol>
	
	
<!-- #################################################TUTUP BODY###################################################### -->
<!-- #####################################################SPACE################################################## -->
<div id="adblock">
<br class="clear" />
</div>
<!-- #################################################TUTUP SPACE###################################################### -->

<!-- ##############################################BOTTOM######################################################### -->
<br class="clear" />
<div class="wrapper col8">
  <div id="copyright">
  <font size="-3" face="Arial, Helvetica, sans-serif">
    <p class="fl_left">Copyright &copy;Dec 2014 - Mac 2015  - All Rights Reserved - <a>PKINK</a></p>
    <p class="fl_right">Dibina oleh : <a>Pelajar Latihan Industri UiTM</a></p>
    </font>
    <br class="clear" />
  </div>
</div>
<!-- ##############################################TUTuP BOTTOM######################################################### -->
</body>
</html>
<?php
}
?>
