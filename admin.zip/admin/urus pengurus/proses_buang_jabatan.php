<?php

 	include '../penghubung/penghubung.php';
	$jabatan = $_POST['jabatan'];
	

	
	if($jabatan == "0")
	{
			$maklum = "Sila pilih jabatan yang ingin dibuang";
			
			header("Location:tambah_jabatan.php?status=$maklum");
	}
	else
	{
	
			$select = mysql_query("select * from jabatan where jabatanNo = '$jabatan'");
	$dataSelect = mysql_fetch_array($select);
	
	$namaJabatan = $dataSelect['jabatanNama'];	
	
	
			mysql_query("delete from jabatan where jabatanNo = '$jabatan'") or die (mysql_error());
			
			$maklum = $namaJabatan." Berjaya Dibuang.";
			
			header("Location:tambah_jabatan.php?status=$maklum");
	}

	?>