<?php
	session_start();
	$nama = $_SESSION['nama'];
	$noStaff = $_SESSION['noStaff'];
	$jawatan = $_SESSION['jawatan'];
	
	if(!$_SESSION['register'])
		header('Location:../index.php');
	
	else
	{
		include '../penghubung/penghubung.php';
		
		$select ="select * from jabatan";
		$qSelect = mysql_query($select) or die(mysql_error());
	
		$no = $_GET['no'];
	
	
		$anggota = mysql_query("select * from anggota where anggotaID = '$no'") or die(mysql_error());
		$dataAnggota = mysql_fetch_array($anggota);
		
		
		$pengguna = mysql_query("select * from pengguna where penggunaID = '$no'") or die(mysql_error());
		$dataPengguna = mysql_fetch_array($pengguna);
							
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<title>WHO'S IN SISTEM</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="scripts/jquery.timers.1.2.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.2.1.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.setup.js"></script>
</head>
<body id="top">
<!-- ########################################HEADER############################################################### -->
<div class="wrapper col0">
  <div id="topline">
    <p><font face="Arial, Helvetica, sans-serif">Log Masuk Sebagai: Admin | &nbsp;&nbsp;&nbsp;<a href="../proses_log_keluar.php">|LOG KELUAR|</a> </font></p>
   <!-- <ul>
      <li><a href="#">Libero</a></li>
      <li><a href="#">Maecenas</a></li>
      <li><a href="#">Mauris</a></li>
      <li class="last"><a href="#">Suspendisse</a></li>
    </ul>-->
    <br class="clear" />
  </div>
</div>
<!-- ###############################################TUTUP HEADER######################################################## -->
<!-- #############################################LOGO########################################################## -->
<div class="wrapper">
  <div id="header">
    <div class="fl_left">
      <h1><a href="#"><strong>W</strong>ho's In<strong> S</strong>istem</a></h1>
      <p>Keberadaan Anggota </p>
    </div>
    <div class="fl_right"><a href="#"><img src="images/LOGO.png" alt="" /></a></div>
    <br class="clear" />
  </div>
</div>

<!-- ##################################################TUTUP LOGO##################################################### -->

<!-- #################################################MENU###################################################### -->
<div class="wrapper col2">
  <div id="topbar">
  <font face="Arial, Helvetica, sans-serif">
    <div id="topnav">
      <ul>
        <li><a href="../index.php">Utama</a></li>
        <li class="active"><a href="lihat_semua_pengurus.php">Urus Anggota</a></li>
        <li><a href="../permohonan kemaskini/catatan_keluar_masuk.php"> Kemaskini Keberadaan</a></li>
         
        <li><a href="../khidmat pengguna/senarai_khidmat_pengguna.php">Senarai Khidmat Anggota</a></li>
    </div>
    </font>
    <br class="clear" />
  </div>
</div>
<!-- #####################################################TUTUP MENU################################################## -->
<!-- ###############################################BODY######################################################## -->
<div class="wrapper">
<div class="container">
<font face="arial" size="3">
<div id="respond" align="center">


<form action="proses_kemaskini_anggota.php" method="post" name="tambah">

Nombor Staff : <input type="text" name="noStaff" value="<?php echo $no;?>" required>
<br><br>
Nama : <input type="text" name="nama" value="<?php echo $dataPengguna['penggunaNama'];?>" required>
<br><br>
Nombor IC : <input type="text" name="nomborIC" value="<?php echo $dataAnggota['anggotaIC'];?>" required>
<br><br>
Jabatan : &nbsp;&nbsp;<select name="jabatan" />
		<option selected />Pilih Jabatan
		<?php
		
		$qSelect = mysql_query("select * from jabatan") or die (mysql_error());
		
		while($dataSelect = mysql_fetch_array($qSelect))
		{
			if($dataAnggota['anggotaJabatan'] == $dataSelect['jabatanNama'])
			{
		?>
		</option>
		<option selected value="<?php echo $dataSelect['jabatanNama']; ?>"><?php echo $dataSelect['jabatanNama']; ?>
		<?php 
			}
			else
			{
		?>
		<option value="<?php echo $dataSelect['jabatanNama']; ?>"><?php echo $dataSelect['jabatanNama']; ?>
		<?php }
		} 
		?>
		</option>
		</select>
<br><br>
Email : <input type="text" name="email" value="<?php echo $dataAnggota['anggotaEmail'];?>" >
<br><br>
Nombor Telefon : <input type="text" name="nomborTelefon" value="<?php echo $dataAnggota['anggotaNoTel'];?>">

<br><br>

<input type="submit" name="submit" value="Kemaskini Anggota">
<input type="reset" name="reset" value="Bersih">
<a href="lihat_semua_anggota.php"><input type="button" name="submit" value="Kembali"></a>
</div>
</form>

</font>
	
    </div>
    <br class="clear" />
</div>
<!-- #################################################TUTUP BODY###################################################### -->
<!-- #####################################################SPACE################################################## -->
<div id="adblock">
<br class="clear" />
</div>
<!-- #################################################TUTUP SPACE###################################################### -->

<!-- ##############################################BOTTOM######################################################### -->
<br class="clear" />
<div class="wrapper col8">
  <div id="copyright">
  <font size="-3" face="Arial, Helvetica, sans-serif">
    <p class="fl_left">Copyright &copy; Dec 2014 - Mac 2015 - All Rights Reserved - <a>PKINK</a></p>
    <p class="fl_right">Dibina oleh : <a>Pelajar Latihan Industri UiTM</a></p>
    </font>
    <br class="clear" />
  </div>
</div>
<!-- ##############################################TUTuP BOTTOM######################################################### -->
</body>
</html>
<?php
}
?>


		
	