<?php

 	include '../penghubung/penghubung.php';
	
	$noStaff = $_POST['noStaff'];
	$penggunaNama = $_POST['penggunaNama'];
	$anggotaIC = $_POST['anggotaIC'];
	$anggotaJabatan = $_POST['anggotajabatan'];
	$penggunaJawatan = "anggota";
	$anggotaEmail = $_POST['anggotaEmail'];
	$anggotaNoTel = $_POST['anggotaNoTel'];

	
			mysql_query("update pengguna 
						set penggunaID = '$noStaff',
							penggunaNama = '$penggunaNama'
							where penggunaID = 'noStaff'") or die (mysql_error());
			
			mysql_query("update anggota
						set anggotaID = '$noStaff',
							anggotaIC = '$anggotaIC',
							anggotaJabatan = '$pengguna 		jabatan',
							anggotaEmail = '$anggotaEmail',
							anggotaNoTel = '$anggotaNoTel'
							where anggotaID = '$noStaff'") or die (mysql_error());
			
			$maklum = $noStaff." Berjaya Dikemaskini.";
			
			header("Location:lihat_semua_anggota.php?status=$maklum");

	?>