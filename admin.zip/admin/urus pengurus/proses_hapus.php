<?php

 	include '../penghubung/penghubung.php';
	
	$no = $_GET['no'];
	
			mysql_query("delete from anggota where anggotaID = '$no'") or die (mysql_error());
			
			mysql_query("delete from anggota where anggotaID = '$no'") or die (mysql_error());
			
			$maklum = $noStaff." Telah Dibuang.";
			
			header("Location:lihat_semua_anggota.php?status=$maklum");

	?>