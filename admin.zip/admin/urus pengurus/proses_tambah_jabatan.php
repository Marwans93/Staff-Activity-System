<?php

 	include '../penghubung/penghubung.php';
	$jabatan = $_POST['jabatan'];
	
	$jabatanSelect = mysql_query("select * from jabatan") or die (mysql_error());
	$data = mysql_fetch_array($jabatanSelect);
	$no = mysql_num_rows($jabatanSelect)+1;
	
	
	$compare = mysql_query("select * from jabatan where jabatanNama = '$jabatan'") or die (mysql_error());
	$row = mysql_num_rows($compare);

	if(!$row == 0)
	{
			$maklum = "Maaf ".$jabatan." sudah didaftar!";
			
			header("Location:tambah_jabatan.php?status=$maklum");
	}
	else
	{
			mysql_query("insert into jabatan values ('$jabatan','$no')") or die (mysql_error());
			
			$maklum = $jabatan." Berjaya Ditambah.";
			
			header("Location:tambah_jabatan.php?status=$maklum");
	}

	?>