<?php
	session_start();
	$nama = $_SESSION['nama'];
	$noStaff = $_SESSION['noStaff'];
	$jawatan = $_SESSION['jawatan'];
	
	if(!$_SESSION['register'])
		header('Location:../index.php');
	
	else
	{
		include '../penghubung/penghubung.php';
		
	if(isset($_GET['status']))
	{
		$id = $_GET['status'];
	
		$semakStatus = $id;
	}
	else
	{
		$semakStatus = '';
	}					
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<title>Sistem Tempahan</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="scripts/jquery.timers.1.2.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.2.1.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.setup.js"></script>
</head>
<body id="top">
<!-- ########################################HEADER############################################################### -->
<div class="wrapper col0">
  <div id="topline">
    <p><font face="Arial, Helvetica, sans-serif">Log Masuk Sebagai: Admin | &nbsp;&nbsp;&nbsp;<a href="../proses_log_keluar.php">|LOG KELUAR|</a> </font></p>
   <!-- <ul>
      <li><a href="#">Libero</a></li>
      <li><a href="#">Maecenas</a></li>
      <li><a href="#">Mauris</a></li>
      <li class="last"><a href="#">Suspendisse</a></li>
    </ul>-->
    <br class="clear" />
  </div>
</div>
<!-- ###############################################TUTUP HEADER######################################################## -->
<!-- #############################################LOGO########################################################## -->
<div class="wrapper">
  <div id="header">
    <div class="fl_left">
      <h1><a href="#"><strong>W</strong>ho's In<strong> S</strong>istem</a></h1>
      <p>Keberadaan Anggota </p>
    </div>
    <div class="fl_right"><a href="#"><img src="images/LOGO.png" alt="" /></a></div>
    <br class="clear" />
  </div>
</div>

<!-- ##################################################TUTUP LOGO##################################################### -->

<!-- #################################################MENU###################################################### -->
<div class="wrapper col2">
  <div id="topbar">
  <font face="Arial, Helvetica, sans-serif">
    <div id="topnav">
      <ul>
        <li><a href="../index.php">Utama</a></li>
        <li class="active"><a href="lihat_semua_anggota.php">Urus Anggota</a></li>
        <li><a href="../permohonan kemaskini/catatan_keluar_masuk.php"> Kemaskini Keberadaan</a></li>
         
        <li><a href="../khidmat pengguna/senarai_khidmat_anggota.php">Senarai Khidmat Anggota</a></li>
    </div>
    </font>
    <br class="clear" />
  </div>
</div>
<!-- #####################################################TUTUP MENU################################################## -->
<!-- ###############################################BODY######################################################## -->
<div class="wrapper">
<div class="container">

<p align="center">


	<font face="arial" size="+2"><br>
	<p align="center">Urus Jabatan</p></font>
	<p align="center"><label for="name"><font face="arial" size="+1" color="red"><?php echo $semakStatus;?></font></label></p>
	<br>
	<hr>
	<!-- #########################################semak noStaff#######################################################-->
	
<font face="arial" size="3">
	<form action="proses_tambah_jabatan.php" method="post" name="tambah">
		<div align="center" id="respond">
		
		<h3>Tambah Jabatan Baru</h3>
		<br>
		<br>
		<label for="name">Tambah Jabatan:</label>
		<input type="text" name="jabatan" required placeholder="Masukkan Nama Jabatan"/>
		<br>
		<br>
		
		<!--#################################### tutup semak noStaff#####################################################-->
		<br><br>
		<div align="center">
		
		<input type="submit" name="tambah" value="Tambah Jabatan">
		<input type="reset" name="reset" value="Bersih">
		
		</form>
		<br><br>
		<hr>
		<h3>Buang Jabatan</h3>
		<br><br>
		Pilih Jabatan Untuk Dibuang : 
		
		<form action="proses_buang_jabatan.php" method="post" name="buang">
		<select name="jabatan">
				<option selected value="0">Pilih Jabatan
				<?php 
					$jab = mysql_query("select * from jabatan") or die (mysql_error());
					
					while($dataJab = mysql_fetch_array($jab))
					{
				?>
				</option>
				<option value="<?php echo $dataJab['jabatanNo'];?>"><?php echo $dataJab['jabatanNama'];?></option>
				<?php 
				}
				?>
		</select>
		<br><br>		
		<input type="submit" name="submit" Value="Buang">
		</form>
		<br><br>		
		<a href="lihat_semua_anggota.php"><input type="button" name="kembali" value="Kembali"></a>
		<br><br>
		
		</div>
		</div>
		
		</font>
	


	
    </div>
    <br class="clear" />
</div>
<!-- #################################################TUTUP BODY###################################################### -->
<!-- #####################################################SPACE################################################## -->
<div id="adblock">
<br class="clear" />
</div>
<!-- #################################################TUTUP SPACE###################################################### -->

<!-- ##############################################BOTTOM######################################################### -->
<br class="clear" />
<div class="wrapper col8">
  <div id="copyright">
  <font size="-3" face="Arial, Helvetica, sans-serif">
    <p class="fl_left">Copyright &copy; Dec 2014 - Mac 2015 - All Rights Reserved - <a>PKINK</a></p>
    <p class="fl_right">Dibina oleh : <a>Pelajar Latihan Industri UiTM</a></p>
    </font>
    <br class="clear" />
  </div>
</div>
<!-- ##############################################TUTuP BOTTOM######################################################### -->
</body>
</html>
<?php
}
?>


		
	