<?php
	session_start();
	$nama = $_SESSION['nama'];
	$noStaff = $_SESSION['noStaff'];
	$jawatan = $_SESSION['jawatan'];
	
	if(!$_SESSION['register'])
		header('Location:../index.php');
	
	else
	{
		include '../penghubung/penghubung.php';
		
		
	if(isset($_GET['status']))
	{
		$catatan = $_GET['status'];
	
		$semakStatus = $catatan;
	}
	else
	{
		$semakStatus = '';
	}
	
	
		if (isset($_GET["start"]))
		{	$start = $_GET["start"]; }
		else
		{	$start =''; }

			if(!isset($start))
				{ $start = 0; }                 
  
				$eu = ($start - 0);
				$limit = 5;
				$thispage = $eu + $limit;
				$back = $eu - $limit;
				$next = $eu + $limit;
				
	
	
	$search = 'x';
	
	if(isset($_POST['search']))
	{
		$search = $_POST['search'];
	}
	else
	{
		$search = '';
	}
	
	if(!isset($search))
	{
	
		$anggota = "select * from anggota limit $eu,$limit";
		$queueAnggota = mysql_query($pengurus) or die(mysql_error());
		
		$select = "select * from anggota";
		$qSelect = mysql_query($select) or die(mysql_error());
		$rows = mysql_num_rows($qSelect);
		
		
	}
	else
	{
		
		$anggota = "select * from anggota where anggotaID like '%$search%' limit $eu,$limit";
		$queueAnggota = mysql_query($anggota) or die(mysql_error());
		$rows = mysql_num_rows($queueAnggota);
	}
	
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<title>WHO'S IN SISTEM</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="scripts/jquery.timers.1.2.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.2.1.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.setup.js"></script>
</head>
<body id="top">
<!-- ########################################HEADER############################################################### -->
<div class="wrapper col0">
  <div id="topline">
    <p><font face="Arial, Helvetica, sans-serif">Log Masuk Sebagai: Admin | &nbsp;&nbsp;&nbsp;<a href="../proses_log_keluar.php">|LOG KELUAR|</a> </font></p>
   <!-- <ul>
      <li><a href="#">Libero</a></li>
      <li><a href="#">Maecenas</a></li>
      <li><a href="#">Mauris</a></li>
      <li class="last"><a href="#">Suspendisse</a></li>
    </ul>-->
    <br class="clear" />
  </div>
</div>
<!-- ###############################################TUTUP HEADER######################################################## -->
<!-- #############################################LOGO########################################################## -->
<div class="wrapper">
  <div id="header">
    <div class="fl_left">
      <h1><a href="#"><strong>W</strong>ho's In<strong> S</strong>istem</a></h1>
      <p>Keberadaan Anggota </p>
    </div>
    <div class="fl_right"><a href="#"><img src="images/LOGO.png" alt="" /></a></div>
    <br class="clear" />
  </div>
</div>

<!-- ##################################################TUTUP LOGO##################################################### -->

<!-- #################################################MENU###################################################### -->
<div class="wrapper col2">
  <div id="topbar">
  <font face="Arial, Helvetica, sans-serif">
    <div id="topnav">
      <ul>
        <li><a href="../index.php">Utama</a></li>
        <li class="active"><a href="lihat_semua_anggota.php">Urus Anggota</a></li>
        <li><a href="../permohonan kemaskini/catatan_keluar_masuk.php"> Kemaskini Keberadaan</a></li>
         
        <li><a href="../khidmat pengguna/senarai_khidmat_anggota.php">Senarai Khidmat Anggota</a></li>
    </div>
    </font>
    <br class="clear" />
  </div>
</div>
<!-- #####################################################TUTUP MENU################################################## -->
<!-- ###############################################BODY######################################################## -->
<div class="wrapper">
<div class="container">
<p align="center">
<font face="Arial, Helvetica, sans-serif" size="+2">
URUS ANGGOTA
<br>
</font></p>

<p align="center">
<font face="Arial, Helvetica, sans-serif" color="green" size="+1">
<?php echo $semakStatus; ?>
<br>
</font></p>
<font face="Arial, Helvetica, sans-serif">




<br>
<a href="tambah_jabatan.php">+ Urus Jabatan</a>
<br><br>
<a href="tambah_anggota_semak.php">+ Tambah Anggota Baru</a>
<br>
<br>
<div id="respond">
<form action="lihat_semua_anggota.php" method="post" name="carian">
<input type="text" name="search" placeholder="Cari Nombor Staff">
<input type="submit" id="submit" name="submit" value="Cari">
</form>
</div>
<br>

  <table summary="Summary Here" cellpadding="0" cellspacing="0" border="1">
        <thead>
          <tr>
            <th >Bil.</th>
			<th >Nombor Staff</th>
			<th >Nama</th>
			<th >Jabatan</th>
			<th colspan="2">Tindakkan</th>
          </tr>
        </thead>
        <tbody>
		<?php
		
			$kira = 1;
			while($dataAnggota = mysql_fetch_array($queueAnggota))
			{
				$noAnggota = $dataAnggota['anggotaID'];
				
				$pengguna = mysql_query("select * from pengguna where penggunaID = '$noAnggota'");
				$dataPengguna = mysql_fetch_array($pengguna);
		?>
          <tr class="light">
            <td width="1%"><?php echo $kira++; ?></td>
            <td width="19%"><?php echo $dataAnggota['anggotaID']; ?></td>
            <td width="20%"><?php echo $dataPengguna['penggunaNama']; ?></td>
			<td width="30%"><?php echo $dataAnggota['anggotaJabatan']; ?></td>
			<td width="7%" align="center"><a href="lagi_anggota.php?no=<?php echo $dataAnggota['anggotaID']; ?>"><img src="images/lagi.png" onMouseOver="this.src='images/lagi2.png'" onMouseOut="this.src='images/lagi.png'"></a></td>
			<td width="7%" align="center"><a href="proses_hapus.php?no=<?php echo $dataAnggota['anggotaID'];?>"><img src="images/hapus.png" onMouseOver="this.src='images/hapus2.png'" onMouseOut="this.src='images/hapus.png'"></a></td>
          </tr>
		  <?php
			
			}
		  
		  ?>
		  <tr>
		  <td colspan="6"><p align="right">
		  <?php
	
		$bilrow1 = $rows;

         if($back >= 0)
         { print "<a href='lihat_semua_anggota.php?start=$back' ><<&nbsp;</a>";}

         $j=0;
         $l=1;

         for($j=0; $j<$bilrow1; $j=$j+$limit)
         {
           if($j <> $eu)
           { echo "&nbsp;&nbsp;<a href='lihat_semua_anggota.php?start=$j'>$l</a> ";}
           else
           { echo "&nbsp;<font color=red>$l</font>";}
   
           $l=$l+1;
         }

         if($thispage < $bilrow1)
         { echo "&nbsp;&nbsp;<a href='lihat_semua_anggota.php?start=$next'><font face='Verdana' size='2'>>></font></a>";}

?></p></td>
		  </tr>
        </tbody>
      </table>
      
      
    </font>
	
    </div>
    <br class="clear" />
</div>
<!-- #################################################TUTUP BODY###################################################### -->
<!-- #####################################################SPACE################################################## -->
<div id="adblock">
<br class="clear" />
</div>
<!-- #################################################TUTUP SPACE###################################################### -->

<!-- ##############################################BOTTOM######################################################### -->
<br class="clear" />
<div class="wrapper col8">
  <div id="copyright">
  
    <p class="fl_left"><font size="-3" face="Arial, Helvetica, sans-serif">Copyright &copy; Dec 2014 - Mac 2015 - All Rights Reserved - <a>PKINK</a></font></p><font size="-3" face="Arial, Helvetica, sans-serif">
    <p class="fl_right">Dibina oleh : <a>Pelajar Latihan Industri UiTM</a></p>
    </font>
    <br class="clear" />
  </div>
</div>
<!-- ##############################################TUTuP BOTTOM######################################################### -->
</body>
</html>
<?php
}
?>
