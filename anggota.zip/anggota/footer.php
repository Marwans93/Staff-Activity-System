
<!-- ##############################################BOTTOM######################################################### -->

<div class="wrapper col8">
  <div id="copyright">
  
    <p class="fl_left"><font size="-3" face="Arial, Helvetica, sans-serif">Copyright &copy; Dec 2014 - Mac 2015 - All Rights Reserved - <a>PKINK</a></font></p>
    <font size="-3" face="Arial, Helvetica, sans-serif">
    <p class="fl_right">Dibina oleh : <a>Pelajar Latihan Industri UiTM</a></p>
    </font>
    <br class="clear" />
  </div>
</div>
<!-- ##############################################TUTuP BOTTOM######################################################### -->
