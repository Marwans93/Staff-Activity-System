<?php
	session_start();
	$nama = $_SESSION['nama'];
	$noStaff = $_SESSION['noStaff'];
	$jawatan = $_SESSION['jawatan'];
	
	if(!$_SESSION['register'])
		header('Location:../index.php');
	
	else
	{
		include '../penghubung/penghubung.php';
?>
<?php include ('header.php'); ?>
if($_POST["Tukar"])
{
$pass_lama = $_POST['pass_lama'];
$pass_baru = $_POST['pass_baru'];
$sah_pass = $_POST['sah_pass'];	

	
	$sql= mysql_query("SELECT * FROM pengguna WHERE id='$id'");
	$result = mysql_fetch_array($sql);
	
	$katalaluan1 = $result['katalaluan1'];
	
	

		if ($pass_lama == $katalaluan1)
			{
			
				if (strlen($pass_baru)<6)
				
				{ 	
					
					
					echo  "<script language='JavaScript'>alert('Katalaluan baru minimum 6 aksara.'); 
					document.location.href='laman_staf.php?action=link&what=tukar_katalaluan.php';</script>";
					
				}
				
				else
				
				{
				if($pass_baru == $sah_pass)
				{	
				
					mysql_query("UPDATE staf SET katalaluan1= '$sah_pass' WHERE id= '$id'");
					
					
					echo "<script language='JavaScript'>alert('Kemaskini katalaluan anda berjaya disimpan.'); 
					document.location.href='index.php';</script>";
				}

				else 
				{ 	
					echo "<script language='JavaScript'>alert('Sila isi katalaluan baru yang sama dengan sah katalaluan.'); 
					document.location.href='laman_staf.php?action=link&what=tukar_katalaluan.php';</script>";
					
				}
			}
			
		}
     else  
		{  
			echo "<script language='JavaScript'>alert('Sila isikan katalaluan yang betul.'); 
					document.location.href='laman_staf.php?action=link&what=tukar_katalaluan.php';</script>";
		}
	
}

?>