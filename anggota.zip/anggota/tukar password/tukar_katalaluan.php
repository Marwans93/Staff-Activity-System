<?php
	session_start();
	$nama = $_SESSION['nama'];
	$noStaff = $_SESSION['noStaff'];
	$jawatan = $_SESSION['jawatan'];
	
	if(!$_SESSION['register'])
		header('Location:../index.php');
	
	else
	{
		include '../penghubung/penghubung.php';
?>
<?php include ('header.php'); ?>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style1 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 14px;
	color: #000000;
}
.style6 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: small;
	font-weight: normal;
}
.style8 {	font-family: Arial, Helvetica, sans-serif;
	font-style: italic;
	font-size: x-small;
	color: #FF0000;
}
.style9 {
	font-family: Arial;
	font-size: 12px;
}
.style11 {font-size: 10px}
.style12 {color: #000000}
.style13 {font-family: Arial; font-size: 12px; color: #000000; }
-->
</style>
</head>
<body>
<p>&nbsp;</p>
<table width="458" height="279" border="0" align="center" cellpadding="0" cellspacing="0" bordercolor="#FFFFFF">
  <tr>
    <th width="463" height="277" bgcolor="#333333" scope="col">
     <form id="form2" name="form2" method="post" action="proses_tukar_katalaluan.php">
       <table width="445" border="0" align="center" cellpadding="4" cellspacing="1" bgcolor="#FFFFFF" class="2ndback">
         <tr>
           <th height="24" colspan="4" background="../images/pro_line_b2-1.gif"><span class="style1"> TUKAR KATALALUAN </span></th>
         </tr>
         <tr>
           <th colspan="4"><img src="../images/change_password3.gif" alt="" width="50" height="50" /></th>
         </tr>
         <tr>
           <td width="10%" align="left" valign="middle">&nbsp;</td>
           <td width="37%" align="left" valign="middle"><div align="right" class="style6">
               <div align="left" class="style13">Katalaluan Lama </div>
           </div></td>
           <td width="3%"><span class="style6">:</span></td>
           <td width="50%"><div align="left">
               <input type="password" name="pass_lama" id="pass_lama" maxlength="12" />
           </div></td>
         </tr>
         <tr>
           <td align="left" valign="middle">&nbsp;</td>
           <td align="left" valign="middle" class="style9"><div align="right" class="style6">
               <div align="left" class="style13">Katalaluan Baru</div>
           </div></td>
           <td><span class="style6">:</span></td>
           <td><p align="left" class="style8">
               <input type="password" name="pass_baru" id="pass_baru" maxlength="10" />
           </p></td>
         </tr>
         <tr>
           <td height="24" align="left" valign="middle">&nbsp;</td>
           <td height="24" align="left" valign="middle"><div align="right" class="style6">
               <div align="left" class="style13">Pengesahan Katalaluan</div>
           </div></td>
           <td><span class="style6">:</span></td>
           <td><div align="left">
               <input type="password" name="sah_pass" id="pass_baru" maxlength="10" />
           </div></td>
         </tr>
         <tr>
           <td height="21" colspan="4" align="center"><font color="#FF0000"> </font></td>
         </tr>
         <tr>
           <td colspan="4"><div align="center">
               <input name="Tukar" type="submit" id="Tukar" onclick="Javascript:if(confirm('ANDA PASTI?')){return true} else return false;" value="Tukar" />
           </div></td>
         </tr>
       </table>
     </form></th>
  </tr>
</body>
</table>