<!-- ########################################HEADER############################################################### -->
<div class="wrapper col0">
  <div id="topline">
    <p><font face="Arial, Helvetica, sans-serif">Log Masuk Sebagai: Anggota | |&nbsp;&nbsp;&nbsp;<a href="../proses_log_keluar.php">[LOG KELUAR]</a></font></p>
    <span class="fl_right"><a href="#"><img src="images/LOGO.png" alt="" /></a></span><br class="clear" />
  </div>
</div>
<!-- ###############################################TUTUP HEADER######################################################## -->

<!-- #############################################LOGO########################################################## -->
<div class="wrapper">
  <div id="header">
    <div class="fl_left">
      <h1><a href="#"><strong>W</strong>ho's In <strong>S</strong>istem</a></h1>
      <p>Status Keberadaan Anggota</p>
    </div>
    <div class="fl_right"></div>
    <br class="clear" />
  </div>
</div>

<!-- ##################################################TUTUP LOGO##################################################### -->