<font face="Arial, Helvetica, sans-serif" size="6">
  <a href="index.php">Tambah Bilik</a>
  </font>