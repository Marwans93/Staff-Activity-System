<?php
	session_start();
	$nama = $_SESSION['nama'];
	$noStaff = $_SESSION['noStaff'];
	$jawatan = $_SESSION['jawatan'];
	$status="";

	
	if(!$_SESSION['register'])
		header('Location:../index.php');
	
	else
	{
		include '../penghubung/penghubung.php';

		
		
		
		if(isset($_POST['limit']))
		{	
			$limitPapar = $_POST['limit'];
		}
		else
		{
			$limitPapar = "";
		}
		
		if(!$limitPapar == "")
		{
			$lc = $limitPapar;
		}
		else
		{
			$lc = "5";
		}
		
		
	//pagination
		if (isset($_GET["start"]))
		{	$start = $_GET["start"]; }
		else
		{	$start =''; }

			if(!isset($start))
				{ $start = 0; }                 
  
				$eu = ($start - 0);
				$limit = $lc;
				$thispage = $eu + $limit;
				$back = $eu - $limit;
				$next = $eu + $limit;
		
		
		
		
		
		
		
		
		if(isset($_REQUEST['submit']))
		{
			$aras = $_POST['aras'];
			$jenis = $_POST['jenisBilik'];
			$namaBilik = $_POST['namaBilik'];
			
			if(!$aras == "")
			{
				if(!$jenis == "")
				{ 
					
				
					$semak = mysql_query("select * from bilik where bilikNama = '$namaBilik' and bilikAras = '$aras'");
					$adaketak = mysql_num_rows($semak);
				
					if($adaketak == 0)
					{
						$select = "select * from bilik";
						$qSelect = mysql_query($select) or die (mysql_error());
						$dataSelect = mysql_num_rows($qSelect);
	
						$no = $dataSelect+1;
	
						while($semakID = mysql_fetch_array($qSelect))
						{
							if($no == $semakID['bilikNo'])
							{
								$tempahanNo = $no++;
							}
							else
							{	$tempahanNo = $no;}
						}
					
						$select2 = "select * from aras";
						$qSelect2 = mysql_query($select2) or die (mysql_error());
						$dataSelect2 = mysql_num_rows($qSelect2);
	
						$no2 = $dataSelect2+1;
	
						while($semakID2 = mysql_fetch_array($qSelect2))
						{
							if($no2 == $semakID2['arasId'])
							{
								$tempahanNo2 = $no2++;
							}
							else
							{	$tempahanNo2 = $no2;}
						}
					
					
					
						
						mysql_query("insert into bilik values('$no','$namaBilik','$jenis', '$aras')");
						$status = "tb";
					}
					else
					{	$status = "btsa";}
			}
			else
			{	$status = "jbtdm";}
		}
		else
		{	$status = "atdp";}
	}
	else
	{ $status ="";}	
	
	
	if(isset($_GET['id']))
		{
			$hapus = $_GET['id'];
			
			mysql_query("delete from bilik where bilikNo = '$hapus'");
			mysql_query("delete from aras where arasId = '$hapus'");
			$status = "bbd";
		
		}
		
	
	if(!$status=="")
	{
		if($status == "atdp")
		{
			$paparStatus = "<font face='Arial, sans-serif' size='2' color='red'>Aras Tidak Dipilih!</font>";
		}
		elseif($status == "jbtdm")
		{
			$paparStatus = "<font face='Arial, sans-serif' size='2' color='red'>Jenis Bilik Tidak Dipilih!</font>";
		}
		elseif($status == "tb")
		{
			$paparStatus = "<font face='Arial, sans-serif' size='2' color='green'>Tambah Berjaya!</font>";
		}
		elseif($status == "btsa")
		{
			$paparStatus = "<font face='Arial, sans-serif' size='2' color='red'>Bilik Telah Sedia Ada!</font>";
		}
		elseif($status == "bbd")
		{
			$paparStatus = "<font face='Arial, sans-serif' size='2' color='red'>Bilik Berjaya Dihapuskan!</font>";
		}
	}
	else
	{
		$paparStatus= "&nbsp;";
	}
	
	
?>
<!DOCTYPE>
<html xml:lang="EN" lang="EN" dir="ltr">
<head>
<title>WHO'S IN SISTEM</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="scripts/jquery.timers.1.2.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.2.1.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.setup.js"></script>
</head>
<body id="top">
<!-- ########################################HEADER############################################################### -->
<?php include '../header.php';?>

<!-- ##################################################TUTUP LOGO##################################################### -->

<!-- #################################################MENU###################################################### -->
<?php include 'menu.php';?>
<!-- #####################################################TUTUP MENU################################################## -->
<!-- ##################################################MAKLUMAT PENGUNA##################################################### -->
<div class="wrapper">
  <div class="container">
  <?php include 'tajuk_tambah_bilik.php'; ?>
  </div>
</div>
<!-- #################################################TUTUP MAKLUMAT PENGGUNA###################################################### -->
<!-- ###############################################BODY######################################################## -->
<div class="wrapper">
<div class="container">

	<table border="1">
	<tr class="light"><form action="index.php" method="post">
		<td align="center"><font face="Arial, sans-serif" size="2">Aras: 
		<select name="aras">
			<option value="">Pilih Aras</option>
			<option value="Aras 1">Aras 1</option>
			<option value="Aras 2">Aras 2</option>
			<option value="Aras 3">Aras 3</option>
			<option value="Aras 4">Aras 4</option>
			<option value="Aras 5">Aras 5</option>
			<option value="Aras 6">Aras 6</option>
			<option value="Aras 7">Aras 7</option>
			<option value="Aras 8">Aras 8</option>
			<option value="Aras 9">Aras 9</option>
			<option value="Aras 10">Aras 10</option>
			<option value="Aras 11">Aras 11</option>
		</select>
		
		Jenis Bilik : 
		
		<select name="jenisBilik">
			<option value="">Pilih Jenis Bilik</option>
			<option value="Bilik Makmal">Bilik Makmal</option>
			<option value="Bilik Mesyuarat">Bilik Mesyuarat</option>
		</select>
		
		Nama Bilik: <input type="text" name="namaBilik" placeholder="Nama Bilik Baru" size="80" required>
		</font>
		</td>
			
	</tr>
	<tr class="light">
		<td><div id="respond" align="center"><input type="submit" name="submit" value="Tambah"></div></td>
	</tr></form>
	</table>
	
	
	
	

   <div align="center"> <?php echo $paparStatus;?></div>
    <br>
    <table summary="Summary Here" cellpadding="0" cellspacing="0" border="1">
      <thead>
    <tr>
       <th colspan="6"><font face="Arial, sans-serif" size="2">Senarai Bilik : </font></th>        
    </tr>
    </thead>
    <tbody>
    <tr class="dark">
       <th width="4%"><font face="Arial, sans-serif" size="2">Bil.</font></th>
       <th width="65%"><font face="Arial, sans-serif" size="2">Nama Bilik</font></th>
       <th width="10%"><font face="Arial, sans-serif" size="2">Aras</font></th>
       <th width="20%"><font face="Arial, sans-serif" size="2">Jenis Bilik</font></th>
       <th width="1%">&nbsp;</th>
    </tr>
    <?php
		$bil = $start + 1;
		$bilik = mysql_query("select * from bilik order by bilikNama asc limit $eu,$limit");
		
		while($dataBilik = mysql_fetch_array($bilik))
		{
	?>
     <tr class="light">        
        <td><font face="Arial, sans-serif" size="2"><?php echo $bil++;?></font></td>
        <td><font face="Arial, sans-serif" size="2"><?php echo $dataBilik['bilikNama'];?></font></td>
        <td><font face="Arial, sans-serif" size="2"><?php echo $dataBilik['bilikAras'];?></font></td>
        <td><font face="Arial, sans-serif" size="2"><?php echo $dataBilik['bilikJenis'];?></font></td>
        <td>
		<a href="index.php?id=<?php echo $dataBilik['bilikNo']; ?>"><img src="../images/padam11.png" onClick="this.src='../images/padam11.png'" onMouseOver="this.src='../images/padam22.png'" onMouseOut="this.src='../images/padam11.png'" title="Padam Bilik Ini"></a></td>
     </tr>
     <?php
		}
		$rows = mysql_num_rows(mysql_query("select * from bilik"));
		$bilrow1 = $rows;
	 ?>
      <tr>        	<form action="index.php" method="post">
     	<td colspan="6"><font face="Arial, sans-serif" size="2">Bilangan Semua Bilik : <?php echo $bilrow1;?>   ||
		  <?php
	
		

         if($back >= 0)
         	{ 
		
			?>
            <a href="index.php?start=<?php echo $back;?>" ><<</a>
            
            <?php
			}
         $j=0;
         $l=1;

         for($j=0; $j<$bilrow1; $j=$j+$limit)
         {
           if($j <> $eu)
           { 
		   ?>
           <a href="index.php?start=<?php echo $j;?>"><?php echo $l;?></a>
           <?php
		   }
           else
           { 
		   ?>
           <font face="Arial, sans-serif" size="2" color="#FF0000"><?php echo $l;?></font>
           <?php
   			}
           $l=$l+1;
         }

         if($thispage < $bilrow1)
         { echo "&nbsp;&nbsp;<a href='index.php?start=$next'>>></a>";}

?>
        
        || Limit paparan: </font>
	
		<select name="limit" onChange="this.form.submit();">
			<option value="5" <?php 
			if($lc == "5")
			{ echo "selected";}
			else
			{ echo "";}
			?>>5</option>
			<option value="10" <?php
			if($lc=="10")
			{ echo "selected";}
			else
			{ echo "";}
			?>>10</option>
			<option value="15" <?php 
			if($lc == "15")
			{ echo "selected";}
			else
			{ echo "";}
			?>>15</option>
			<option value="20" <?php 
			if($lc == "20")
			{ echo "selected";}
			else
			{ echo "";}
			?>>20</option>
		</form></td>
     </tr>
    </tbody>
    </table>
    
    </div>
    <br class="clear" />
</div>
<!-- #################################################TUTUP BODY###################################################### -->
<!-- #####################################################SPACE################################################## -->
<div id="adblock">
<br class="clear" />
</div>
<!-- #################################################TUTUP SPACE###################################################### -->

<!-- ##############################################BOTTOM######################################################### -->
<?php include '../footer.php';?>
<!-- ##############################################TUTuP BOTTOM######################################################### -->
</body>
</html>
<?php } ?>