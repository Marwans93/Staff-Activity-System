
<!-- ##################################################MAKLUMAT PENGUNA##################################################### -->
  <div class="column">
    
	<?php
		$gambar = "select * from gambar where gambarPenggunaID = '$noStaff'";
		$qGambar = mysql_query($gambar) or die (mysql_error());
		$dataGambar = mysql_fetch_array($qGambar);
	?>
	
    <table border="5">
	
    <tr>
    	<th colspan="3" align="center" bgcolor="#CCCCCC"><font face="Arial, Helvetica, sans-serif" size="2" >Maklumat Pengguna</font></th>
		
    </tr>
    <tr>
    	<td rowspan="3" width="55" align="center"><img src="../<?php echo $dataGambar['gambarAlamat'];?>" width="57" height="69" /></td>
        <td><font face="Arial, Helvetica, sans-serif" size="2" >Nama</font></td>
		<td><font face="Arial, Helvetica, sans-serif" size="2" ><?php echo $nama;?></font></td>
    </tr>
	<tr>
		<td><font face="Arial, Helvetica, sans-serif" size="2" >No. Staf</font></td>
		<td><font face="Arial, Helvetica, sans-serif" size="2" ><?php echo $noStaff;?></font></td>
	</tr>
	<tr>
		<td colspan="3">
			<a href="../proses_log_keluar.php"><font face="Arial, Helvetica, sans-serif" size="2" >[LOG KELUAR]</font></a>
        </td>
    </tr>
    
    </table> 
    </div>
    <br class="clear" />
<!-- #################################################TUTUP MAKLUMAT PENGGUNA###################################################### -->