<!-- ###############################################BODY######################################################## -->
<div class="wrapper">
<div id="adblock">
  <p align="center">
<?php

	$dbhost = 'localhost';
	$dbuser = 'root';
	$dbpass = '';
	$dbname = 'in_out_board';
	
	mysql_connect($dbhost, $dbuser,$dbpass,$dbname) or die(mysql_error());
	mysql_select_db($dbname) or die(mysql_error());
?>
<?php
	$anggota = mysql_query("select * from anggota where anggotaID = '$noStaff'");
	$dataAnggota = mysql_fetch_array($anggota);
?>

  <table>
  <tr class="light">	
    <thead>
  	<th colspan="3"><font face="Arial, Helvetica, sans-serif" size="2">Status Keluar</font></th>
   </thead>
  </tr>
  <tbody>
  <tr class="dark">
  	<td width="24%"><font face="Arial, Helvetica, sans-serif" size="2">Nama</font></td>
    <td width="1%">:</td>
    <td width="75%"><font face="Arial, Helvetica, sans-serif" size="2"><?php echo $nama;?></font></td>
   </tr>
    <tr class="light">
  	<td width="24%"><font face="Arial, Helvetica, sans-serif" size="2">Nombor IC</font></td>
    <td width="1%">:</td>
    <td width="75%"><font face="Arial, Helvetica, sans-serif" size="2"><?php echo $dataAnggota['anggotaIC'];?></font></td>
   </tr>
    <tr class="dark">
  	<td width="24%"><font face="Arial, Helvetica, sans-serif" size="2">Jabatan</font></td>
    <td width="1%">:</td>
    <td width="75%"><font face="Arial, Helvetica, sans-serif" size="2"><?php echo $dataAnggota['anggotaJabatan'];?></font></td>
   </tr>
    <tr class="light">
  	<td width="24%"><font face="Arial, Helvetica, sans-serif" size="2">Email</font></td>
    <td width="1%">:</td>
    <td width="75%"><font face="Arial, Helvetica, sans-serif" size="2"><?php echo $dataAnggota['anggotaEmail'];?></font></td>
   </tr>
    <tr class="dark">
  	<td width="24%"><font face="Arial, Helvetica, sans-serif" size="2">Nombor Telefon</font></td>
    <td width="1%">:</td>
    <td width="75%"><font face="Arial, Helvetica, sans-serif" size="2"><?php echo $dataAnggota['anggotaNoTel'];?></font></td>
	<tr class="dark">
  	<td width="24%"><font face="Arial, Helvetica, sans-serif" size="2">Masa</font></td>
    <td width="1%">:</td>
    <td width="75%"><font face="Arial, Helvetica, sans-serif" size="2"></font></td>
	<tr class="dark">
  	<td width="24%"><font face="Arial, Helvetica, sans-serif" size="2">Tarikh</font></td>
    <td width="1%">:</td>
    <td width="75%"><font face="Arial, Helvetica, sans-serif" size="2"></font></td>
        </font>
      </form></td>
  	</tr>
   </tbody>
   </table>
</div>
<!-- #################################################TUTUP BODY###################################################### -->