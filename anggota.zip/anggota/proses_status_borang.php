<?php

 	include '../penghubung/penghubung.php';
	
	$tarikh = $_POST['statusTarikh'];
	$nama = $_POST['anggotaNama'];
	$tujuan = $_POST['statusTujuan'];
	$timeKeluar = $_POST['statusKeluar'];
	$timeMasuk = $_POST['statusMasuk'];
	$pegawai = $_POST['statusKebenaran'];
	

			mysql_query("insert into status values ('$statusTarikh','$anggotaNama','$statusTujuan','$statusKeluar','statusMasuk','statusKebenaran')") or die (mysql_error());
				
			$maklum = $anggotaNama." Permohonan Berjaya Dihantar!";
			
			header("Location:index.php?status=$maklum");

$sqldata = mysql_query($dbconnect,$sqlget) or die ('Permohonan Tidak Berjaya Dihantar!');
	
	?>