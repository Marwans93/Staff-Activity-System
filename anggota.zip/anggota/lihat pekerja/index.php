<?php
	session_start();
	$nama = $_SESSION['nama'];
	$noStaff = $_SESSION['noStaff'];
	$jawatan = $_SESSION['jawatan'];
	$cariJabatan = "";
	
	if(!$_SESSION['register'])
		header('Location:../index.php');
	
	else
	{
		include '../penghubung/penghubung.php';

		
		
		
		if(isset($_GET['limit']))
		{	
			$limitPapar = $_GET['limit'];
		}
		else
		{
			$limitPapar = "";
		}
		
		if(!$limitPapar == "")
		{
			$lc = $limitPapar;
		}
		else
		{
			$lc = "5";
		}
		
		
	//pagination
		if (isset($_GET["start"]))
		{	$start = $_GET["start"]; }
		else
		{	$start =''; }

			if(!isset($start))
				{ $start = 0; }                 
  
				$eu = ($start - 0);
				$limit = $lc;
				$thispage = $eu + $limit;
				$back = $eu - $limit;
				$next = $eu + $limit;
				
				
				
				//check
				
	if(isset($_REQUEST['submit']))
	{
		$button = $_REQUEST['submit'];
	}
	else
	{
		$button = "";
	}
	
	if($button == "")
	{
				
		$pekerja = "select * from pekerja limit $eu, $limit";
		$queryPekerja = mysql_query($pekerja) or die (mysql_error());
		
		$semua = "select * from pekerja";
		$querySemua = mysql_query($semua) or die (mysql_error());
		$rows = mysql_num_rows($querySemua);
				
	}
	elseif(isset($button))
	{	
		if($button == "Cari")
		{
			if(isset($_POST['cari']))
			{	
				$search = $_POST['cari'];
			}
			
			else
			{
				$search = '';
			}
				
			if(isset($search))
			{
				if($search == "")
				{
					$pekerja = "select * from pekerja limit $eu, $limit";
					$queryPekerja = mysql_query($pekerja) or die (mysql_error());
		
					$semua = "select * from pekerja";
					$querySemua = mysql_query($semua) or die (mysql_error());
					$rows = mysql_num_rows($querySemua);
				}
				else
				{
					$pekerja = "select * from pekerja where pekerjaIC like '%$search%' limit $eu, $limit";
					$queryPekerja = mysql_query($pekerja) or die (mysql_error());
					$rows = mysql_num_rows($queryPekerja);
				}
			}
			
		}
		elseif($button=="Cari Jabatan")
		{
		
			if(isset($_POST['cariJabatan']))
			{
				$cariJabatan = $_POST['cariJabatan'];
			}
	
			else
			{
				$cariJabatan = '';
			}
		
			
			if(isset($cariJabatan))
			{
				if($cariJabatan == "")
				{
					$pekerja = "select * from pekerja limit $eu, $limit";
					$queryPekerja = mysql_query($pekerja) or die (mysql_error());
		
					$semua = "select * from pekerja";
					$querySemua = mysql_query($semua) or die (mysql_error());
					$rows = mysql_num_rows($querySemua);
				}
				else{
				$pekerja = "select * from pekerja where pekerjaJabatan like '%$cariJabatan%' limit $eu, $limit";
				$queryPekerja = mysql_query($pekerja) or die (mysql_error());
				$rows = mysql_num_rows($queryPekerja);
				}
			}
			
		}
		elseif($button == "Lihat Semua")
		{
					
				
				
				
					$semua = "select * from pekerja";
					$querySemua = mysql_query($semua) or die (mysql_error());
					$rows = mysql_num_rows($querySemua);
				
					$eu = 0;
					$limit = $rows;
					$thispage = $eu + $limit;
					$back = $eu - $limit;
					$next = $eu + $limit;	
					
					$pekerja = "select * from pekerja limit $eu,$limit";
					$queryPekerja = mysql_query($pekerja) or die (mysql_error());
		}
		
	}
	
	if(isset($_GET['status']))
	{
		$status = $_GET['status'];
		if($status == "pbd")
		{
			$paparStatus = "<font face='Arial, sans-serif' size='2' color='red'>Pekerja Berjaya Dihapuskan!</font>";
		}
	}
	else
	{
		$paparStatus= "&nbsp;";
	}
	
	
?>
<!DOCTYPE>
<html xml:lang="EN" lang="EN" dir="ltr">
<head>
<title>Sistem Tempahan</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="scripts/jquery.timers.1.2.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.2.1.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.setup.js"></script>
</head>
<body id="top">
<!-- ########################################HEADER############################################################### -->
<?php include '../header.php';?>

<!-- ##################################################TUTUP LOGO##################################################### -->

<!-- #################################################MENU###################################################### -->
<?php include 'menu.php';?>
<!-- #####################################################TUTUP MENU################################################## -->
<!-- ##################################################MAKLUMAT PENGUNA##################################################### -->
<div class="wrapper">
  <div class="container">
  <?php include 'tajuk_lihat_pekerja.php'; ?>
  </div>
</div>
<!-- #################################################TUTUP MAKLUMAT PENGGUNA###################################################### -->
<!-- ###############################################BODY######################################################## -->
<div class="wrapper">
<div class="container">


<table>
<tr class="light">
<td width="40%"><div align="center" id="respond">
	<form action="index.php" method="post">
	<input type="text" name="cari" placeholder="Cari Nombor IC"> 
    <input type="submit" name="submit" value="Cari">
	</form>
</td>
<td width="40%"><div align="center" id="respond">
	<form action="index.php" method="post">
	<select name="cariJabatan">
		<option value="">Cari Jabatan
    	<?php 
			$jabatan = mysql_query("select * from jabatan");
		
			while($dataJabatan = mysql_fetch_array($jabatan))
			{
				if($cariJabatan == $dataJabatan['jabatanNama'])
				{
		?></option>
    	<option selected value="<?php echo $dataJabatan['jabatanNama'];?>"><?php echo $dataJabatan['jabatanNama'];?>
		<?php
				}
				else
				{
		?>
    	</option>
		<option value="<?php echo $dataJabatan['jabatanNama'];?>"><?php echo $dataJabatan['jabatanNama'];?>
		
		<?php 
				}
			}
		?></option>
	</select>
	<input type="submit" name="submit" value="Cari Jabatan">
    </form></div>
</td>
<td><div align="center" id="respond">
<form action="index.php" method="post">
<input type="submit" name="submit" value="Lihat Semua">
</form>
</div>
</td>
</tr>
</table>


   <div align="center"> <?php echo $paparStatus;?></div>
    <br>
    <table summary="Summary Here" cellpadding="0" cellspacing="0" border="1">
      <thead>
    <tr>
       <th colspan="6"><font face="Arial, sans-serif" size="2">Biodata Anggota : </font></th>        
    </tr>
    </thead>
    <tbody>
    <tr class="dark">
       <th width="34%"><font face="Arial, sans-serif" size="2">Nama</font></th>
       <th width="20%"><font face="Arial, sans-serif" size="2">Nombor IC</font></th>
       <th width="20%"><font face="Arial, sans-serif" size="2">Jabatan</font></th>
       <th width="15%"><font face="Arial, sans-serif" size="2">Email</font></th>
       <th width="10%"><font face="Arial, sans-serif" size="2">Nombor Telifon</font></th>
       <th width="1%">&nbsp;</th>
    </tr>
    <?php
		
		while($dataPekerja = mysql_fetch_array($queryPekerja))
		{	
			$AmbilNama = $dataAnggota['AnggotaID'];
			
			$Anggota = mysql_query("select AnggotaNama from Anggota where AnggotaID = '$AmbilNama'");
			$dataAnggota = mysql_fetch_array($Anggota);
	?>
     <tr class="light">        
        <td><font face="Arial, sans-serif" size="2"><?php echo $dataAnggota['AnggotaNama'];?></font></td>
        <td><font face="Arial, sans-serif" size="2"><?php echo $dataAnggota['AnggotaIC'];?></font></td>
        <td><font face="Arial, sans-serif" size="2"><?php echo $dataAnggota['AnggotaJabatan'];?></font></td>
        <td><font face="Arial, sans-serif" size="2"><?php echo $dataAnggota['AnggotaEmail'];?></font></td>
        <td><font face="Arial, sans-serif" size="2"><?php echo $dataAnggota['AnggotaTelifon'];?></font></td>
        <td>
		<a href="proses_padam.php?id=<?php echo $dataAnggota['AnggotaID']; ?>"><img src="../images/padam11.png" onClick="this.src='../images/padam11.png'" onMouseOver="this.src='../images/padam22.png'" onMouseOut="this.src='../images/padam11.png'" title="Padam Pekerja Ini"></a></td>
     </tr>
     <?php
		}
		
		$bilrow1 = $rows;
	 ?>
      <tr>        	<form action="index.php" method="get">
     	<td colspan="6"><font face="Arial, sans-serif" size="2">Bilangan Semua Anggota : <?php echo $bilrow1;?>   ||
		  <?php
	
		

         if($back >= 0)
         	{ 
		
			?>
            <a href="index.php?start=<?php echo $back;?>&limit=<?php echo $lc;?>" ><<</a>
            
            <?php
			}
         $j=0;
         $l=1;

         for($j=0; $j<$bilrow1; $j=$j+$limit)
         {
           if($j <> $eu)
           { 
		   ?>
           <a href="index.php?start=<?php echo $j;?>&limit=<?php echo $lc;?>"><?php echo $l;?></a>
           <?php
		   }
           else
           { 
		   ?>
           <font face="Arial, sans-serif" size="2" color="#FF0000"><?php echo $l;?></font>
           <?php
   			}
           $l=$l+1;
         }

         if($thispage < $bilrow1)
         { echo "&nbsp;&nbsp;<a href='index.php?start=$next&limit=$lc'>>></a>";}

?>
        
        || Limit paparan: </font>
	
		<select name="limit" onChange="this.form.submit();">
			<option value="5" <?php 
			if($lc == "5")
			{ echo "selected";}
			else
			{ echo "";}
			?>>5</option>
			<option value="10" <?php
			if($lc=="10")
			{ echo "selected";}
			else
			{ echo "";}
			?>>10</option>
			<option value="15" <?php 
			if($lc == "15")
			{ echo "selected";}
			else
			{ echo "";}
			?>>15</option>
			<option value="20" <?php 
			if($lc == "20")
			{ echo "selected";}
			else
			{ echo "";}
			?>>20</option>
		</form></td>
     </tr>
    </tbody>
    </table>
    
    </div>
    <br class="clear" />
</div>
<!-- #################################################TUTUP BODY###################################################### -->
<!-- #####################################################SPACE################################################## -->
<div id="adblock">
<br class="clear" />
</div>
<!-- #################################################TUTUP SPACE###################################################### -->

<!-- ##############################################BOTTOM######################################################### -->
<?php include '../footer.php';?>
<!-- ##############################################TUTuP BOTTOM######################################################### -->
</body>
</html>
<?php } ?>