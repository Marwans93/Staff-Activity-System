<?php
	
	include '../penghubung/penghubung.php';	
	
		$anggota = mysql_query("select * from anggota where anggotaID = '$noStaff'");
		$dataAnggota = mysql_fetch_array($anggota);			
?>
<!doctype html>

<head>

	<!-- Basics -->
	
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	
	<title>WHO'S IN SISTEM</title>

	<!-- CSS -->
	
	<link rel="stylesheet" href="../css/reset.css">
	<link rel="stylesheet" href="../css/animate.css">
	<link rel="stylesheet" href="../css/styles.css">
	
</head>

	<!-- Main HTML -->
	
<body>
	
	<!-- Begin Page Content -->
	<p align="center">
	<img src="../images/logo.gif" width="650" height="650"></p>
	
	<div id="container2">
	<font face="arial" size="+1"><br>
	<p align="center">BORANG KELUAR MASUK ANGGOTA</p></font>
	<br>
	<hr>
	<!-- ################################################################################################-->
	
		
		<table>
		<tr> 
        <form action="../anggota/proses_status_borang.php" method="post" enctype="multipart/form-data">
        <tr>
			<td><label for="date">Tarikh :</label></td>
			<td><input type="text" value="<?php
echo date('Y-m-d');
?>"></td>
		</tr>
		<tr>			
			<td><label for="text">Nama Anggota:</label></td             >
			<td><input type="text" name="nama" id="input3"value="<?php echo $anggotaNama;?>"> </td>
         </tr>
		<tr>
			<td><label for="text">Tujuan Urusan Rasmi & Tidak Rasmi:</label></td>
			<td><input type="text"  id="input3" name="tujuan" placeholder="XXXXXX" required /></td>
		</tr>
		<tr>
			<td><label for="time">Masa Keluar:</label></td>
			<td><input type="text" value="<?php
echo date('H:m:s');
?>"></td>
		</tr>
		<tr>
			<td><label for="time">Masa Masuk:</label></td>
			<td><input type="text"  id="input3" name="timeMasuk" placeholder="08:40" readonly/></td>
		</tr>
        <tr>
			<td><label for="checkbox">Kelulusan Pegawai Penyelia:</label></td>
			<td><input type="checkbox"id="input3" name="pegawai" checked>Pegawai A</td>
		</tr>
		</table>
		<div id="lower">
		
		<input type="submit" name="daftar" value="Hantar">
		<input type="reset" class="input2" name="reset" value="Bersih">
		<br><br><br>
		<p align="left"><a href="../index.php"><font face="Arial" size="-1">Pergi Ke Log In</font></a></p>
		
		</div>
		
		</form>
		<br><br>
		<p align="center"><font face="arial" size="-2" color="Black">
			Dec 2014 - Mac 2015 - All Rights Reserved - Perbadanan Kemajuan Iktisad Negeri Kelantan <br>
			Dibina oleh : Pelajar Latihan Industri UiTM
			</font>
		</p>
	</div>
	
	
	
	<!-- End Page Content -->
	
</body>

</html>
	
	
	
	
	
		
	