<?php
	session_start();
	$nama = $_SESSION['nama'];
	$noStaff = $_SESSION['noStaff'];
	$jawatan = $_SESSION['jawatan'];
	$cariJabatan = "";
		$tarikhMula = "";
		
	if(!$_SESSION['register'])
		header('Location:../index.php');
	
	else
	{
		include '../penghubung/penghubung.php';

		
		
		
		if(isset($_POST['limit']))
		{	
			$limitPapar = $_POST['limit'];
		}
		else
		{
			$limitPapar = "";
		}
		
		if(!$limitPapar == "")
		{
			$lc = $limitPapar;
		}
		else
		{
			$lc = "5";
		}
		
		
	//pagination
		if (isset($_GET["start"]))
		{	$start = $_GET["start"]; }
		else
		{	$start =''; }

			if(!isset($start))
				{ $start = 0; }                 
  
				$eu = ($start - 0);
				$limit = $lc;
				$thispage = $eu + $limit;
				$back = $eu - $limit;
				$next = $eu + $limit;
				
				
				
				//check
				
	if(isset($_REQUEST['submit']))
	{
		$button = $_REQUEST['submit'];
	}
	else
	{
		$button = "";
	}
	
	if($button == "")
	{
				
		$pekerja = "select * from tempahan order by tempahanTarikh desc limit $eu, $limit";
		$queryPekerja = mysql_query($pekerja) or die (mysql_error());
		
		$semua = "select * from tempahan";
		$querySemua = mysql_query($semua) or die (mysql_error());
		$rows = mysql_num_rows($querySemua);
				
	}
	elseif(isset($button))
	{	
		if($button == "Cari")
		{
			if(isset($_POST['cari']))
			{	
				$search = $_POST['cari'];
			}
			
			else
			{
				$search = '';
			}
				
			if(isset($search))
			{
				if($search == "")
				{
					$pekerja = "select * from tempahan order by tempahanTarikh desc limit $eu, $limit";
					$queryPekerja = mysql_query($pekerja) or die (mysql_error());
		
					$semua = "select * from tempahan";
					$querySemua = mysql_query($semua) or die (mysql_error());
					$rows = mysql_num_rows($querySemua);
				}
				else
				{
					$pekerja = "select * from tempahan where tempahanTarikh like '%$search%' order by tempahanTarikh desc limit $eu, $limit";
					$queryPekerja = mysql_query($pekerja) or die (mysql_error());
					$rows = mysql_num_rows($queryPekerja);
				}
			}
			
		}
		elseif($button=="Cari Jenis Bilik")
		{
		
			if(isset($_POST['cariJabatan']))
			{
				$cariJabatan = $_POST['cariJabatan'];
			}
	
			else
			{
				$cariJabatan = '';
			}
		
			
			if(isset($cariJabatan))
			{
				if($cariJabatan == "")
				{
					$pekerja = "select * from tempahan order by tempahanTarikh desc limit $eu, $limit";
					$queryPekerja = mysql_query($pekerja) or die (mysql_error());
		
					$semua = "select * from tempahan";
					$querySemua = mysql_query($semua) or die (mysql_error());
					$rows = mysql_num_rows($querySemua);
				}
				else{
				$pekerja = "select * from tempahan where tempahanJenis like '%$cariJabatan%' order by tempahanTarikh desc limit $eu, $limit";
				$queryPekerja = mysql_query($pekerja) or die (mysql_error());
				$rows = mysql_num_rows($queryPekerja);
				}
			}
			
		}
		elseif($button == "Lihat Semua")
		{
					
				
				
				
					$semua = "select * from tempahan order by tempahanTarikh desc";
					$querySemua = mysql_query($semua) or die (mysql_error());
					$rows = mysql_num_rows($querySemua);
				
					$eu = 0;
					$limit = $rows;
					$thispage = $eu + $limit;
					$back = $eu - $limit;
					$next = $eu + $limit;	
					
					$pekerja = "select * from tempahan order by tempahanTarikh desc limit $eu,$limit";
					$queryPekerja = mysql_query($pekerja) or die (mysql_error());
		}
		
	}
	
	if(isset($_GET['status']))
	{
		$status = $_GET['status'];
		if($status == "ttd")
		{
			$paparStatus = "<font face='Arial, sans-serif' size='2' color='red'>Tempahan Telah Dibatalkan!</font>";
		}
	}
	else
	{
		$paparStatus= "&nbsp;";
	}
	
	
?>
<!DOCTYPE>
<html xml:lang="EN" lang="EN" dir="ltr">
<head>
<title>Sistem Tempahan</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="scripts/jquery.timers.1.2.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.2.1.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.setup.js"></script>
<script type="text/javascript" src="datetimepicker-master/jquery.js"></script>
<script type="text/javascript" src="datetimepicker-master/jquery.datetimepicker.js"></script>
<script type="text/javascript">
$('#datetimepicker2').datetimepicker({
	yearOffset:0,
	lang:'ml',
	timepicker:false,
	format:'Y-m-d',
	formatDate:'Y/m/d',
	minDate:'-2000/01/02', // yesterday is minimum date
	maxDate:'+2020/01/02' // and tommorow is maximum date calendar
});
</script>
</head>
<body id="top">
<!-- ########################################HEADER############################################################### -->
<?php include '../header.php';?>

<!-- ##################################################TUTUP LOGO##################################################### -->

<!-- #################################################MENU###################################################### -->
<?php include 'menu.php';?>
<!-- #####################################################TUTUP MENU################################################## -->
<!-- ##################################################MAKLUMAT PENGUNA##################################################### -->
<div class="wrapper">
  <div class="container">
  <?php include 'tajuk_lihat_tempahan.php'; ?>
  </div>
</div>
<!-- #################################################TUTUP MAKLUMAT PENGGUNA###################################################### -->
<!-- ###############################################BODY######################################################## -->
<div class="wrapper">
<div class="container">


<table>
<tr class="light">
<td width="40%"><div align="center" id="respond">
	<form action="index.php" method="post">
    <input type="date" id="datetimepicker2" name="cari" placeholder="Pilih Tarikh" value="<?php echo $tarikhMula;?>">
    <input type="submit" name="submit" value="Cari">
	</form>
</td>
<td width="40%"><div align="center" id="respond">
	<form action="index.php" method="post"><div align="left"><font face="Arial, sans-serif" size="2">
	<input type="radio" name="cariJabatan" value="" hidden <?php
		if($cariJabatan == "")
		{ echo "checked";}
		else
		{	echo "";}
	?>>
	<input type="radio" name="cariJabatan" value="Bilik Makmal" <?php
		if($cariJabatan == "Bilik Makmal")
		{ echo "checked";}
		else
		{	echo "";}
	?>>Bilik Makmal
	<input type="radio" name="cariJabatan" value="Bilik Mesyuarat" <?php
		if($cariJabatan == "Bilik Mesyuarat")
		{ echo "checked";}
		else
		{	echo "";}
	?>>Bilik Mesyuarat</div></font>
	<input type="submit" name="submit" value="Cari Jenis Bilik">
    </form></div>
</td>
<td><div align="center" id="respond">
<form action="index.php" method="post">
<input type="submit" name="submit" value="Lihat Semua">
</form>
</div>
</td>
</tr>
</table>


   <div align="center"> <?php echo $paparStatus;?></div>
    <br>
    <table summary="Summary Here" cellpadding="0" cellspacing="0" border="1">
      <thead>
    <tr>
       <th colspan="8"><font face="Arial, sans-serif" size="2">Senarai Tempahan : </font></th>        
    </tr>
    </thead>
    <tbody>
    <tr class="dark">
       <th width="24%"><font face="Arial, sans-serif" size="2">Nama</font></th>
       <th width="8%"><font face="Arial, sans-serif" size="2">Tarikh</font></th>
       <th width="8%"><font face="Arial, sans-serif" size="2">Masa Mula</font></th>
       <th width="8%"><font face="Arial, sans-serif" size="2">Masa Akhir</font></th>
	   <th width="6%"><font face="Arial, sans-serif" size="2">Aras</font></th>
       <th width="35%"><font face="Arial, sans-serif" size="2">Tujuan</font></th>
	   <th width="10%"><font face="Arial, sans-serif" size="2">Jenis Tempahan</font></th>
       <th width="1%">&nbsp;</th>
    </tr>
    <?php
		
		while($dataPekerja = mysql_fetch_array($queryPekerja))
		{	
			$AmbilNama = $dataPekerja['tempahanID'];
			$AmbilNoTempahan = $dataPekerja['tempahanNo'];
			
			$pengguna = mysql_query("select penggunaNama from pengguna where penggunaID = '$AmbilNama'");
			$dataPengguna = mysql_fetch_array($pengguna);
			
			$tempahanBilik = mysql_query("select * from tempahanbilik where tempahanNo = '$AmbilNoTempahan'");
			$dataTempahanBilik = mysql_fetch_array ($tempahanBilik);
			
			$aras = $dataTempahanBilik['bilikNo'];
			
			$bilik = mysql_query("select bilikAras from bilik where bilikNo = '$aras'");
			$dataAras = mysql_fetch_array($bilik);
			
	?>
     <tr class="light">        
        <td><font face="Arial, sans-serif" size="2"><?php echo $dataPengguna['penggunaNama'];?></font></td>
        <td><font face="Arial, sans-serif" size="2"><?php echo $dataPekerja['tempahanTarikh'];?></font></td>
        <td><font face="Arial, sans-serif" size="2"><?php echo $dataPekerja['tempahanMula'];?></font></td>
        <td><font face="Arial, sans-serif" size="2"><?php echo $dataPekerja['tempahanAkhir'];?></font></td>
		<td><font face="Arial, sans-serif" size="2"><?php echo $dataAras['bilikAras'];?></font></td>
        <td><font face="Arial, sans-serif" size="2"><?php echo $dataPekerja['tempahanTujuan'];?></font></td>
		<td><font face="Arial, sans-serif" size="2"><?php echo $dataPekerja['tempahanJenis'];?></font></td>
        <td>
		<a href="proses_batal_tempahan.php?id=<?php echo $dataPekerja['tempahanNo']; ?>"><img src="../images/padam11.png" onClick="this.src='../images/padam11.png'" onMouseOver="this.src='../images/padam22.png'" onMouseOut="this.src='../images/padam11.png'" title="Batal Tempahan Ini"></a></td>
     </tr>
     <?php
		}
		
		$bilrow1 = $rows;
	 ?>
      <tr>        	<form action="index.php" method="post">
     	<td colspan="8"><font face="Arial, sans-serif" size="2">Bilangan Semua Tempahan : <?php echo $bilrow1;?>   ||
		  <?php
	
		

         if($back >= 0)
         	{ 
		
			?>
            <a href="index.php?start=<?php echo $back;?>" ><<</a>
            
            <?php
			}
         $j=0;
         $l=1;

         for($j=0; $j<$bilrow1; $j=$j+$limit)
         {
           if($j <> $eu)
           { 
		   ?>
           <a href="index.php?start=<?php echo $j;?>"><?php echo $l;?></a>
           <?php
		   }
           else
           { 
		   ?>
           <font face="Arial, sans-serif" size="2" color="#FF0000"><?php echo $l;?></font>
           <?php
   			}
           $l=$l+1;
         }

         if($thispage < $bilrow1)
         { echo "&nbsp;&nbsp;<a href='index.php?start=$next'>>></a>";}

?>
        
        || Limit paparan: </font>
	
		<select name="limit" onChange="this.form.submit();">
			<option value="5" <?php 
			if($lc == "5")
			{ echo "selected";}
			else
			{ echo "";}
			?>>5</option>
			<option value="10" <?php
			if($lc=="10")
			{ echo "selected";}
			else
			{ echo "";}
			?>>10</option>
			<option value="15" <?php 
			if($lc == "15")
			{ echo "selected";}
			else
			{ echo "";}
			?>>15</option>
			<option value="20" <?php 
			if($lc == "20")
			{ echo "selected";}
			else
			{ echo "";}
			?>>20</option>
		</form></td>
     </tr>
    </tbody>
    </table>
    
    </div>
    <br class="clear" />
</div>
<!-- #################################################TUTUP BODY###################################################### -->
<!-- #####################################################SPACE################################################## -->
<div id="adblock">
<br class="clear" />
</div>
<!-- #################################################TUTUP SPACE###################################################### -->

<!-- ##############################################BOTTOM######################################################### -->
<?php include '../footer.php';?>
<!-- ##############################################TUTuP BOTTOM######################################################### -->
</body>

</html>
<?php } ?>