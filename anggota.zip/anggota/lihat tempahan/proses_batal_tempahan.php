<?php
	$noTempahan = $_GET['id'];
	
	include '../penghubung/penghubung.php';
	
	$selectTempahan = mysql_query("select * from tempahan where tempahanNo = '$noTempahan'");
	$dataTempahan = mysql_fetch_array($selectTempahan);
	
	$masaAkhir = $dataTempahan['tempahanAkhir'];
	$masaMula = $dataTempahan['tempahanMula'];
	$tarikhMula = $dataTempahan['tempahanTarikh'];
	
	$selectBilik = mysql_query("select * from tempahanbilik where tempahanNo = '$noTempahan'");
	$dataBilik = mysql_fetch_array($selectBilik);
	
	$noBilik = $dataBilik['bilikNo'];
	
	//################# Start Masa ###################################
	
	//###########################################buka 9pg###########################################################
	
		if($masaAkhir=='9:00PG')
	{
		if($masaMula=='8:00PG')
		{
			$masa = "update masa
					set	pg8 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		
	}	
	
	
//##########################tutup 9pg#########################################
//##########################buka 5ptg#########################################	
	elseif($masaAkhir=="5:00PTG")
	{
		if($masaMula=="8:00PG")
		{
			$masa = "update masa
					set	pg8 = 'x',
						pg9 = 'x',
						pg10 = 'x',
						pg11 = 'x',
						ptg12 = 'x',
						ptg1 = 'x',
						ptg2 = 'x',
						ptg3 = 'x',
						ptg4 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="9:00PG")
		{
			$masa = "update masa
					set	pg9 = 'x',
						pg10 = 'x',
						pg11 = 'x',
						ptg12 = 'x',
						ptg1 = 'x',
						ptg2 = 'x',
						ptg3 = 'x',
						ptg4 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="10:00PG")
		{
			$masa = "update masa
					set	pg10 = 'x',
						pg11 = 'x',
						ptg12 = 'x',
						ptg1 = 'x',
						ptg2 = 'x',
						ptg3 = 'x',
						ptg4 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="11:00PG")
		{
			$masa = "update masa
					set	pg11 = 'x',
						ptg12 = 'x',
						ptg1 = 'x',
						ptg2 = 'x',
						ptg3 = 'x',
						ptg4 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="12:00PTG")
		{
			$masa = "update masa
					set	ptg12 = 'x',
						ptg1 = 'x',
						ptg2 = 'x',
						ptg3 = 'x',
						ptg4 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="1:00PTG")
		{
			$masa = "update masa
					set	ptg1 = 'x',
						ptg2 = 'x',
						ptg3 = 'x',
						ptg4 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="2:00PTG")
		{
			$masa = "update masa
					set	ptg2 = 'x',
						ptg3 = 'x',
						ptg4 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="3:00PTG")
		{
			$masa = "update masa
					set ptg3 = 'x',
						ptg4 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="4:00PTG")
		{
			$masa = "update masa
					set ptg4 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
	}
	
//##########################tutup 5ptg############################
//##########################buka 4ptg#########################################
	elseif($masaAkhir=="4:00PTG")
	{
		if($masaMula=="8:00PG")
		{
			$masa = "update masa
					set	pg8 = 'x',
						pg9 = 'x',
						pg10 = 'x',
						pg11 = 'x',
						ptg12 = 'x',
						ptg1 = 'x',
						ptg2 = 'x',
						ptg3 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="9:00PG")
		{
			$masa = "update masa
					set	pg9 = 'x',
						pg10 = 'x',
						pg11 = 'x',
						ptg12 = 'x',
						ptg1 = 'x',
						ptg2 = 'x',
						ptg3 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="10:00PG")
		{
			$masa = "update masa
					set	pg10 = 'x',
						pg11 = 'x',
						ptg12 = 'x',
						ptg1 = 'x',
						ptg2 = 'x',
						ptg3 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="11:00PG")
		{
			$masa = "update masa
					set	pg11 = 'x',
						ptg12 = 'x',
						ptg1 = 'x',
						ptg2 = 'x',
						ptg3 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="12:00PTG")
		{
			$masa = "update masa
					set	ptg12 = 'x',
						ptg1 = 'x',
						ptg2 = 'x',
						ptg3 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="1:00PTG")
		{
			$masa = "update masa
					set	ptg1 = 'x',
						ptg2 = 'x',
						ptg3 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="2:00PTG")
		{
			$masa = "update masa
					set	ptg2 = 'x',
						ptg3 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="3:00PTG")
		{
			$masa = "update masa
					set ptg3 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
	}
//##########################tutup 4ptg##################################################
//##########################buka 3ptg#########################################	
	elseif($masaAkhir=="3:00PTG")
	{
		if($masaMula=="8:00PG")
		{
			$masa = "update masa
					set	pg8 = 'x',
						pg9 = 'x',
						pg10 = 'x',
						pg11 = 'x',
						ptg12 = 'x',
						ptg1 = 'x',
						ptg2 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="9:00PG")
		{
			$masa = "update masa
					set	pg9 = 'x',
						pg10 = 'x',
						pg11 = 'x',
						ptg12 = 'x',
						ptg1 = 'x',
						ptg2 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="10:00PG")
		{
			$masa = "update masa
					set	pg10 = 'x',
						pg11 = 'x',
						ptg12 = 'x',
						ptg1 = 'x',
						ptg2 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="11:00PG")
		{
			$masa = "update masa
					set	pg11 = 'x',
						ptg12 = 'x',
						ptg1 = 'x',
						ptg2 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="12:00PTG")
		{
			$masa = "update masa
					set	ptg12 = 'x',
						ptg1 = 'x',
						ptg2 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="1:00PTG")
		{
			$masa = "update masa
					set	ptg1 = 'x',
						ptg2 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="2:00PTG")
		{
			$masa = "update masa
					set	ptg2 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		
	}
//##########################tutup 3ptg#########################################
//##########################buka 2ptg#########################################		
		elseif($masaAkhir=="2:00PTG")
	{
		if($masaMula=="8:00PG")
		{
			$masa = "update masa
					set	pg8 = 'x',
						pg9 = 'x',
						pg10 = 'x',
						pg11 = 'x',
						ptg12 = 'x',
						ptg1 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="9:00PG")
		{
			$masa = "update masa
					set	pg9 = 'x',
						pg10 = 'x',
						pg11 = 'x',
						ptg12 = 'x',
						ptg1 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="10:00PG")
		{
		
			$masa = "update masa
					set	pg10 = 'x',
						pg11 = 'x',
						ptg12 = 'x',
						ptg1 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="11:00PG")
		{
			$masa = "update masa
					set	pg11 = 'x',
						ptg12 = 'x',
						ptg1 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="12:00PTG")
		{
			$masa = "update masa
					set	ptg12 = 'x',
						ptg1 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="1:00PTG")
		{
			$masa = "update masa
					set	ptg1 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		
	}
//##########################tutup 2ptg#########################################
//##########################buka 1ptg#########################################		
		elseif($masaAkhir=="1:00PTG")
	{
		if($masaMula=="8:00PG")
		{
			$masa = "update masa
					set	pg8 = 'x',
						pg9 = 'x',
						pg10 = 'x',
						pg11 = 'x',
						ptg12 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="9:00PG")
		{
			$masa = "update masa
					set	pg9 = 'x',
						pg10 = 'x',
						pg11 = 'x',
						ptg12 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="10:00PG")
		{
			$masa = "update masa
					set	pg10 = 'x',
						pg11 = 'x',
						ptg12 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="11:00PG")
		{
			$masa = "update masa
					set	pg11 = 'x',
						ptg12 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="12:00PTG")
		{
			$masa = "update masa
					set	ptg12 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		
	}
//##########################tutup 1ptg#########################################
//##########################buka 12ptg#########################################		
		elseif($masaAkhir=="12:00PTG")
	{
		if($masaMula=="8:00PG")
		{
			$masa = "update masa
					set	pg8 = 'x',
						pg9 = 'x',
						pg10 = 'x',
						pg11 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="9:00PG")
		{
			$masa = "update masa
					set	pg9 = 'x',
						pg10 = 'x',
						pg11 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="10:00PG")
		{
			$masa = "update masa
					set	pg10 = 'x',
						pg11 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="11:00PG")
		{
			$masa = "update masa
					set	pg11 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		
	}
//##########################tutup 12ptg#########################################
//##########################buka 11pg#########################################		
		elseif($masaAkhir=="11:00PG")
	{
		if($masaMula=="8:00PG")
		{
			$masa = "update masa
					set	pg8 = 'x',
						pg9 = 'x',
						pg10 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="9:00PG")
		{
			$masa = "update masa
					set	pg9 = 'x',
						pg10 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="10:00PG")
		{
			$masa = "update masa
					set	pg10 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		
	}
//##########################tutup 11pg#########################################	
//##########################buka 10pg#########################################
		elseif($masaAkhir=="10:00PG")
	{
		if($masaMula=="8:00PG")
		{
			$masa = "update masa
					set	pg8 = 'x',
						pg9 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		elseif($masaMula=="9:00PG")
		{
			$masa = "update masa
					set	pg9 = 'x'
					where masaTarikh = '$tarikhMula' and masaBilikNo = '$noBilik'";
		}
		
	}
//#########################tutup 10pg##########################################	
		mysql_query($masa) or die(mysql_error());
	
	//#################tutup masa#####################################
	
	$tempahan = "delete from tempahan where tempahanNo = '$noTempahan'";
	mysql_query($tempahan) or die(mysql_error());
	
	$tempahanBilik = "delete from tempahanbilik where tempahanNo = '$noTempahan'";
	mysql_query($tempahanBilik) or die(mysql_error());
	
	$status = "ttd";
	header("Location: index.php?status=$status");

	?>