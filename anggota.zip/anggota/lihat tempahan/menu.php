<!-- #################################################MENU###################################################### -->
<div class="wrapper col2">
  <div id="topbar">
  <font face="Arial, Helvetica, sans-serif">
    <div id="topnav">
      <ul>
        <li><a href="../index.php">Utama</a></li>
        <li><a href="../lihat pekerja/index.php">Lihat Pekerja</a></li>
        <li class="active"><a href="index.php">Lihat Tempahan</a></li>
        <li><a href="#">Tambah</a>
          <ul>
            <li><a href="../jabatan/index.php">Jabatan</a></li>
            <li><a href="../bilik/index.php">Bilik</a></li>
          </ul>
        </li>
      </ul>
    </div>
    </font>
    <br class="clear" />
  </div>
</div>
<!-- #################################################TUTUP MENU###################################################### -->