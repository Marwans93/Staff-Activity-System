<!-- #################################################MENU###################################################### -->
<div class="wrapper col2">
  <div id="topbar">
  
    <div id="topnav">
      <ul>
        <li><font face="Arial, Helvetica, sans-serif"><a href="../index.php">Utama</a></font></li>
        <li><font face="Arial, Helvetica, sans-serif"><a href="../lihat pekerja/index.php">Lihat Anggota</a></font></li>
        <li><font face="Arial, Helvetica, sans-serif"><a href="../lihat tempahan/index.php">Lihat Keberadaan</a></font></li>
        <li class="active" ><font face="Arial, Helvetica, sans-serif"><a href="#">Tambah</a>
          </font><ul>
            <li><font face="Arial, Helvetica, sans-serif"><a href="../jabatan/index.php">Jabatan</a></font></li>
            <li><font face="Arial, Helvetica, sans-serif"><a href="../bilik/index.php">Bilik</a></font></li>
          </ul>
        </li>
      </ul>
    </div>
    
    <br class="clear" />
  </div>
</div>
<!-- #################################################TUTUP MENU###################################################### -->