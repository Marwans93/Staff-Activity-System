<?php
	session_start();
	$nama = $_SESSION['nama'];
	$noStaff = $_SESSION['noStaff'];
	$jawatan = $_SESSION['jawatan'];
	$status = "";
	
	if(!$_SESSION['register'])
		header('Location:../index.php');
	
	else
	{
		include '../penghubung/penghubung.php';

		
		if(isset($_GET['id']))
		{
			$padamJabatan = $_GET['id'];
			mysql_query("delete from jabatan where jabatanNo = '$padamJabatan'");
			$status = "jtdh";
		}
		
		
		
		
		if(isset($_POST['limit']))
		{	
			$limitPapar = $_POST['limit'];
		}
		else
		{
			$limitPapar = "";
		}
		
		if(!$limitPapar == "")
		{
			$lc = $limitPapar;
		}
		else
		{
			$lc = "5";
		}
		
		
	//pagination
		if (isset($_GET["start"]))
		{	$start = $_GET["start"]; }
		else
		{	$start =''; }

			if(!isset($start))
				{ $start = 0; }                 
  
				$eu = ($start - 0);
				$limit = $lc;
				$thispage = $eu + $limit;
				$back = $eu - $limit;
				$next = $eu + $limit;
				
	//tambah baru
	
	if(isset($_POST['tambahJabatan']))
	{
		$tambah = $_POST['tambahJabatan'];
		$tempahanNo = "";
		
		if(!$tambah == "")
		{
			$semak = mysql_query("select * from jabatan where jabatanNama = '$tambah'");
			$adaketak = mysql_num_rows($semak);
		
			if($adaketak == 0)
			{
				$select = "select * from jabatan";
				$qSelect = mysql_query($select) or die (mysql_error());
				$dataSelect = mysql_num_rows($qSelect);
	
				$no = $dataSelect+1;
	
				while($semakID = mysql_fetch_array($qSelect))
				{
					if($no == $semakID['jabatanNama'])
					{
						$tempahanNo = $no++;
					}
					else
					{	$tempahanNo = $no;}
				}
				$status = "jbd";
				mysql_query("insert into jabatan values('$tambah','$no')");
		
			}
			else
			{	$status = "jtsa";}
		}
		else
		{	$status = "jtd";}
	}
	else
	{	$tambah = "";}
	

	if(!$status == "")
	{
		if($status == "jbd")
		{
			$paparStatus = "<font face='Arial, sans-serif' size='2' color='green'>Jabatan Berjaya Ditambah!</font>";
		}
		elseif($status == "jtsa")
		{
			$paparStatus = "<font face='Arial, sans-serif' size='2' color='Red'>Jabatan Telah Sedia Ada!</font>";
		}
		elseif($status == "jtd")
		{
			$paparStatus = "<font face='Arial, sans-serif' size='2' color='Red'>Jabatan Tidak Dimasukan!</font>";
		}
		elseif($status == "jtdh")
		{
			$paparStatus = "<font face='Arial, sans-serif' size='2' color='Red'>Jabatan Telah Dihapuskan!</font>";
		}
	}
	else
	{
		$paparStatus= "&nbsp;";
	}
	
	
?>
<!DOCTYPE>
<html xml:lang="EN" lang="EN" dir="ltr">
<head>
<title>WHO'S IN SISTEM</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="scripts/jquery.timers.1.2.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.2.1.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.setup.js"></script>
</head>
<body id="top">
<!-- ########################################HEADER############################################################### -->
<?php include '../header.php';?>

<!-- ##################################################TUTUP LOGO##################################################### -->

<!-- #################################################MENU###################################################### -->
<?php include 'menu.php';?>
<!-- #####################################################TUTUP MENU################################################## -->
<!-- ##################################################MAKLUMAT PENGUNA##################################################### -->
<div class="wrapper">
  <div class="container">
  <?php include 'tajuk_jabatan.php'; ?>
  </div>
</div>
<!-- #################################################TUTUP MAKLUMAT PENGGUNA###################################################### -->
<!-- ###############################################BODY######################################################## -->
<div class="wrapper">
<div class="container">

	<table>
    <thead>
    <tr>
    	<th colspan="2"><font face="Arial, sans-serif" size="2">Tambah Jabatan Baru</font></th>
    </tr>
    </thead>
    <tbody>
    <tr class="light"><form action="index.php" method="post">
    	<td><font face="Arial, sans-serif" size="2">Nama Jabatan : <input type="text" name="tambahJabatan" size="120" placeholder="Masukkan Nama Penuh Jabatan Baru" required></font></td>
        <td><div id="respond"><input type="submit" name="submit" value="Tambah">
        </td></div>
    </tr></form>
    </tbody>
    </table>

   <div align="center"> <?php echo $paparStatus;?></div>
    <br>
    
    
    
    
    <table summary="Summary Here" cellpadding="0" cellspacing="0" border="1">
      <thead>
    <tr>
       <th colspan="3"><font face="Arial, sans-serif" size="2">Senarai Jabatan</font></th>        
    </tr>
    </thead>
    <tbody>
    <tr class="dark">
    	<th width="4%"><font face="Arial, sans-serif" size="2">Bil.</font></th>
       	<th width="95%"><font face="Arial, sans-serif" size="2">Nama Jabatan</font></th>
       	<th width="1%">&nbsp;</th>
    </tr>
    <?php
		$bil = $start+1;
		$jabatan = mysql_query("select * from jabatan order by jabatanNama asc limit $eu,$limit");
		while($dataJabatan = mysql_fetch_array($jabatan))
		{
	?>
    
    
    <tr class="light">      
		<td align="center"><font face="Arial, sans-serif" size="2"><?php echo $bil++;?></font></td>        
        <td><font face="Arial, sans-serif" size="2"><?php echo $dataJabatan['jabatanNama'];?></font></td>
        <td>
		<a href="index.php?id=<?php echo $dataJabatan['jabatanNo']; ?>"><img src="../images/padam11.png" onClick="this.src='../images/padam11.png'" onMouseOver="this.src='../images/padam22.png'" onMouseOut="this.src='../images/padam11.png'" title="Padam Jabatan Ini"></a></td>
     </tr>
     <?php
		}
		$rows = mysql_num_rows(mysql_query("select * from jabatan"));
		$bilrow1 = $rows;
	 ?>
      <tr>        	<form action="index.php" method="post">
     	<td colspan="3"><font face="Arial, sans-serif" size="2">Bilangan Semua Jabatan : <?php echo $bilrow1;?>   ||
		  <?php
	
		

         if($back >= 0)
         	{ 
		
			?>
            <a href="index.php?start=<?php echo $back;?>" ><<</a>
            
            <?php
			}
         $j=0;
         $l=1;

         for($j=0; $j<$bilrow1; $j=$j+$limit)
         {
           if($j <> $eu)
           { 
		   ?>
           <a href="index.php?start=<?php echo $j;?>"><?php echo $l;?></a>
           <?php
		   }
           else
           { 
		   ?>
           <font face="Arial, sans-serif" size="2" color="#FF0000"><?php echo $l;?></font>
           <?php
   			}
           $l=$l+1;
         }

         if($thispage < $bilrow1)
         { echo "&nbsp;&nbsp;<a href='index.php?start=$next'>>></a>";}

?>
        
        || Limit paparan: </font>
	
		<select name="limit" onChange="this.form.submit();">
			<option value="5" <?php 
			if($lc == "5")
			{ echo "selected";}
			else
			{ echo "";}
			?>>5</option>
			<option value="10" <?php
			if($lc=="10")
			{ echo "selected";}
			else
			{ echo "";}
			?>>10</option>
			<option value="15" <?php 
			if($lc == "15")
			{ echo "selected";}
			else
			{ echo "";}
			?>>15</option>
			<option value="20" <?php 
			if($lc == "20")
			{ echo "selected";}
			else
			{ echo "";}
			?>>20</option>
		</form></td>
     </tr>
    </tbody>
    </table>
    
    </div>
    <br class="clear" />
</div>
<!-- #################################################TUTUP BODY###################################################### -->
<!-- #####################################################SPACE################################################## -->
<div id="adblock">
<br class="clear" />
</div>
<!-- #################################################TUTUP SPACE###################################################### -->

<!-- ##############################################BOTTOM######################################################### -->
<?php include '../footer.php';?>
<!-- ##############################################TUTuP BOTTOM######################################################### -->
</body>
</html>
<?php } ?>